/* X CLIENT — o'yin ichidagi bosh menyu logikasi. Faqat ES5 (CEF1 / Chrome 17).
 * O'yin:   nextclient.exec / getCvarValue / matchmaking / console / gameUi / connect hodisalari
 * Akkaunt: xc_api.php (shu papkada) — login, profil, bulut, do'stlar, TOP hafta, turnirlar */
(function () {
'use strict';

/* ============================================================ Promise (CEF1 da yo'q) */
if (typeof window.Promise !== 'function') {
  var P = function (fn) {
    var self = this; self._s = 0; self._v = undefined; self._cb = [];
    function settle(st, v) {
      if (self._s) return;
      if (st === 1 && v && typeof v.then === 'function') { v.then(function (x) { settle(1, x); }, function (e) { settle(2, e); }); return; }
      self._s = st; self._v = v;
      var cbs = self._cb; self._cb = [];
      for (var i = 0; i < cbs.length; i++) cbs[i]();
    }
    try { fn(function (v) { settle(1, v); }, function (e) { settle(2, e); }); } catch (e) { settle(2, e); }
  };
  P.prototype.then = function (onF, onR) {
    var self = this;
    return new P(function (res, rej) {
      function run() {
        setTimeout(function () {
          var h = self._s === 1 ? onF : onR;
          if (typeof h !== 'function') { (self._s === 1 ? res : rej)(self._v); return; }
          try { res(h(self._v)); } catch (e) { rej(e); }
        }, 0);
      }
      if (self._s) run(); else self._cb.push(run);
    });
  };
  P.prototype['catch'] = function (onR) { return this.then(null, onR); };
  window.Promise = P;
}

/* ============================================================ yordamchilar */
function $(id) { return document.getElementById(id); }
function each(list, fn) { for (var i = 0; i < list.length; i++) fn(list[i], i); }
function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function now() { return new Date().getTime(); }
function closest(el, attr) { while (el && el !== document) { if (el.getAttribute && el.getAttribute(attr) != null) return el; el = el.parentNode; } return null; }
function copy(o) { return JSON.parse(JSON.stringify(o)); }
function q(v) { return '"' + String(v).replace(/"/g, '') + '"'; }
var DEBUG = /[?&]debug=1/.test(location.search);
function dbg(m) { if (!DEBUG) return; var d = $('dbg'); d.style.display = 'block'; d.innerHTML = esc(m) + '<br>' + d.innerHTML.slice(0, 2000); }

var NC = window.nextclient || null;
/* Oddiy brauzerda (o'yindan tashqarida) ochilsa - yuklab olish sahifasiga. O'yin brauzeri CEF1 (Chrome 17), ?menu - tekshirish uchun */
(function () {
  var ua = navigator.userAgent || '', m = /Chrome\/(\d+)/.exec(ua);
  var modern = m ? +m[1] >= 50 : /Firefox|Safari|Edge/.test(ua);
  if (!NC && modern && !/[?#&]menu/.test(location.href)) location.replace('https://cssborka.uz/xclient/index.html');
})();
function hasApi() { return !!(NC && typeof NC.exec === 'function'); }
function hasMM() { return !!(NC && NC.matchmaking && NC.matchmaking.getServerInfo); }
function canRead() { return !!(NC && typeof NC.getCvarValue === 'function'); }
function ncHas(cv) { if (!canRead()) return true; var v = readCvar(cv); return v != null && v !== ''; }   // NextClient 2.5 da yo'q, 2.6 da bor sozlamalar
function radarNC() { return ncHas('hud_radar_scale'); }
var NCH = {};
function ncHasC(cv) { if (!(cv in NCH)) NCH[cv] = ncHas(cv); return NCH[cv]; }   // natija eslab qolinadi (har saqlashda o'yindan qayta so'ramaymiz)
/* oddiy kompyuter (launcher bilan bir xil qoida): F9 buferi o'yinchi o'zi yoqmasa - o'chiq */
function verGE(a, b) { a = String(a || '0').split('.'); b = String(b).split('.'); for (var i = 0; i < 3; i++) { var x = +a[i] || 0, y = +b[i] || 0; if (x !== y) return x > y; } return true; }
function pcWeak() { return !!(HW && ((HW.cpu && HW.cpu < 4) || (HW.ram && HW.ram < 6144))); }
function rbOn() { return false; }   // F9 (oxirgi 30 soniya) hammada o'chiq: orqa fonda doim yozish o'yinni qotirardi
function readCvar(n) { if (!canRead()) return null; try { var v = NC.getCvarValue(n); return v == null ? null : String(v); } catch (e) { return null; } }
function cmd(c) {
  dbg('exec: ' + c);
  try {
    if (hasApi()) {
      /* serverga ulanishdan OLDIN menyu musiqasini o'chiramiz: xarita yuklanayotganda mp3 chalinsa o'yin qotib,
       * ovoz takrorlanib qoladi va ba'zan yuklanish tugamaydi ('connect' hodisasi kech yoki manzilsiz kelishi mumkin) */
      if (/^(connect|retry|reconnect)\b/.test(c)) { if (DEMO_PLAY) demoEnd('menyu: ' + c); NC.exec('host_framerate 0\n'); NC.exec('mp3 stop\n'); NC.exec('stopsound\n'); MUSIC_ON = false; }
      /* demo paytida menyu yuborgan har bir buyruq konsolda ko'rinsin - demo nima sababdan yopilganini topish uchun */
      if (DEMO_PLAY && !/^(echo|play |xcd_|alias xcd|bind F[6-9]|unbind F[6-9])/.test(c)) NC.exec('echo [X CLIENT menyu] ' + c.replace(/["\n]/g, ' ') + '\n');
      NC.exec(c + '\n'); return true;
    }
  } catch (e) { dbg('exec xato ' + e); }
  return false;
}
function toast(msg, ms) {
  var t = $('toast'); t.innerHTML = esc(msg); t.style.display = 'block'; t.removeAttribute('data-ip'); t.removeAttribute('data-frprof'); t.className = '';
  clearTimeout(toast.tm); toast.tm = setTimeout(function () { t.style.display = 'none'; }, ms || 2800);
}
/* bosiladigan xabar: do'st serverga kirdi -> bosilsa o'sha serverga ulanadi */
function toastAct(msg, attr, val, ms) { toast(msg, ms || 8000); var t = $('toast'); t.setAttribute(attr, val); t.className = 'act'; }
function normIp(ip) {
  ip = String(ip || '').replace(/\s+/g, '');
  if (!/^[\w.\-]+(:\d{1,5})?$/.test(ip)) return '';
  if (ip.indexOf(':') < 0) ip += ':27015';
  return ip;
}
function clean(v) { return String(v || '').replace(/[\u0000-\u001f\u007f-\u009f\ufffd\u2580-\u259f]/g, ' ').replace(/\s{2,}/g, ' ').replace(/^\s+|\s+$/g, ''); }

/* ============================================================ til */
var LANG = window.XC_LANG || { uz: {} };
var L = LANG.uz, CUR_LANG = 'uz';
var LFALL = { ua: 'ru', kz: 'ru', kg: 'ru', tj: 'ru', tr: 'en', az: 'en', tm: 'en' };
function T(k) {
  if (L && L[k] != null) return L[k];
  var f = LANG[LFALL[CUR_LANG]];
  if (f && f[k] != null) return f[k];
  return LANG.uz[k] != null ? LANG.uz[k] : k;
}
function fmtShort(sec) {                       // o'yinchilar ro'yxati uchun qisqa: 1:04 yoki 26'
  sec = Math.max(0, Math.round(sec || 0));
  var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60);
  return h ? h + ':' + (m < 10 ? '0' : '') + m : m + "'";
}
function fmtDur(sec) {
  sec = Math.max(0, Math.round(sec || 0));
  var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60);
  if (CUR_LANG === 'ru' || LFALL[CUR_LANG] === 'ru') return h ? h + ' \u0447 ' + m + ' \u043c\u0438\u043d' : m + ' \u043c\u0438\u043d';
  if (CUR_LANG === 'en') return h ? h + ' h ' + m + ' min' : m + ' min';
  return h ? h + ' soat ' + m + ' daq' : m + ' daq';
}
function fmtTime(ts) {
  var d = new Date(ts), n = new Date();
  var hm = (d.getHours() < 10 ? '0' : '') + d.getHours() + ':' + (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
  if (d.toDateString() === n.toDateString()) return hm;
  var y = new Date(n.getTime() - 86400000);
  if (d.toDateString() === y.toDateString()) return (CUR_LANG === 'ru' ? '\u0432\u0447\u0435\u0440\u0430 ' : CUR_LANG === 'en' ? 'yesterday ' : 'kecha ') + hm;
  return d.getDate() + '.' + (d.getMonth() + 1) + ' ' + hm;
}
function applyLang() {
  each(document.querySelectorAll('[data-t]'), function (el) { el.innerHTML = esc(T(el.getAttribute('data-t'))); });
  if (typeof renderTop2 === 'function') renderTop2();
  $('srvSearch').setAttribute('placeholder', T('search'));
  renderLoginForm();
  renderAll();
}
var LANGS = [['uz', 'UZ', "O'zbekcha", '#1eb53a'], ['ru', 'RU', '\u0420\u0443\u0441\u0441\u043a\u0438\u0439', '#0039a6'], ['en', 'EN', 'English', '#012169'],
  ['ua', 'UA', '\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430', '#0057b7'], ['tr', 'TR', 'T\u00fcrk\u00e7e', '#e30a17'], ['kz', 'KZ', '\u049a\u0430\u0437\u0430\u049b\u0448\u0430', '#00afca'],
  ['kg', 'KG', '\u041a\u044b\u0440\u0433\u044b\u0437\u0447\u0430', '#e8112d'], ['tj', 'TJ', '\u0422\u043e\u04b7\u0438\u043a\u04e3', '#006600'], ['az', 'AZ', 'Az\u0259rbaycanca', '#0092bc'], ['tm', 'TM', 'T\u00fcrkmen\u00e7e', '#28ae66']];
/* bayroqlar (ichki SVG - internet kerak emas, har o'lchamda tiniq) */
var FLAGS = {"uz": "<rect width=\"30\" height=\"20\" fill=\"#1eb53a\"/><rect width=\"30\" height=\"13.6\" fill=\"#ce1126\"/><rect width=\"30\" height=\"13.2\" fill=\"#fff\"/><rect width=\"30\" height=\"6.8\" fill=\"#ce1126\"/><rect width=\"30\" height=\"6.4\" fill=\"#0099b5\"/><circle cx=\"5\" cy=\"3.2\" r=\"2.2\" fill=\"#fff\"/><circle cx=\"5.9\" cy=\"3.2\" r=\"1.9\" fill=\"#0099b5\"/>", "ru": "<rect width=\"30\" height=\"20\" fill=\"#d52b1e\"/><rect width=\"30\" height=\"13.3\" fill=\"#0039a6\"/><rect width=\"30\" height=\"6.7\" fill=\"#fff\"/>", "en": "<rect width=\"30\" height=\"20\" fill=\"#012169\"/><path d=\"M0 0L30 20M30 0L0 20\" stroke=\"#fff\" stroke-width=\"4\"/><path d=\"M0 0L30 20M30 0L0 20\" stroke=\"#c8102e\" stroke-width=\"1.4\"/><rect x=\"12\" width=\"6\" height=\"20\" fill=\"#fff\"/><rect y=\"7\" width=\"30\" height=\"6\" fill=\"#fff\"/><rect x=\"13.3\" width=\"3.4\" height=\"20\" fill=\"#c8102e\"/><rect y=\"8.3\" width=\"30\" height=\"3.4\" fill=\"#c8102e\"/>", "ua": "<rect width=\"30\" height=\"20\" fill=\"#ffd700\"/><rect width=\"30\" height=\"10\" fill=\"#0057b7\"/>", "tr": "<rect width=\"30\" height=\"20\" fill=\"#e30a17\"/><circle cx=\"11\" cy=\"10\" r=\"5\" fill=\"#fff\"/><circle cx=\"12.3\" cy=\"10\" r=\"4\" fill=\"#e30a17\"/><polygon points=\"19.6,10 17.3,10.8 17.9,13.1 16.4,11.2 14.1,11.9 15.5,10 14.1,8.1 16.4,8.8 17.9,6.9 17.3,9.2\" fill=\"#fff\"/>", "kz": "<rect width=\"30\" height=\"20\" fill=\"#00afca\"/><circle cx=\"16\" cy=\"9\" r=\"3.4\" fill=\"#fec50c\"/><rect x=\"2\" width=\"1.6\" height=\"20\" fill=\"#fec50c\"/>", "kg": "<rect width=\"30\" height=\"20\" fill=\"#e8112d\"/><circle cx=\"15\" cy=\"10\" r=\"5\" fill=\"#ffef00\"/><circle cx=\"15\" cy=\"10\" r=\"2.6\" fill=\"#e8112d\"/>", "tj": "<rect width=\"30\" height=\"20\" fill=\"#006600\"/><rect width=\"30\" height=\"14.3\" fill=\"#fff\"/><rect width=\"30\" height=\"5.7\" fill=\"#cc0000\"/><circle cx=\"15\" cy=\"10\" r=\"1.7\" fill=\"#f8c300\"/>", "az": "<rect width=\"30\" height=\"20\" fill=\"#509e2f\"/><rect width=\"30\" height=\"13.3\" fill=\"#ef3340\"/><rect width=\"30\" height=\"6.7\" fill=\"#00b5e2\"/><circle cx=\"14\" cy=\"10\" r=\"2.6\" fill=\"#fff\"/><circle cx=\"14.8\" cy=\"10\" r=\"2.1\" fill=\"#ef3340\"/><circle cx=\"17.6\" cy=\"10\" r=\"0.9\" fill=\"#fff\"/>", "tm": "<rect width=\"30\" height=\"20\" fill=\"#00843d\"/><rect x=\"4\" width=\"5\" height=\"20\" fill=\"#d22630\"/><circle cx=\"21\" cy=\"5\" r=\"2.6\" fill=\"#fff\"/><circle cx=\"22.1\" cy=\"4.5\" r=\"2.3\" fill=\"#00843d\"/>"};
function langFlag(c) { return FLAGS[c] ? '<svg viewBox="0 0 30 20" width="30" height="20" preserveAspectRatio="none">' + FLAGS[c] + '</svg>' : ''; }
function langBox(o) { return '<b class="flb" style="background:' + o[3] + '">' + (FLAGS[o[0]] ? langFlag(o[0]) : o[1]) + '</b>'; }
/* kichik ikonkalar: emoji o'yin brauzerida (CEF) kvadrat bo'lib chiqadi - SVG ishlatamiz */
function ico(n) {
  var P = { chat: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>', phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
    gift: '<polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>',
    flag: '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>',
    swords: '<polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5"/><line x1="13" y1="19" x2="19" y2="13"/><line x1="16" y1="16" x2="20" y2="20"/><line x1="19" y1="21" x2="21" y2="19"/><polyline points="14.5 6.5 18 3 21 3 21 6 17.5 9.5"/><line x1="5" y1="14" x2="9" y2="18"/><line x1="7" y1="17" x2="4" y2="20"/><line x1="3" y1="19" x2="5" y2="21"/>',
    clock: '<circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/>',
    play: '<polygon points="6 4 20 12 6 20 6 4" fill="currentColor"/>', pause: '<rect x="6" y="4" width="4" height="16" fill="currentColor"/><rect x="14" y="4" width="4" height="16" fill="currentColor"/>',
    rew: '<polygon points="11 19 2 12 11 5 11 19" fill="currentColor"/><polygon points="22 19 13 12 22 5 22 19" fill="currentColor"/>', ff: '<polygon points="13 19 22 12 13 5 13 19" fill="currentColor"/><polygon points="2 19 11 12 2 5 2 19" fill="currentColor"/>',
    cut: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.1" y2="15.9"/><line x1="14.5" y1="14.5" x2="20" y2="20"/><line x1="8.1" y1="8.1" x2="12" y2="12"/>',
    trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6M9 6V4h6v2"/>', folder: '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
    share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.6" y1="13.5" x2="15.4" y2="17.5"/><line x1="15.4" y1="6.5" x2="8.6" y2="10.5"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
    key: '<circle cx="7.5" cy="15.5" r="4.5"/><path d="M10.7 12.3L20 3M16 7l3 3M14 9l2 2"/>',
    stop: '<rect x="5" y="5" width="14" height="14" fill="currentColor"/>', film: '<rect x="2" y="4" width="20" height="16" rx="2"/><line x1="7" y1="4" x2="7" y2="20"/><line x1="17" y1="4" x2="17" y2="20"/><line x1="2" y1="12" x2="22" y2="12"/>', user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>' };
  return '<svg class="ico" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">' + (P[n] || '') + '</svg>';
}
function agoText(ts) {
  if (!ts) return T('ago_long');
  var d = Math.max(0, Math.floor(now() / 1000) - ts);
  if (d < 120) return T('ago_now');
  if (d < 3600) return T('ago_m').replace('{n}', Math.floor(d / 60));
  if (d < 86400) return T('ago_h').replace('{n}', Math.floor(d / 3600));
  return T('ago_d').replace('{n}', Math.floor(d / 86400));
}
function setLang(code) {
  var map = { uzbek: 'uz', russian: 'ru', ukrainian: 'ua', english: 'en', turkish: 'tr', kazakh: 'kz', kyrgyz: 'kg', tajik: 'tj', azerbaijani: 'az', turkmen: 'tm' };
  code = String(code || '').toLowerCase();
  CUR_LANG = LANG[code] ? code : (map[code] || 'uz');
  L = LANG[CUR_LANG] || LANG.uz;
  applyLang();
}

/* ============================================================ mahalliy saqlash */
var DB = { fav: [], hist: [], set: null, binds: null, lang: '', token: '', guest: 0, device: '', autosave: 1, cloudt: 0 };
function load() {
  try { var x = JSON.parse(localStorage.getItem('xclient') || '{}'); for (var k in x) if (x.hasOwnProperty(k)) DB[k] = x[k]; } catch (e) {}
  if (!DB.fav || !DB.fav.length) DB.fav = [];
  if (!DB.hist || !DB.hist.length) DB.hist = [];
  if (!DB.device) { DB.device = ''; for (var i = 0; i < 16; i++) DB.device += 'abcdefghijklmnopqrstuvwxyz0123456789'.charAt(Math.floor(Math.random() * 36)); }
}
function persist() { try { localStorage.setItem('xclient', JSON.stringify(DB)); } catch (e) {} if (typeof statePush === 'function') statePush(); }

/* ============================================================ ekranga moslash (1600x900 dizayn) */
function fit() {
  var w = window.innerWidth || document.documentElement.clientWidth || 1600;
  var h = window.innerHeight || document.documentElement.clientHeight || 900;
  var z = Math.min(w / 1600, h / 900);
  var app = $('app');
  /* Kichik ekranda (z < 1) "zoom" bilan o'yin brauzeri matnni kichraytirmaydi (eng kichik shrift chegarasi) -
   * yozuvlar kattalashib, oynadan chiqib ketardi. Shuning uchun kichraytirish transform bilan: hammasi bir xil
   * nisbatda kichrayadi. Katta ekranda (z >= 1) zoom - matn tiniq qoladi. */
  if (z < 1) {
    app.style.zoom = 1;
    app.style.webkitTransformOrigin = '0 0'; app.style.transformOrigin = '0 0';
    app.style.webkitTransform = 'scale(' + z + ')'; app.style.transform = 'scale(' + z + ')';
  } else {
    app.style.webkitTransform = ''; app.style.transform = '';
    app.style.zoom = z;
  }
  var W = Math.round(w / z), H = Math.round(h / z);
  app.style.width = W + 'px'; app.style.height = H + 'px';
  each(document.querySelectorAll('.modal'), function (m) { m.style.width = W + 'px'; m.style.height = H + 'px'; });
  each(document.querySelectorAll('.win'), function (m) {
    var small = m.className.indexOf('sm') >= 0, mw = small ? 760 : 1180, mh = small ? 620 : 780;
    m.style.left = Math.round((W - mw) / 2) + 'px'; m.style.top = Math.max(10, Math.round((H - 52 - mh) / 2)) + 'px';
  });
  var ask = document.querySelector('.ask'); ask.style.left = Math.round((W - 480) / 2) + 'px'; ask.style.top = Math.round((H - 230) / 2) + 'px';
  $('toast').style.left = Math.round((W - 440) / 2) + 'px';
  $('loginBox').style.left = Math.max(620, W - 740) + 'px';
  // markazdagi X CLIENT: chap menyu bilan o'ng ustun o'rtasida
  var st = $('stage'), mid = Math.round((480 + (W - 450)) / 2);
  st.style.left = (mid - 300) + 'px'; st.style.top = Math.max(40, Math.round((H - 52 - 600) / 2)) + 'px';
}

/* ============================================================ yengil animatsiya
 * O'yin brauzeri (CEF1) har kadrni protsessorda chizadi - shuning uchun faqat kichik maydon,
 * sekundiga ~12 marta: halqa sekin aylanadi, nur "nafas oladi", logo ozgina suzadi. */
var INTRO_TM = 0;
function intro() {
  var r = document.querySelector('#stage .r1'), g = document.querySelector('#stage .glow'), x = document.querySelector('#stage .xl2'), t = document.querySelector('#stage .ttl');
  if (!r || !g || !x || !t) return;
  clearInterval(INTRO_TM);
  var f = 0, N = lowFx() ? 1 : 16;                      // ~1.2 soniya, keyin to'xtaydi (yengil menyuda - darhol)
  INTRO_TM = setInterval(function () {
    f++;
    var p = f / N, e = 1 - Math.pow(1 - p, 3);          // ease-out
    r.style.webkitTransform = 'rotate(' + Math.round(-120 + 120 * e) + 'deg)';
    g.style.opacity = e.toFixed(2);
    x.style.opacity = e.toFixed(2);
    x.style.webkitTransform = 'scale(' + (0.82 + 0.18 * e).toFixed(3) + ')';
    t.style.opacity = Math.max(0, (p - 0.4) / 0.6).toFixed(2);
    if (f >= N) clearInterval(INTRO_TM);
  }, 75);
}
/* uchqunlar: 14 ta kichik <i> (3x3 px) sekundiga ~11 marta siljiydi - faqat o'sha kichik nuqtalar qayta chiziladi.
 * O'yin paytida (menyu yopiq), oyna ochiq bo'lsa yoki Tizim'da o'chirilsa - hech narsa qilmaydi.
 * Kompyuter sekin bo'lsa (taymer kechiksa) o'zi o'chadi. */
var FX = { tm: 0, p: [], last: 0, slow: 0, off: 0, n: 0 };
/* Yengil menyu: effektlar (uchqun, porlash, halqa, soyalar) o'chiq - ESC bosilganda o'yin FPS'i tushmasin */
/* funksiya tugmalari (admin panel > Funksiyalar): o'chirilgani menyuda ko'rinmaydi. html ga "nf-<nom>" klassi qo'yiladi */
var FEAT = {};
function feat(k) { return FEAT[k] !== 0; }
function loadFeat() {
  api('feat', {}, function (r) {
    if (!r.ok || !r.f) return;
    FEAT = r.f; window.XC_BETA = r.beta; var h = document.documentElement;
    h.className = (h.className || '').replace(/(^|\s)nf-\w+/g, '');
    for (var k in FEAT) if (FEAT.hasOwnProperty(k) && FEAT[k] === 0) h.className += ' nf-' + k;
    if (typeof applyBg === 'function') applyBg();
  });
}
/* o'yin menyusi ko'rinib turibdimi: NextClient 'show'/'hide' hodisalari bo'yicha (gameUi.shown xususiyati har versiyada bo'lmasligi mumkin) */
var UI_VIS = true;
function uiShown() { try { if (NC && NC.gameUi && typeof NC.gameUi.shown === 'boolean') return NC.gameUi.shown; } catch (e) {} return UI_VIS; }
/* serverda o'ynalayotganda (ESC menyusi o'yin ustida) - effektlarsiz: aks holda o'yin FPS'i tushadi */
var SAFE = 0;   // launcher xavfsiz rejimda (o'yin 3 marta ketma-ket yiqilgan) - shu safar effektsiz, odamchalarsiz
function lowFx() { return DB.fx === 0 || !!FX.off || !!CONNECTED || !!SAFE || localGame(); }
function fxClass() { var h = document.documentElement; h.className = (h.className || '').replace(/(^|\s)lowfx(?=\s|$)/g, '') + (lowFx() ? ' lowfx' : ''); }
function fxVisible() {
  if (curModal || document.webkitHidden) return false;
  return uiShown();
}
/* o'ng tomondagi qahramonlar: ikkalasi alohida qatlam - har biri o'zicha nafas oladi, tebranadi va ko'zini pirpiratadi.
 * CEF1 har kadrni protsessorda chizadi - sekundiga ~15 kadr, faqat menyu ko'rinib turganda, oyna ochiq emas va effektlar
 * yoqiq bo'lsa (o'yinda va kuchsiz kompyuterda qimirlamaydi) */
var HERO = null, HERO_T0 = now(), HERO_LAST = 0, HERO_SLOW = 0, HERO_OFF = false;
function heroInit() {
  var f = $('heroF'), b = $('heroB'); if (!f || !b) return null;
  return { f: f, b: b, g: $('hero').getElementsByTagName('div')[0], fb: $('heroFB'), bb: $('heroBB'), nf: now() + 2500, nb: now() + 4200 };
}
function heroBlink(el, at) {   // ko'z yumiladi ~130 ms; ba'zan ikki marta
  var t = now();
  if (t >= at) { el.style.visibility = 'visible'; setTimeout(function () { el.style.visibility = 'hidden'; }, 130); return t + (Math.random() < 0.2 ? 320 : 3000 + Math.random() * 4000); }
  return at;
}
/* Harakatning o'zi CSS animatsiyada (brauzer silliq chizadi - JS taymer bilan "qotib-qotib" siljirdi).
 * JS faqat: ko'z pirpiratish, menyu ko'rinmaganda pauza, kompyuter ulgurmasa butunlay to'xtatish */
/* Harakat JS bilan, sekundiga 20 kadr va faqat siljish (masshtabsiz): o'yin brauzeri (CEF1) har kadrni o'yinning asosiy oqimida
 * chizadi - CSS animatsiya kadr tezligida (100+) qayta chizib, kuchsizroq kompyuterda o'yinni "не отвечает" holatiga tushirardi.
 * Menyu ochilgandan 10 s keyin boshlanadi (o'yin yuklanib bo'lgach); admin > Funksiyalar > Animatsiyalar o'chiq bo'lsa - qimirlamaydi */
var HERO_T1 = now() + 10000;
/* odamchalar rasmlari faqat kuchli/o'rtacha kompyuterda yuklanadi. Kuchsiz kompyuter, Windows 7/8 yoki "Yengil menyu" -
 * umuman yo'q (yuklanmaydi ham): o'yin brauzeri xotirasi kamayadi, eski kompyuterlarda yiqilishlar kamayadi */
var HERO_LD = 0;
/* odamchalar har doim ko'rinadi (faqat 3 marta yiqilgandan keyingi xavfsiz rejimda yo'q). Kuchsiz kompyuterda va o'yin ichida (ESC) -
 * harakatsiz rasm: har kadr qayta chizilmaydi, o'yin sekinlashmaydi */
function heroWeak() { return !!SAFE; }
function heroStill() { return DB.fx === 0 || !!LITE || (DB.fx == null && HW && hwClass() === 'weak'); }
function heroLoad() {
  var h = $('hero'); if (!h) return;
  if (heroWeak()) { h.className = 'hnone'; HERO_OFF = true; return; }
  if (HERO_LD) return; HERO_LD = 1; HERO_OFF = false;
  var im = h.getElementsByTagName('img');
  for (var i = 0; i < im.length; i++) { var u = im[i].getAttribute('data-src'); if (u) im[i].src = u; }
  h.className = 'hoff'; if (HERO) HERO.cls = 'hoff';
}
setTimeout(heroLoad, 4000);   // sayt javob bermasa (kompyuter quvvati noma'lum) - 4 s dan keyin
function heroTick() {
  if (!HERO_LD) return 1000;
  if (!HERO) { HERO = heroInit(); if (!HERO) return 1000; HERO.el = $('hero'); }
  var tn = now(), off = HERO_OFF || lowFx() || heroStill() || !feat('anim') || tn < HERO_T1;
  var cls = off ? 'hoff' : !fxVisible() ? 'hp' : '';
  if (HERO.cls !== cls) { HERO.cls = cls; HERO.el.className = cls; }
  if (cls) { HERO_LAST = 0; return 1000; }
  if (HERO_LAST) { HERO_SLOW = tn - HERO_LAST > 160 ? HERO_SLOW + 1 : Math.max(0, HERO_SLOW - 1); if (HERO_SLOW > 30) { HERO_OFF = true; return 1000; } } HERO_LAST = tn;
  var t = (tn - HERO_T0) / 1000;
  HERO.f.style.webkitTransform = 'translate(' + (Math.sin(t * 0.31 + 2) * 2).toFixed(2) + 'px,' + (Math.sin(t * 1.12) * 3.5).toFixed(2) + 'px)';
  HERO.b.style.webkitTransform = 'translate(' + (Math.sin(t * 0.27 + 0.4) * 2.5).toFixed(2) + 'px,' + (Math.sin(t * 0.86 + 1.3) * 4).toFixed(2) + 'px)';
  HERO.nf = heroBlink(HERO.fb, HERO.nf); HERO.nb = heroBlink(HERO.bb, HERO.nb);
  return 50;
}
/* o'yin paytida (harakat o'chiq) taymer sekundiga 20 marta emas, 1 marta uyg'onadi - CEF1 taymerlari o'yin oqimida ishlaydi */
(function heroLoop() { var d = 1000; try { d = heroTick() || 1000; } catch (e) {} setTimeout(heroLoop, d); })();
/* menyu foni (rang) va zarrachalar: uchqun / qor / yo'q. Bayramlarda o'zi bezanadi (Yangi yil - qor, Navro'z, Mustaqillik) */
var BGS = { def: '', blue: '#0d2a4a 0%, #0b1526 30%, #080c16 60%, #05070c 100%', purple: '#3a0d4a 0%, #1f0b2a 30%, #110a18 60%, #08060c 100%',
  green: '#0d3a1e 0%, #0b1f12 30%, #0a120d 60%, #060a07 100%', dark: '#1a1a1f 0%, #111114 30%, #0b0b0d 60%, #060607 100%', sand: '#4a3410 0%, #2a1e0b 30%, #16100a 60%, #0a0806 100%' };
function holiday() {
  if (DB.hol === 0 || !feat('holiday')) return null;
  var d = new Date(), md = (d.getMonth() + 1) * 100 + d.getDate();
  if (md >= 1215 || md <= 110) return { id: 'ny', ptc: 'snow' };
  if (md >= 318 && md <= 325) return { id: 'nav', ptc: 'nav' };
  if (md >= 828 && md <= 903) return { id: 'ind', ptc: 'ind' };
  return null;
}
function ptcMode() { var h = holiday(); return DB.ptc === 'none' || !feat('particles') ? 'none' : (h && DB.ptc !== 'spark' ? h.ptc : (DB.ptc || 'spark')); }
function applyBg() {
  var b = $('bg'); if (!b) return;
  var g = BGS[DB.bgs || 'def'];
  b.style.background = g && !isDay() ? '-webkit-radial-gradient(55% 45%, circle cover, ' + g + ')' : '';
  var hb = $('holBar'), h = holiday();
  if (h) { if (!hb) { hb = document.createElement('div'); hb.id = 'holBar'; (document.getElementById('app') || document.body).appendChild(hb); } hb.className = 'hol ' + h.id; hb.innerHTML = esc(T('hd_' + h.id)); hb.style.display = ''; }
  else if (hb) hb.style.display = 'none';
  var m = ptcMode(), st = $('stage'); if (st) st.className = 'pt-' + m;
  if (FX.mode !== m) { FX.mode = m; each(FX.p, function (p) { sparkReset(p, true); }); sparks(); }
}
function sparkReset(p, first) {
  if (FX.mode === 'snow') {
    p.x = Math.random() * 600; p.y = first ? Math.random() * 600 : -10; p.vx = (Math.random() - 0.5) * 0.6; p.vy = 1 + Math.random() * 1.6;
    p.max = 400; p.life = 400; return;
  }
  p.x = 150 + Math.random() * 300; p.y = first ? 200 + Math.random() * 380 : 470 + Math.random() * 110;
  p.vx = (Math.random() - 0.5) * 2.4; p.vy = -(1.6 + Math.random() * 3.2);
  p.max = 22 + Math.floor(Math.random() * 26); p.life = first ? Math.floor(Math.random() * p.max) : p.max;
}
function sparks() {
  var st = $('stage'); if (!st) return;
  if (!FX.p.length) {
    for (var i = 0; i < 14; i++) {
      var d = document.createElement('i'); d.className = 'spk' + (i % 3 ? '' : ' s2'); st.appendChild(d);
      var p = { el: d }; sparkReset(p, true); FX.p.push(p);
    }
  }
  clearInterval(FX.tm);
  var on = DB.fx !== 0 && !FX.off && ptcMode() !== 'none';
  fxClass();
  each(FX.p, function (q) { q.el.style.display = on ? '' : 'none'; });
  if (!on) return;
  FX.last = +new Date();
  FX.tm = setInterval(sparkTick, 90);
}
function sparkTick() {
  var t = +new Date(), dt = t - FX.last; FX.last = t;
  if (!fxVisible()) return;
  if (dt > 260 && dt < 3000) { if (++FX.slow >= 12) { FX.off = 1; sparks(); return; } } else if (FX.slow > 0 && dt < 140) FX.slow -= 0.25;
  each(FX.p, function (p) {
    p.life--; if (p.life <= 0) sparkReset(p);
    p.x += p.vx; p.y += p.vy; p.vx += (Math.random() - 0.5) * (FX.mode === 'snow' ? 0.1 : 0.4);
    if (FX.mode === 'snow' && p.y > 620) sparkReset(p);
    var s = p.el.style;
    s.left = Math.round(p.x) + 'px'; s.top = Math.round(p.y) + 'px'; s.opacity = FX.mode === 'snow' ? '0.85' : (p.life / p.max).toFixed(2);
  });
  // kirmaganlarga akkaunt kartasi sekin "nafas oladi"
  if (!ME && !acxHidden() && !DB.dnd && ++FX.n % 11 === 0) { var a = $('acct'); if (a) a.className = 'card acct' + (FX.n % 22 ? ' hi' : ''); }
}
function fxLoop() {
  intro(); sparks();
  try { if (NC && NC.gameUi && NC.gameUi.addEventListener) NC.gameUi.addEventListener('show', intro); } catch (e) {}
}
/* ============================================================ XClient.exe bilan aloqa
 * XClient.exe bosh menyu manziliga ?xc=<kompyuter id>&v=<versiya>&c=<kesh MB> qo'shadi.
 * Tizim sozlamalari (beta, Windows bilan ishga tushish, ekran, kesh, fayllarni tekshirish)
 * xc_api.php ga yoziladi va XClient.exe ularni keyingi ishga tushishda bajaradi. */
function qparam(k) { var m = new RegExp('[?&]' + k + '=([^&]*)').exec(location.search || ''); return m ? decodeURIComponent(m[1]) : ''; }
var PCID = /^[a-z0-9]{8,40}$/.test(qparam('xc')) ? qparam('xc') : '';   // kompyuter id (DB.pcid) va uning maxfiy kaliti (DB.pck) load() dan keyin olinadi
var HW = null, OPTS = { beta: 0, auto: 1, start: 0, res: '', win: 0, winx: 0, clean: 0, verify: 0, prio: 0, shots: 0, packs: '', hud: 100, vq: 'mid', dmf: null, vids: null, mic: 0, rb: 1, rbx: 0, rsk: 3, rskx: 0, tune: 1, macc: 1, bgp: 1, dvr: 0, dvroff: 0 }, CACHE_MB = parseInt(qparam('c'), 10) || 0;
var OPTS_TRY = 0;
/* To'liq X CLIENT menyusi faqat XCLauncher.exe orqali ochilganda. Menyu saytda turadi va boshqa boost-top sborkalari ham
 * uni ochadi - ularda "sodda rejim": tezkor o'yin, serverlar, sozlamalar + X CLIENT ni yuklab olish kartasi.
 * Sayt javobigacha ('gate') akkaunt/do'stlar/vazifalar yashirin turadi; javob kelmasa 8 s dan keyin to'liq menyu ochiladi. */
var LITE = null;
/* xc.html ni faqat X CLIENT o'rnatgan o'yin ochadi (launcher bosh sahifani shunga almashtiradi) - u yerda o'yin
 * launchersiz (eski boost-top yorlig'idan, 10 daqiqadan keyin yoki IP almashgan holda) ochilsa ham to'liq menyu */
var ON_XC = /(^|\/)xc\.html$/i.test(location.pathname || '');
/* eski launcher: menyuda yangilash kartasi. Launcher har ochilishda o'zi yangilanadi - eski qolgan bo'lsa
 * avto-yangilash o'chirilgan yoki yuklab bo'lmagan. Yopsa 2 kun ko'rinmaydi */
var LVER = '';
function launcherOld() { return !!(PCID && LVER && VERSION && /^1\.0\.\d+$/.test(LVER) && !verGE(VERSION, LVER)); }
function updCard() {
  var c = $('updCard'); if (!c) return;
  var on = launcherOld() && !LITE && !(DB.updx && now() - DB.updx < 2 * 864e5);
  c.style.display = on ? '' : 'none';
  if (on) $('updT').innerHTML = esc(T('up_t').replace('{v}', VERSION).replace('{n}', LVER));
}
function updPane() {
  CLK.upd_open = (CLK.upd_open || 0) + 1; CLK_N++;
  var off = OPTS && OPTS.auto === 0;
  openSide('updl', T('up_h'), '<div class="qrw"><p class="qri">' + esc(T('up_t').replace('{v}', VERSION).replace('{n}', LVER)) + '</p>' +
    (off ? '<p><b>' + esc(T('up_off')) + '</b></p><a class="btn red" data-act="updauto">' + esc(T('up_on')) + '</a>' : '') +
    '<ol class="upst"><li>' + esc(T('up_1')) + '</li><li>' + esc(T('up_2')) + '</li><li>' + esc(T('up_3')) + '</li></ol>' +
    '<div class="avurl"><input class="ipin" readonly value="cssborka.uz/xclient"><a class="cpy" data-copyip="https://cssborka.uz/xclient">' + esc(T('ip_copy')) + '</a></div></div>');
}
/* akkaunt kartasi yopilganmi: 3-yopishdan keyin butunlay, oldin - 5 kunga. acx=1 (eski menyu yoki serverdagi belgi) - vaqti noma'lum, yana ko'rsatiladi */
function acxHidden() { if (!DB.acx) return false; if ((DB.acn || 0) >= 3) return true; return DB.acx > 1 && now() - DB.acx < 5 * 864e5; }
function setLite(on) {
  if (on && ON_XC) on = false;
  if (LITE === on) return;
  LITE = on;
  var h = document.documentElement;
  h.className = (h.className || '').replace(/(^|\s)(gate|lite)(?=\s|$)/g, '') + (on ? ' lite' : '');
  if (on && curModal === 'mdLogin') closeModal();
  /* serverlar X CLIENT o'yinchisini taniydi (server plagini xclient_bonus: [X] belgisi, bonuslar). Faqat launcher bilan o'ynayotganlarda */
  try { cmd('setinfo _xc ' + (on ? '""' : '1')); } catch (e) {}
}
document.documentElement.className += ' gate';
setTimeout(function () { if (LITE === null) setLite(false); }, 8000);
function openPromo() {
  var h = '<div class="xpro"><img src="logo_big.png" alt=""><b>' + esc(T('lp_t')) + '</b><p>' + esc(T('lp_s')) + '</p><ul>';
  each(['lp_1', 'lp_2', 'lp_3', 'lp_4', 'lp_5', 'lp_6'], function (k) { h += '<li>' + esc(T(k)) + '</li>'; });
  CLK.promo_open = (CLK.promo_open || 0) + 1; CLK_N++;           // admin > Tugmalar: NextClient o'yinchilari banner ochgan
  openSide('promo', 'X CLIENT', h + '</ul><div class="avurl"><input class="ipin" readonly value="cssborka.uz/xclient"><a class="cpy" data-copyip="https://cssborka.uz/xclient">' + esc(T('ip_copy')) + '</a></div>' +
    '<small class="mut">' + esc(T('lp_how')) + '</small></div>');
}
/* O'yin X CLIENT'siz (cstrike.exe / hl.exe dan) ochilganmi: launcher har ishga tushganda saytga "hello" yuboradi.
 * O'yin jarayonidagi birinchi menyu yuklanishida (sessionStorage) launcher 15 daqiqadan ko'p oldin ochilgan bo'lsa - o'yin launchersiz ochilgan */
function launchCheck(age) {
  var first = true;
  try { first = !sessionStorage.getItem('xcs'); sessionStorage.setItem('xcs', '1'); } catch (e) { return; }
  if (!first || age < 900 || CONNECTED || DEMO_PLAY) return;
  if (DB.nlw && now() - DB.nlw < 3 * 3600 * 1000) return;          // ko'pi 3 soatda bir marta
  if (curModal) return setTimeout(function () { launchCheckShow(); }, 20000);
  launchCheckShow();
}
function launchCheckShow() {
  if (curModal || CONNECTED) return;
  DB.nlw = now(); persist(); CLK.nolaunch = (CLK.nolaunch || 0) + 1; CLK_N++;   // admin > Tugmalar: necha marta launchersiz ochilgan
  openSide('nolaunch', T('nl_t'), '<div class="nlw"><b>' + esc(T('nl_t')) + '</b><p>' + esc(T('nl_d')) + '</p><ul><li>' + esc(T('nl_1')) + '</li><li>' + esc(T('nl_2')) + '</li></ul><p class="mut">' + esc(T('nl_how')) + '</p></div>');
}
function loadOpts() {
  // id berilmasa server shu IP dan oxirgi ulangan XClient.exe ni topadi
  if (!PCID && DB.pcid && DB.pck) PCID = DB.pcid;
  api('opts', PCID ? { d: PCID } : {}, function (r) {
    if (!r.ok && r.err === 'nolaunch' && PCID) { PCID = ''; DB.pcid = DB.pck = ''; persist(); return loadOpts(); }   // kalit eskirgan
    if (r.ok) setLite(!r.o);                     // o: null - bu kompyuterda XCLauncher.exe ochilmagan (oddiy boost-top launcheri)
    if (!r.ok || !r.o) return;
    if (r.d) PCID = r.d;
    if (r.k) { DB.pcid = r.d; DB.pck = r.k; persist(); }
    for (var k in r.o) if (r.o.hasOwnProperty(k) && OPTS.hasOwnProperty(k)) OPTS[k] = r.o[k];
    if (typeof OPTS.shots === 'object') OPTS.shots = 0;   // eski server: F11 ro'yxati 'shots' (galereya belgisi) ga tushgan edi
    if (r.o.f11) OPTS.f11 = r.o.f11;
    if (r.o.ver && !qparam('v')) { VERSION = r.o.ver; renderBar(); }
    if (r.o.lver) { LVER = r.o.lver; updCard(); }
    if (r.o.age != null) setTimeout(function () { launchCheck(r.o.age); }, 3500);
    if (r.o.cachemb != null && !qparam('c')) CACHE_MB = r.o.cachemb;
    if (r.o.scr) OPTS.scr = r.o.scr;                   // monitor o'lchami (launcher)
    if (r.o.safe && !SAFE) { SAFE = 1; fxClass(); sparks(); }
    if (r.o.cpuhi && now() / 1000 - r.o.cpuhi < 3 * 86400 && DB.cpuhi !== r.o.cpuhi && !(S && S.lowgfx)) { var ch = r.o.cpuhi; setTimeout(function () { cpuHiOffer(ch, 0); }, 9000); }   // oxirgi o'yinda kompyuter kuchi yetmadi
    if (r.o.hw) { HW = r.o.hw; if (r.o.os) HW.os = r.o.os; if (DB.fx == null && hwClass() === 'weak') { DB.fx = 0; persist(); sparks(); api('prob', { k: 'menu_lite', d: PCID || '' }, function () {}); } }   // kuchsiz kompyuter - yengil menyu
    heroLoad();
    if (!DB.lang && /^(ru|uz|en)$/.test(r.o.ilang || '')) { DB.lang = r.o.ilang; setLang(DB.lang); persist(); }   // o'rnatishda tanlangan til
    var rt = OPTS.rsk ? 1 : 0;                   // radar foni launcherda (1.0.91+); cl_radartype unga mos bo'lsin (qora fonlar - to'liq radar)
    if (S && S.radar !== rt && verGE(r.o.ver, '1.0.91') && !radarNC()) { S.radar = rt; DB.set = S; persist(); cmd('cl_radartype ' + rt); }
    stateSync();
    setTimeout(tuneHints, 4000);
    if (curModal === 'mdSettings' && (setTab === 'pro' || setTab === 'cont')) showSetTab(setTab);
    if (curModal === 'mdSettings' && (setTab === 'system' || setTab === 'video')) showSetTab(setTab);
  });
}
/* Menyu holati kompyuter (XCLauncher.exe) bo'yicha saytda ham saqlanadi: o'yin brauzeri localStorage ni har doim ham
 * saqlab qolmaydi (o'yin yopilganda yo'qoladi) - kirish ("Eslab qolish"), sevimlilar, tarix, tugmalar, til qayta tiklanadi. */
var STATE_SYNCED = false, STATE_TM = 0;
function stateData() {
  var h = [];
  each((DB.hist || []).slice(0, 50), function (x) { h.push({ ip: x.ip, name: x.name, map: x.map, t: x.t, d: x.d, k: x.k, x: x.x }); });
  return { token: DB.forget ? '' : (DB.token || ''), fav: DB.fav.slice(0, 100), hist: h, binds: DB.binds || null, binds2: DB.binds2 || null, lang: DB.lang || '', wnSeen: DB.wnSeen || '', dnd: DB.dnd ? 1 : 0, acx: DB.acx || 0, acn: DB.acn || 0, pxx: DB.pxx || 0, tour: DB.tour ? 1 : 0, rgo: DB.rgo || 0, rgn: DB.rgn || 0, demos: (DB.demos || []).slice(0, 40) };
}
function statePush() {
  if (!PCID || !STATE_SYNCED) return;
  clearTimeout(STATE_TM);
  STATE_TM = setTimeout(function () { api('dstate', { d: PCID, set: JSON.stringify(stateData()) }, function () {}); }, 1500);
}
function stateSync() {
  if (!PCID || STATE_SYNCED) return;
  api('dstate', { d: PCID }, function (r) {
    if (!r.ok) return;
    var st = r.st || {}, ch = false;
    each(st.fav || [], function (ip) { if (DB.fav.indexOf(ip) < 0) { DB.fav.push(ip); ch = true; } });
    if ((!DB.hist || !DB.hist.length) && st.hist && st.hist.length) { DB.hist = st.hist; ch = true; }
    if (!DB.binds && st.binds) { DB.binds = st.binds; DB.binds2 = st.binds2 || null; loadBinds(); applyBinds(); ch = true; }
    if (!DB.lang && st.lang) { DB.lang = st.lang; setLang(st.lang); ch = true; }
    if (!DB.wnSeen && st.wnSeen) { DB.wnSeen = st.wnSeen; ch = true; }
    if (DB.dnd == null && st.dnd) { DB.dnd = 1; ch = true; }
    if (st.acx && (!DB.acx || st.acx > DB.acx)) { DB.acx = st.acx; ch = true; }
    if ((st.acn | 0) > (DB.acn | 0)) { DB.acn = st.acn | 0; ch = true; }
    if (!DB.pxx && st.pxx) { DB.pxx = st.pxx; ch = true; }
    if (!DB.tour && st.tour) { DB.tour = 1; ch = true; }
    if (!DB.rgo && st.rgo) { DB.rgo = st.rgo; DB.rgn = st.rgn || 0; ch = true; }
    if ((!DB.demos || !DB.demos.length) && st.demos && st.demos.length) { DB.demos = st.demos; ch = true; }   // demolar ro'yxati qayta kirganda yo'qolmasin
    STATE_SYNCED = true;
    if (!DB.token && st.token) {
      DB.token = st.token;
      api('me', {}, function (m) {
        if (m.ok) { setMe(m.me); loadFriends(); pingPresence(); }
        else if (m.err === 'auth') DB.token = '';
        persist();
      });
    }
    if (ch) { persist(); renderSoon(); } else statePush();
  });
}
/* IP nusxalash: o'yin brauzerida (CEF1) clipboard API yo'q - maydonni belgilab execCommand('copy');
 * bo'lmasa IP belgilangan holda qoladi va "Ctrl+C" deb aytamiz */
function copyIp(ip, inp) {
  var ok = false;
  try {
    if (!inp) { inp = document.createElement('input'); inp.value = ip; inp.style.cssText = 'position:absolute;left:-999px;top:0'; document.body.appendChild(inp); }
    inp.focus(); inp.select();
    ok = document.execCommand && document.execCommand('copy');
  } catch (e) { ok = false; }
  toast(ok ? T('ip_copied') + ' ' + ip : T('ip_ctrlc'), 3000);
}
/* launcher qaysi rejimda ochadi: Windows 10/11 + "Avto" o'lcham + o'yinchi o'zi tanlamagan bo'lsa - chegarasiz (launcher 1.0.155+) */
function winEff() { var w = OPTS.win | 0; if (w === 0 && !OPTS.winx && !OPTS.res && HW && /Windows 1[01]/.test(HW.os || '') && verGE(VERSION, '1.0.155')) return 2; return w; }
function saveOpts(msg) {
  if (!PCID) { toast(T('sy_nolaunch'), 4000); return; }
  api('opts_set', { d: PCID, o: JSON.stringify(OPTS) }, function (r) { toast(r.ok ? (msg || T('sy_next')) : (r.msg || 'Xato'), 3500); });
}

/* ============================================================ akkaunt API (xc_api.php) */
var ME = null, FRIENDS = [], WEEK = [];
function api(a, params, cb) {
  var body = 'a=' + encodeURIComponent(a) + '&device=' + DB.device + (DB.token ? '&token=' + DB.token : '') + (params && params.d && params.d === PCID && DB.pck ? '&k=' + DB.pck : '');
  for (var k in params) if (params.hasOwnProperty(k)) body += '&' + k + '=' + encodeURIComponent(params[k]);
  var x;
  try { x = new XMLHttpRequest(); x.open('POST', 'xc_api.php', true); x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded'); }
  catch (e) { if (cb) cb({ ok: false, err: 'net', msg: T('lg_neterr') }); return; }
  var done = false;
  var tm = setTimeout(function () { if (!done) { done = true; try { x.abort(); } catch (e) {} if (cb) cb({ ok: false, err: 'net', msg: T('lg_neterr') }); } }, 12000);
  x.onreadystatechange = function () {
    if (x.readyState !== 4 || done) return;
    done = true; clearTimeout(tm);
    var r = null;
    try { r = JSON.parse(x.responseText); } catch (e) {}
    if (!r) r = { ok: false, err: 'net', msg: T('lg_neterr') };
    if (r.err === 'auth') { DB.token = ''; ME = null; persist(); renderAll(); }
    var sx = r.msg && /^(.*?)\. Masalan: (\S+)$/.exec(r.msg);   // "Bu login band. Masalan: Ali_123" - tarjima + taklif
    if (sx && window.SRVMSG && SRVMSG[sx[1]] && CUR_LANG !== 'uz') { var lj = CUR_LANG === 'en' || LFALL[CUR_LANG] === 'en' ? 1 : 0; r.msg = SRVMSG[sx[1]][lj] + (lj ? '. For example: ' : '. Например: ') + sx[2]; }
    if (r.msg && window.SRVMSG && SRVMSG[r.msg] && CUR_LANG !== 'uz') {   // sayt xabarlari o'zbekcha - tanlangan tilga
      var li = CUR_LANG === 'en' || LFALL[CUR_LANG] === 'en' ? 1 : 0;
      r.msg = SRVMSG[r.msg][li];
    }
    if (cb) cb(r);
  };
  try { x.send(body); } catch (e) { done = true; clearTimeout(tm); if (cb) cb({ ok: false, err: 'net', msg: T('lg_neterr') }); }
}
function setMe(me) { var was = !!ME; ME = me; renderAll(); if (me && !was) { setTimeout(pollNotif, 3000); setTimeout(statBackfill, 5000); setTimeout(claimDaily, 6000); setTimeout(misCheck, 9000); setTimeout(function () { tgAsk(0); }, 16000); if (S && S.rtag) setTimeout(function () { if (!PW_NAME) cmd('name ' + q(fullName(S))); }, 1500); } }
/* kunlik kirish mukofoti: har kuni birinchi kirishda o'zi olinadi (ketma-ket kunlar - ko'proq XP, 7-kuni +200) */
function claimDaily() {
  if (!ME || LITE || !feat('daily')) return;
  api('daily', {}, function (r) {
    if (!r.ok || !r.got || !ME) return;
    ME.xp = r.xp; ME.level = r.level; ME.lvlxp = r.lvlxp; renderBar();
    if (r.newach && r.newach.length) { ME.ach = (ME.ach || []).concat(r.newach); setTimeout(function () { achToast(r.newach); }, 7500); }
    if (r.chests != null) { ME.chests = r.chests; renderBar(); }
    DB.dstk = { s: r.streak, t: now() }; persist();
    var cal = !DB.dnd && !CONNECTED && !curModal;
    if (cal) setTimeout(function () { if (!curModal && !CONNECTED) { dailyCal(r.streak, r.got); sfx('save'); } else toast(T('dl_ok').replace('{n}', r.got).replace('{d}', r.streak), 7000); }, 1500);
    else if (r.yday && !DB.dnd) setTimeout(function () { if (!curModal) showYesterday(r.yday); }, 2500);
    if (!cal && !DB.dnd) { toast(T('dl_ok').replace('{n}', r.got).replace('{d}', r.streak), 7000); sfx('save'); }
    if (r.d2) setTimeout(function () { toast(T('d2_got'), 9000); sfx('save'); }, 8000);
    else if (r.tmr) setTimeout(function () { toast(T('d2_tmr'), 8000); }, 8000);
  });
}
/* kunlik sovg'alar kalendari: 7 kunlik seriya, bugungi olindi, ertangisi ko'rinib turadi - ertaga qaytishga sabab */
function dailyXp(st) { return st % 7 === 0 ? 200 : 20 + 10 * Math.min(5, (st - 1) % 7); }
function dailyCal(st, got) {
  var pos = ((st - 1) % 7) + 1, base = st - pos, h = '';
  for (var i = 1; i <= 7; i++) {
    var d = base + i, cls = i < pos ? 'done' : i === pos ? 'now' : i === pos + 1 ? 'next' : '';
    h += '<div class="dcd ' + cls + (i === 7 ? ' big' : '') + '"><small>' + esc(T('dc_day').replace('{n}', i)) + '</small><b>' + (i === 7 ? ico('gift') : '+' + dailyXp(d)) + '</b><span>' + (i === 7 ? '+200 XP' : 'XP') + '</span>' + (i < pos || i === pos ? '<em>\u2713</em>' : '') + '</div>';
  }
  var nx = dailyXp(st + 1);
  openSide('daily', T('dc_t'), '<div class="dcw"><p>' + esc(T('dc_got').replace('{n}', got).replace('{d}', st)) + '</p><div class="dcr">' + h + '</div>' +
    '<p class="dcn">' + esc(T(pos === 6 ? 'dc_next7' : 'dc_next').replace('{n}', nx)) + '</p><p class="mut" style="font-size:12px">' + esc(T('dc_miss')) + '</p></div>');
}
/* jang statistikasi qo'shilgunga qadar o'ynalgan o'yinlar (shu kompyuter tarixidan) - akkauntga BIR MARTA qo'shiladi */
function statBackfill() {
  if (!ME || ME.bf) return;
  var g = [];
  each((DB.hist || []).slice(0, 100), function (x) { if (x && x.ip && x.t && x !== CUR && (x.k || x.x)) g.push({ t: x.t, ip: x.ip, n: x.name || '', k: x.k || 0, d: x.x || 0, dur: x.d || 0 }); });
  api('stat_bf', { g: JSON.stringify(g) }, function (r) { if (r.ok && ME) { ME.bf = 1; ME.st = r.st; ME.ach = r.ach; achToast(r.newach); renderAll(); } });
}
function afterLogin(r) {
  DB.token = r.token; DB.guest = 0; persist();
  setMe(r.me);
  closeModal();
  // yangi kompyuterda: bulutdagi sozlamalarni olamiz, bo'lmasa shu kompyuterdagisini bulutga yuboramiz
  if (r.me.cloud && (!DB.set || r.me.cloudt > (DB.cloudt || 0))) restoreCloud(r.me.cloud, true);
  else cloudSave(true);
  loadFriends();
}
/* ---- jang statistikasi (akkaunt): shu o'yinning jami kill/o'lim/qurollari yuboriladi, sayt farqini qo'shadi ---- */
var STAT_LAST = '';
/* Zaxira kill hisobi: ba'zi NextClient versiyalarida konsol qatorlari menyuga kelmaydi - killlar 0 bo'lib qolardi
 * (admin: hamma akkauntda k=0). Serverga ulangan paytda 90 s da bir sayt orqali (srvq.php - o'yin dvigateli emas, qotish yo'q)
 * TAB jadvalidagi fragni olamiz: o'sgan qismi kill. Xarita almashsa frag 0 dan boshlanadi - yangi asos */
var SCORE_T = 0;
/* server nikni o'zgartirishi mumkin: "(1)Nik", "[VIP] Nik", "Nik [UZ]", "X | Nik" - asosiy qismi bo'yicha solishtiramiz */
function nameCore(n) { return String(n || '').replace(/^\s*\(\d+\)\s*/, '').replace(/^\s*(\[[^\]]{1,12}\]|\{[^}]{1,12}\}|<[^>]{1,12}>|[^\s|]{1,8}\s*\|)\s*/, '').replace(/\s*(\[[^\]]{1,12}\]|\{[^}]{1,12}\})\s*$/, '').trim().toLowerCase(); }
function isMyName(n) {
  n = String(n || '').trim(); if (!n) return false;
  var c = nameCore(n), nm = myNames();
  for (var i = 0; i < nm.length; i++) if (nm[i] === n || (c && nameCore(nm[i]) === c)) return true;
  return false;
}
var KILL_SAMPLE = [];
function myNames() { var a = []; each([MYNAME, readCvar('name'), PW_NAME || '', S && S.name ? fullName(S) : ''], function (n) { n = String(n || '').trim(); if (n && a.indexOf(n) < 0) a.push(n); }); return a; }
function scoreTick() {
  if (!CONNECTED || !CUR || DEMO_PLAY || CUR.ip !== CONNECTED) return;
  var g = CUR, ip = CONNECTED;
  srvq(ip, function (r) {
    if (!r || !r.ok || !r.players || g !== CUR || CONNECTED !== ip) return;
    var nm = myNames(), me = null;
    each(r.players, function (x) { if (!me && nm.indexOf(String(x.name || '').trim()) >= 0) me = x; });
    if (!me) each(r.players, function (x) { if (!me && isMyName(x.name)) me = x; });   // server nikka prefiks qo'shgan
    if (!me) return;
    var sc = Math.max(0, me.score | 0);
    if (g.sl == null || sc < g.sl) { g.sl = sc; return; }        // birinchi o'lchov yoki xarita almashdi - asos
    g.ks = (g.ks || 0) + (sc - g.sl); g.sl = sc;
    if (g.ks > (g.k || 0)) { g.k = g.ks; persist(); if (typeof duelSync === 'function') duelSync(); }
  });
}
setInterval(function () { if (CONNECTED && now() - SCORE_T > 85000) { SCORE_T = now(); scoreTick(); } }, 15000);
function sendStat(g, done) {
  g = g || CUR;
  if (!ME || !g || !g.t || !g.ip) { if (done) done(); return; }
  var dur = Math.round(((CONNECTED && g === CUR) ? now() - g.t : (g.d || 0) * 1000) / 1000);
  var key = g.t + ':' + (g.k || 0) + ':' + (g.x || 0) + ':' + Math.floor(dur / (done ? 1 : 300));
  if (key === STAT_LAST) { if (done) done(); return; }
  STAT_LAST = key;
  api('stat', { sid: g.t, ip: g.ip, name: g.name || '', map: g.map || '', k: g.k || 0, d: g.x || 0, dur: dur, w: JSON.stringify(g.w || {}), cm: CON_N, ck: CON_K, ks: g.ks || 0, kl: KILL_SAMPLE.join(' || ').slice(0, 300), nm: String(MYNAME || '').slice(0, 40) }, function (r) { if (done) done(); if (r.ok && ME) { ME.st = r.st; ME.ach = r.ach; if (r.xp != null) { ME.xp = r.xp; ME.level = r.level; ME.lvlxp = r.lvlxp; renderBar(); } achToast(r.newach); if (r.rankup) rankUp(r.rankup); } });
}
/* yangi daraja (birinchi marta): katta tabrik, ding ovozi; menyu yopiq bo'lsa - ochilganda ko'rsatiladi */
function rankUp(rk) {
  if (ME) ME.rank = rk;
  var show = function () { openSide('rankup', T('ru_t'), '<div class="rkup"><div class="rkupb">' + rankBadge({ rank: rk }) + '</div><h2>' + esc(T('ru_h').replace('{r}', T('rk_' + rk))) + '</h2><p class="mut">' + esc(T('ru_s')) + '</p><a class="btn red" data-act="stats">' + esc(T('ru_b')) + '</a></div>'); chime(); };
  if (playing() || curModal) { RK_PEND = rk; return; }
  show();
}
var RK_PEND = '';
setInterval(function () { if (RK_PEND && !curModal && !playing()) { var r = RK_PEND; RK_PEND = ''; rankUp(r); } }, 4000);   // o'yin xulosasi yopilgach / menyu ochilganda
function fmtHours(sec) { var h = Math.floor((sec || 0) / 3600), m = Math.floor((sec || 0) % 3600 / 60); return h ? h + T('ks_h') + ' ' + m + T('ks_m') : m + T('ks_m'); }
function kdOf(st) { return st && st.d ? (st.k / st.d).toFixed(2) : String(st && st.k || 0); }
function statBox(st) {
  st = st || {};
  var c = function (v, l) { return '<div><b>' + esc(String(v)) + '</b><span>' + esc(T(l)) + '</span></div>'; };
  return '<div class="stbox">' + c(st.k || 0, 'ks_k') + c(st.d || 0, 'ks_d') + c(kdOf(st), 'ks_kd') + c(st.g || 0, 'ks_g') + '</div>';
}
/* ---- Shaxsiy murabbiy: o'yin tarixidan (oxirgi 300 o'yin) 3 ta aniq maslahat va mos mashqqa bitta bosishda ----
 * headshot % (aim test), eng zaif qurol, eng yomon xarita (granata mashqi), haftalik o'sish, ping/yo'qotish */
function coachTips() {
  var W = {}, M = {}, K = 0, H = 0, X = 0, G = 0, tips = [];
  each(DB.hist || [], function (g) {
    if (!g || !(g.k || g.x) || isLocalAddr(g.ip)) return;
    G++; K += g.k || 0; H += g.h || 0; X += g.x || 0;
    for (var w in g.w || {}) if (g.w.hasOwnProperty(w)) { W[w] = W[w] || { k: 0, h: 0 }; W[w].k += g.w[w]; W[w].h += (g.wh && g.wh[w]) || 0; }
    var mp = g.map || ''; if (mp) { M[mp] = M[mp] || { g: 0, k: 0, x: 0 }; M[mp].g++; M[mp].k += g.k || 0; M[mp].x += g.x || 0; }
  });
  if (G < 5 || K < 20) return [{ t: T('cc_few').replace('{n}', Math.max(0, 5 - G)), a: '' }];
  var hs = Math.round(H * 100 / K);
  if (hs < 30) tips.push({ t: T('cc_hs').replace('{h}', hs), a: 'coach_aim', b: T('cc_baim') });
  var best = null, worst = null;
  for (var w in W) if (W.hasOwnProperty(w) && W[w].k >= 10 && !/knife|grenade|hegren/.test(w)) {
    var r = W[w].h / W[w].k; if (!best || r > best.r) best = { w: w, r: r }; if (!worst || r < worst.r) worst = { w: w, r: r };
  }
  if (best && worst && best.w !== worst.w && best.r - worst.r > 0.12)
    tips.push({ t: T('cc_wpn').replace('{b}', best.w).replace('{bh}', Math.round(best.r * 100)).replace('{w}', worst.w).replace('{wh}', Math.round(worst.r * 100)), a: 'coach_aim', b: T('cc_baim') });
  var wm = null;
  for (var m in M) if (M.hasOwnProperty(m) && M[m].g >= 3) { var kd = M[m].x ? M[m].k / M[m].x : M[m].k; if (!wm || kd < wm.kd) wm = { m: m, kd: kd }; }
  if (wm && wm.kd < 0.85) tips.push({ t: T('cc_map').replace('{m}', wm.m).replace('{kd}', wm.kd.toFixed(2)), a: 'coach_nade', m: wm.m, b: T('cc_bnade') });
  var wk = ME && ME.wkst, ks = []; for (var id in wk || {}) if (wk.hasOwnProperty(id)) ks.push(id); ks.sort();
  if (ks.length >= 2) {
    var a = wk[ks[ks.length - 1]], b = wk[ks[ks.length - 2]], ka = a.d ? a.k / a.d : a.k, kb = b.d ? b.k / b.d : b.k;
    if (a.k >= 10 && b.k >= 10) tips.push({ t: T(ka >= kb ? 'cc_up' : 'cc_down').replace('{a}', ka.toFixed(2)).replace('{b}', kb.toFixed(2)), a: '' });
  }
  if (LASTPERF && (LASTPERF.pm >= 100 || LASTPERF.l >= 5)) tips.push({ t: T('cc_ping').replace('{p}', LASTPERF.pm).replace('{l}', LASTPERF.l), a: 'coach_lag', b: T('cc_blag') });
  if (!tips.length) tips.push({ t: T('cc_good').replace('{h}', hs).replace('{kd}', X ? (K / X).toFixed(2) : K), a: 'coach_aim', b: T('cc_baim') });
  return tips.slice(0, 3);
}
function coachCard() {
  if (!ME) return '';
  var h = '<div class="coach"><div class="cct">' + esc(T('cc_title')) + '</div>';
  each(coachTips(), function (x) { h += '<div class="cci"><p>' + esc(x.t) + '</p>' + (x.a ? '<a class="btn" data-act="' + x.a + '"' + (x.m ? ' data-cmap="' + esc(x.m) + '"' : '') + '>' + esc(x.b) + '</a>' : '') + '</div>'; });
  return h + '</div>';
}
/* ---- Chit haqida xabar: o'yin paytida server o'yinchilari ro'yxatida ⚑. Sabab tanlanadi, demo yozuvi boshlanadi (dalil),
 * xabar saytga ketadi; bitta serverda bitta o'yinchiga 24 soatda 3+ turli o'yinchi shikoyat qilsa - admin Telegram'ga ---- */
var CHEAT_NICK = '';
function cheatPane(nick) {
  CHEAT_NICK = nick; var b = '';
  each(['aim', 'wh', 'speed', 'other'], function (k) { b += '<a class="btn chw" data-chwhy="' + k + '">' + esc(T('ch_' + k)) + '</a>'; });
  openSide('cheat', T('ch_t'), '<div class="chp"><p>' + esc(T('ch_s').replace('{n}', nick)) + '</p><div class="chws">' + b + '</div><p class="mut" style="font-size:12px">' + esc(T('ch_note')) + '</p></div>');
}
function cheatSend(why) {
  if (!CONNECTED || !CHEAT_NICK) return closeModal();
  if (!REC && S) { REC = demoName(); cmd('record ' + REC); var nm = REC; setTimeout(function () { if (REC === nm) demoAdd(nm); }, 8000); }   // dalil: demo yozuvi (hali yozilmayotgan bo'lsa)
  api('cheat_rep', { ip: CONNECTED, nick: CHEAT_NICK, why: why, demo: REC || '' }, function (r) {
    closeModal(); toast(r.ok ? T('ch_ok').replace('{n}', r.n || 1) : (r.msg || 'Xato'), 7000);
  });
}
function openStats() {
  var st = (ME && ME.st) || {}, w = '', sv = '';
  for (var wn in st.wpn || {}) if (st.wpn.hasOwnProperty(wn)) w += '<div class="kv"><span>' + esc(wn) + '</span><b>' + st.wpn[wn] + '</b></div>';
  for (var ip in st.srv || {}) if (st.srv.hasOwnProperty(ip)) { var x = st.srv[ip]; sv += '<div class="kv"><span>' + esc(x.n || ip) + '</span><b>' + x.k + ' / ' + x.d + '</b></div>'; }
  var h = statBox(st) +
    '<div class="stmore"><div class="kv"><span>' + esc(T('ks_best')) + '</span><b>' + (st.best || 0) + '</b></div><div class="kv"><span>' + esc(T('ks_time')) + '</span><b>' + esc(fmtHours(st.t)) + '</b></div>' +
    '<div class="kv"><span>' + esc(T('ks_week')) + '</span><b>' + (st.wk || 0) + '</b></div></div>' +
    '<div class="ph2 m">' + esc(T('ac_title')) + ' (' + ((ME && ME.ach) || []).length + '/' + ACH.length + ')</div>' + achBadges(ME && ME.ach, true) +
    '<div class="ph2 m">' + esc(T('ks_wpn')) + '</div>' + (w || '<div class="mut">' + esc(T('ks_none')) + '</div>') +
    '<div class="ph2 m">' + esc(T('ks_srv')) + '</div>' + (sv || '<div class="mut">' + esc(T('ks_none')) + '</div>') +
    '<div class="ph2 m">' + esc(T('ks_top')) + '</div><div id="topkList" class="mut">...</div><small class="mut">' + esc(T('ks_note')) + '</small>';
  h = rankCard(ME) + coachCard() + statBox(st) + wkChart(ME && ME.wkst) + statDeep() + h.slice(statBox(st).length) + myGames() + '<div class="ph2 m">' + esc(T('rk_top')) + '</div><div id="rpTop" class="mut">...</div>';
  openSide('stats', T('ks_title'), h);
  api('toprp', {}, function (r) {
    var el = $('rpTop'); if (!el) return; var t = '';
    each((r.ok && r.top) || [], function (x, i) { t += '<div class="kv"><span>' + (i + 1) + '. ' + nickHtml(x) + ' ' + rankBadge(x) + '</span><b>' + x.rp + ' RP</b></div>'; });
    el.innerHTML = t || esc(T('ks_none')); el.className = '';
  });
  api('topk', {}, function (r) {
    var el = $('topkList'); if (!el) return;
    var t = '';
    each((r.ok && r.top) || [], function (x, i) { t += '<div class="kv"><span>' + (i + 1) + '. ' + esc(x.name) + (x.vip ? ' <em class="vipb">VIP</em>' : '') + '</span><b>' + x.k + ' kill · K/D ' + x.kd + '</b></div>'; });
    el.innerHTML = t || esc(T('ks_none')); el.className = '';
  });
}
/* batafsil (shu kompyuterdagi oxirgi 300 o'yin): sevimli qurollar + headshot %, eng zo'r xaritalar, eng yaxshi o'yin */
function statDeep() {
  var W = {}, M = {}, best = null, K = 0, H = 0;
  each(DB.hist || [], function (g) {
    if (!g || !(g.k || g.x)) return;
    K += g.k || 0; H += g.h || 0;
    for (var w in g.w || {}) if (g.w.hasOwnProperty(w)) { W[w] = W[w] || { k: 0, h: 0 }; W[w].k += g.w[w]; W[w].h += (g.wh && g.wh[w]) || 0; }
    var mp = g.map || ''; if (mp) { M[mp] = M[mp] || { g: 0, k: 0, x: 0 }; M[mp].g++; M[mp].k += g.k || 0; M[mp].x += g.x || 0; }
    if (!best || (g.k || 0) > (best.k || 0)) best = g;
  });
  if (!K) return '';
  var wl = []; for (var w in W) if (W.hasOwnProperty(w)) wl.push([w, W[w]]);
  wl.sort(function (a, b) { return b[1].k - a[1].k; }); wl = wl.slice(0, 6);
  var mx = wl.length ? wl[0][1].k : 1, h = '<div class="ph2 m">' + esc(T('sd_title')) + '</div><div class="sdeep">';
  h += '<div class="kv"><span>' + esc(T('sd_hs')) + '</span><b>' + Math.round(H * 100 / K) + '%</b></div>';
  if (best) h += '<div class="kv"><span>' + esc(T('sd_best')) + '</span><b>' + (best.k || 0) + ' kill \u00b7 ' + esc(best.map || '') + ' \u00b7 ' + esc(fmtTime(best.t)) + '</b></div>';
  h += '<div class="ph3">' + esc(T('sd_wpn')) + '</div>';
  each(wl, function (x) {
    var hs = x[1].h ? ' \u00b7 HS ' + Math.round(x[1].h * 100 / x[1].k) + '%' : '';
    h += '<div class="sdw"><span>' + esc(x[0]) + '</span><i style="width:' + Math.max(4, Math.round(220 * x[1].k / mx)) + 'px"></i><b>' + x[1].k + hs + '</b></div>';
  });
  var ml = []; for (var m in M) if (M.hasOwnProperty(m) && M[m].g >= 2) ml.push([m, M[m], M[m].x ? M[m].k / M[m].x : M[m].k]);
  ml.sort(function (a, b) { return b[2] - a[2]; }); ml = ml.slice(0, 5);
  if (ml.length) {
    h += '<div class="ph3">' + esc(T('sd_maps')) + '</div>';
    each(ml, function (x, i) { h += '<div class="kv"><span>' + (i + 1) + '. ' + esc(x[0]) + ' <small class="mut">(' + x[1].g + ' ' + esc(T('sd_games')) + ')</small></span><b>K/D ' + x[2].toFixed(2) + '</b></div>'; });
  }
  return h + '</div>';
}
/* haftalar bo'yicha grafik: ustun - kill, ostida K/D (oxirgi 12 hafta) */
function wkChart(ws) {
  var keys = []; for (var k in ws || {}) if (ws.hasOwnProperty(k)) keys.push(k);
  keys.sort(); if (!keys.length) return '';
  var mx = 1; each(keys, function (k) { mx = Math.max(mx, ws[k].k); });
  var h = '<div class="ph2 m">' + esc(T('wk_title')) + '</div><div class="wkc">';
  each(keys, function (k, i) {
    var x = ws[k], kd = x.d ? (x.k / x.d).toFixed(2) : String(x.k), prev = i ? ws[keys[i - 1]] : null, pk = prev ? (prev.d ? prev.k / prev.d : prev.k) : null, ck = x.d ? x.k / x.d : x.k;
    h += '<div class="wkb"><em>' + x.k + '</em><i style="height:' + Math.max(3, Math.round(110 * x.k / mx)) + 'px"></i><b class="' + (pk === null ? '' : ck >= pk ? 'up' : 'dn') + '">' + kd + '</b><small>' + esc(k.replace(/^\d{4}-/, '')) + '-' + esc(T('wk_w')) + '</small></div>';
  });
  return h + '</div><small class="mut">' + esc(T('wk_note')) + '</small>';
}
/* oxirgi o'yinlar: har o'yin - sana, server, xarita, vaqt, kill/o'lim */
function myGames() {
  var l = (DB.hist || []).slice(0, 30); if (!l.length) return '';
  var h = '<div class="ph2 m">' + esc(T('mg_title')) + '</div><table class="mgt"><tr><th>' + esc(T('mg_date')) + '</th><th>' + esc(T('mg_srv')) + '</th><th>' + esc(T('mg_map')) + '</th><th>' + esc(T('mg_time')) + '</th><th>K</th><th>D</th><th>K/D</th></tr>';
  each(l, function (x) {
    var k = x.k || 0, d = x.x || 0;
    h += '<tr><td>' + esc(fmtTime(x.t)) + '</td><td data-ip="' + esc(x.ip) + '" class="lnk">' + esc(x.name || x.ip) + '</td><td>' + esc(x.map || '\u2014') + '</td><td>' + esc(fmtHours(x.d || 0)) + '</td><td><b>' + k + '</b></td><td>' + d + '</td><td class="' + (d && k / d >= 1 ? 'gr' : '') + '">' + (d ? (k / d).toFixed(2) : k) + '</td></tr>';
  });
  return h + '</table>';
}
/* ---- do'st bilan solishtirish ---- */
function openCompare(login) {
  var f = null; each(FRIENDS, function (x) { if (x.login === login) f = x; });
  if (!f || !ME) return;
  var a = ME.st || {}, b = f.st || {};
  var rows = [['ks_k', a.k || 0, b.k || 0], ['ks_d', a.d || 0, b.d || 0, 1], ['ks_kd', +kdOf(a), +kdOf(b)], ['ks_g', a.g || 0, b.g || 0],
    ['ks_best', a.best || 0, b.best || 0], ['ks_week', a.wk || 0, b.wk || 0], ['ks_time', a.t || 0, b.t || 0], ['cmp_lvl', ME.level || 1, f.level || 1],
    ['ac_title', (ME.ach || []).length, (f.ach || []).length]];
  var me = 0, him = 0, h = '<div class="cmp"><div class="cmh"><b>' + crown(ME) + esc(ME.name) + '</b><span>VS</span><b>' + crown(f) + esc(f.name) + '</b></div>';
  each(rows, function (r) {
    var lowWin = r[3], x = r[1], y = r[2], wx = lowWin ? x < y : x > y, wy = lowWin ? y < x : y > x;
    if (wx) me++; if (wy) him++;
    var fmt = function (v) { return r[0] === 'ks_time' ? fmtHours(v) : String(v); };
    h += '<div class="cmr"><span class="' + (wx ? 'w' : '') + '">' + esc(fmt(x)) + '</span><em>' + esc(T(r[0])) + '</em><span class="' + (wy ? 'w' : '') + '">' + esc(fmt(y)) + '</span></div>';
  });
  h += '<div class="cmres">' + esc(me > him ? T('cmp_win') : me < him ? T('cmp_lose').replace('{n}', f.name) : T('cmp_draw')) + ' (' + me + ':' + him + ')</div></div>';
  openSide('cmp', T('cmp_title'), h);
}
/* ---- klan ---- */
var CLAN = null;
function openClan() {
  if (!ME) return openLogin();
  api('clan_info', {}, function (r) { if (r.ok) { CLAN = r.clan; ME.clan = r.clan ? { id: r.clan.id, tag: r.clan.tag, name: r.clan.name } : null; } renderClan(); });
  renderClan();
}
function renderClan() {
  var h = '';
  if (!CLAN) {
    h = '<div class="empty" style="padding:10px 0 16px">' + esc(T('cl_none')) + '</div><a class="btn red" data-act="clancreate">' + esc(T('cl_create')) + '</a> <a class="btn" data-act="clanjoin">' + esc(T('cl_join')) + '</a>';
  } else {
    h = '<div class="clh"><b>[' + esc(CLAN.tag) + '] ' + esc(CLAN.name) + '</b><small>' + esc(T('cl_week').replace('{k}', CLAN.wk)) + ' \u00b7 ' + CLAN.members.length + '/10</small></div>' +
      '<div class="ph2 m">' + esc(T('cl_code')) + '</div><div class="avurl"><input class="ipin" readonly value="' + esc(CLAN.code) + '"><a class="cpy" data-copyip="' + esc(CLAN.code) + '">' + esc(T('ip_copy')) + '</a></div>' +
      '<div class="ph2 m">' + esc(T('cl_members')) + '</div>';
    each(CLAN.members, function (m) {
      h += '<div class="tr" style="cursor:default">' + frAv(m) + '<div class="nm">' + (m.login === CLAN.owner ? ico('flag') + ' ' : '') + crown(m) + esc(m.name) + '</div><div class="mt">' + m.wk + ' kill \u00b7 K/D ' + kdOf(m.st) + '</div>' +
        (CLAN.boss && m.login !== CLAN.owner ? '<div class="fra"><a data-clkick="' + esc(m.login) + '">' + esc(T('cl_kick')) + '</a></div>' : '') + '</div>';
    });
    h += '<a class="btn out" data-act="clanleave" style="margin-top:10px">' + esc(T('cl_leave')) + '</a>';
  }
  h += '<div class="ph2 m">' + esc(T('cl_top')) + '</div><div id="clTop" class="mut">...</div>';
  openSide('clan', T('cl_title'), h);
  api('clan_top', {}, function (r) {
    var el = $('clTop'); if (!el) return; var t = '';
    each((r.ok && r.top) || [], function (c, i) { t += '<div class="kv"><span>' + (i + 1) + '. [' + esc(c.tag) + '] ' + esc(c.name) + ' <small class="mut">' + c.n + '</small></span><b>' + c.k + ' kill</b></div>'; });
    el.innerHTML = t || esc(T('ks_none')); el.className = '';
  });
}
function clanCall(a, p) { api(a, p || {}, function (r) { if (!r.ok) return toast(r.msg || 'Xato'); CLAN = r.clan; ME.clan = r.clan ? { id: r.clan.id, tag: r.clan.tag, name: r.clan.name } : null; renderClan(); }); }
/* ---- taklif kodi va ulashiladigan profil kartasi ---- */
function refMsg() { return T('rf_text').replace('{c}', ME ? ME.login : ''); }
function refBtn(cls) { return ME ? '<a class="btn ' + (cls || '') + '" data-act="ref">' + ico('gift') + ' ' + esc(T('rf_cta')) + '</a>' : ''; }
function openRef() {
  if (!ME) return openLogin();
  var url = 'mmb.boost-top.com/u.php?u=' + String(ME.login).toLowerCase();
  var h = '<div class="ph2">' + esc(T('rf_code')) + '</div><div class="avurl"><input class="ipin" readonly value="' + esc(ME.login) + '"><a class="cpy" data-copyip="' + esc(ME.login) + '">' + esc(T('ip_copy')) + '</a></div>' +
    '<div class="mut small" style="margin:6px 0 14px">' + esc(T('rf_how')) + '</div>' +
    '<div class="ph2 m">' + esc(T('rf_msg')) + '</div><div class="avurl"><input class="ipin" readonly value="' + esc(refMsg()) + '"><a class="cpy" data-copyip="' + esc(refMsg()) + '">' + esc(T('ip_copy')) + '</a></div>' +
    '<div class="mut small" style="margin:6px 0 14px">' + esc(T('rf_msg2')) + '</div>' +
    '<div class="ph2 m">' + esc(T('rf_card')) + '</div><div class="avurl"><input class="ipin" readonly value="' + esc(url) + '"><a class="cpy" data-copyip="' + esc(url) + '">' + esc(T('ip_copy')) + '</a></div>' +
    '<div class="mut small" style="margin:6px 0 14px">' + esc(T('rf_card2')) + '</div>' +
    '<div class="kv"><span>' + esc(T('rf_count')) + '</span><b>' + (ME.refs || 0) + '</b></div>';
  if (!ME.refby && ME.created && now() / 1000 - ME.created < 7 * 86400) h += '<a class="btn red" data-act="refset" style="margin-top:14px">' + esc(T('rf_enter')) + '</a>';
  else if (ME.refby) h += '<div class="kv"><span>' + esc(T('rf_by')) + '</span><b>' + esc(ME.refby) + '</b></div>';
  openSide('ref', T('rf_title'), h);
}
function histCompact(list, n) {                // tarix: akkauntga oxirgi 50 ta o'yin (boshqa kompyuterda ham chiqadi)
  var h = [];
  each((list || []).slice(0, n), function (x) { if (x && x.ip) h.push({ ip: x.ip, name: x.name, map: x.map, t: x.t, d: x.d, k: x.k, x: x.x }); });
  return h;
}
function cloudData() { return { set: DB.set, binds: DB.binds, binds2: DB.binds2, fav: DB.fav, lang: DB.lang, hist: histCompact(DB.hist, 50), pw: DB.pw || [], theme: DB.theme || '', day: DB.day || 0, look: { bgs: DB.bgs || '', ptc: DB.ptc || '', fs: DB.fs || 1, hol: DB.hol === 0 ? 0 : 1, mtrack: DB.mtrack || '' } }; }
function mergeHist(add) {                      // ikki kompyuter tarixini birlashtirish: bir xil o'yin (ip + vaqt) bir marta
  var seen = {}, out = [];
  each((DB.hist || []).concat(add || []), function (x) { var k = x.ip + '|' + Math.round((x.t || 0) / 60000); if (!seen[k]) { seen[k] = 1; out.push(x); } });
  out.sort(function (a, b) { return (b.t || 0) - (a.t || 0); });
  DB.hist = out.slice(0, 300);
}
var cloudTm = 0;
function cloudSave(force) {
  if (!ME || (!DB.autosave && !force)) return;
  clearTimeout(cloudTm);
  cloudTm = setTimeout(function () {
    api('save', { cloud: JSON.stringify(cloudData()) }, function (r) {
      if (!r.ok || !ME) return;
      ME.cloudt = r.cloudt; ME.devices = r.devices; DB.cloudt = r.cloudt; persist(); renderBar();
      if (curModal === 'mdSettings' && setTab === 'account') showSetTab('account');
    });
  }, force ? 0 : 1500);
}
function restoreCloud(c, silent) {
  if (!c) return;
  if (c.set) { DB.set = c.set; loadSettings(); applySettings(S); }
  if (c.binds) { DB.binds = c.binds; if (c.binds2) DB.binds2 = c.binds2; loadBinds(); applyBinds(); }
  if (c.fav && c.fav.length) each(c.fav, function (ip) { if (DB.fav.indexOf(ip) < 0) DB.fav.push(ip); });
  if (c.lang) { DB.lang = c.lang; setLang(c.lang); }
  if (c.hist && c.hist.length) mergeHist(c.hist);
  if (c.pw && c.pw.length) DB.pw = c.pw;
  if (c.look) { DB.bgs = c.look.bgs; DB.ptc = c.look.ptc; DB.fs = c.look.fs || 1; DB.hol = c.look.hol; DB.mtrack = c.look.mtrack; applyBg(); }
  if ((c.theme && c.theme !== DB.theme) || (c.day != null && c.day !== (DB.day || 0))) { if (c.theme) DB.theme = c.theme; if (c.day != null) DB.day = c.day; applyTheme(DB.theme || 'red'); }
  DB.cloudt = ME ? ME.cloudt : 0; persist();
  if (!silent) toast(T('a_restored'));
  renderAll();
}
function loadFriends() {
  if (!ME) { FRIENDS = []; renderHome(); return; }
  api('friends', {}, function (r) {
    if (!r.ok) return;
    var before = {};
    each(FRIENDS, function (f) { before[f.login] = f.server; });
    FRIENDS = r.friends || []; FR_REQ = r.req || []; FR_SENT = r.sent || [];
    each(FRIENDS, function (f) {                                   // do'st sevimli serverga kirdi
      if (f.server && before[f.login] !== undefined && before[f.login] !== f.server && f.server !== CONNECTED && DB.notifyFr !== 0 && !DB.dnd)
        toastAct(f.name + T('fr_joined') + (srv(f.server).name || f.server) + ' \u2014 ' + T('fr_joinq'), 'data-ip', f.server, 9000);
      if (f.server) query(f.server);
    });
    renderHome();
    if (curModal === 'mdServers' && srvTab === 'friends') renderServers();
    if (curModal === 'mdSide' && sideMode === 'friends') openFriends();
    frBadge();
  });
}
/* bosh menyu: "Hafta qotillari" TOP-3 (jang statistikasidan) + o'tgan hafta chempioni */
var CHAMP = null;
function loadWeek() { api('topk', {}, function (r) { if (r.ok) { WEEK = r.top || []; CHAMP = r.champ || null; renderHome(); } }); }
function crown(u) { return (u && (u.champ || (CHAMP && CHAMP.login && u.login && CHAMP.login === String(u.login).toLowerCase()))) ? '<span class="crown" title="' + esc(T('chp_title')) + '">\u265b</span>' : ''; }
/* ---- yutuqlar ---- */
var ACH = [['k100', ico('swords')], ['k1000', ico('swords')], ['k5000', ico('swords')], ['best30', '\u2605'], ['g100', '\u25b6'], ['t10h', ico('clock')], ['t50h', ico('clock')],
  ['awp100', '\u25ce'], ['ak500', '\u25ce'], ['knife10', '\u2020'], ['deagle100', '\u25ce'], ['fr5', '\u263a'], ['ref3', '\u2709'], ['champ', '\u265b'], ['clan', ico('flag')],
  ['k10000', ico('swords')], ['best50', '\u2605'], ['g500', '\u25b6'], ['t100h', ico('clock')], ['fr20', '\u263a'], ['streak7', '\u2600'], ['srv10', '\u25ce'], ['wall10', '\u270e']];
function achBadges(list, all) {
  var h = '';
  each(ACH, function (a) {
    var got = (list || []).indexOf(a[0]) >= 0;
    if (!got && !all) return;
    h += '<span class="ach' + (got ? ' on' : '') + '" title="' + esc(T('ac_' + a[0] + '_d')) + '"><i>' + a[1] + '</i>' + esc(T('ac_' + a[0])) + '</span>';
  });
  return h ? '<div class="achs">' + h + '</div>' : '';
}
function achToast(ids) { each(ids || [], function (id, i) { setTimeout(function () { toast('\u2605 ' + T('ac_new') + ': ' + T('ac_' + id) + ' (+100 XP)', 5000); sfx('save'); }, 600 + i * 5200); }); }
/* do'stdan taklif: "X sizni serverga chaqiryapti" -> Kirish */
function showInvite(iv) {
  var ip = normIp(iv.ip); if (!ip || ip === CONNECTED) return;
  if ($('mdAsk') && /(^|\s)on(\s|$)/.test($('mdAsk').className)) return setTimeout(function () {
    if (DB.dnd || !ME || (iv.t && now() / 1000 - iv.t > 600)) return;   // kutib turganda eskirgan taklif chiqmasin
    showInvite(iv);
  }, 5000);   // ochiq so'rov (parol, nom...) ustiga yozmaymiz
  var s = srv(ip); query(ip);
  ask(T('iv_title').replace('{n}', iv.from || iv.login).replace('{s}', s.name || ip), function () { closeModal(); connect(ip); }, false, false, true);
}
function pingPresence() {
  if (!ME) return;
  var s = CONNECTED ? srv(CONNECTED) : null;
  api('ping', { server: CONNECTED || '', map: (s && s.map) || '' }, function (r) {
    if (r.ok && ME) { ME.xp = r.xp; ME.level = r.level; ME.lvlxp = r.lvlxp; renderBar(); }
    if (r.ok && r.inv && r.inv.length && !DB.dnd) showInvite(r.inv[r.inv.length - 1]);
    if (r.ok && r.msgs && r.msgs.length) showAdminMsgs(r.msgs);
  });
}

/* ============================================================ serverlar */
var PINNED = ['157.22.130.26:27015'];       // X CLIENT o'z serverlari
var SRV = {}, MASTER = [], TOP = [];
var queue = [], running = 0, MAXQ = 12;
/* o'yin ustida (ESC) server so'rovlari o'yin oqimida bajariladi - bir vaqtda 12 ta so'rov kuchsiz kompyuterda qotishga sabab bo'lardi */
function qmax() { return !CONNECTED && !localGame() ? MAXQ : (DB.fx === 0 || (HW && hwClass() === 'weak')) ? 2 : 4; }
function srv(ip) { if (!SRV[ip]) SRV[ip] = { ip: ip }; return SRV[ip]; }
function query(ip, force) {
  if (!ip) return;
  // serverda o'ynayotganda orqa fonda so'rov yubormaymiz: bitta IP'dan ham o'ynash, ham serverlarni tinmay so'rash
  // himoyalar (DProto/ReChecker) nazarida "FakePlayers" kabi ko'rinadi. Ulangan serverning o'zini umuman so'ramaymiz.
  if (CONNECTED && normIp(ip) === CONNECTED) return queryViaSite(ip, force);   // o'zimiz o'ynayotgan server - faqat sayt orqali (o'yinchi IP'sidan so'rov ketmaydi)
  if (CONNECTED && !(force || (curModal === 'mdServers' && uiShown()))) return;
  var s = srv(ip);
  if (!force && s.ts && now() - s.ts < 20000) return;
  if (s.q) return;
  s.q = 1; queue.push(ip); pump();
}
function queryViaSite(ip, force) {
  var s = srv(ip);
  if (s.q || (!force && s.ts && now() - s.ts < 20000)) return;
  s.q = 1;
  srvq(ip, function (r) {
    s.q = 0; s.ts = now();
    if (r && r.ok) { s.ok = true; s.fail = false; s.name = clean(r.name) || s.name || ip; s.map = clean(r.map); s.pl = r.pl || 0; s.max = r.max || 0; s.bots = r.bots || 0;
      if (r.players) setPlayers(ip, r.players.map(function (x) { return { name: x.name, score: x.score, timePlayedSeconds: x.time }; })); }
    renderSoon();
  });
}
function pump() {
  while (running < qmax() && queue.length) {
    (function (ip) {
      running++;
      var s = srv(ip), t0 = now(), done = false;
      function fin() { if (done) return; done = true; running--; s.q = 0; s.ts = now(); onSrvUpdate(s); renderSoon(); pump(); }
      /* NextClient javob ololmasa - sayt (srvq.php) orqali qayta so'raymiz: ba'zi serverlar so'rovlarni cheklaydi */
      function viaSite() {
        srvq(ip, function (r) {
          if (done) return;
          if (r && r.ok) {
            s.prevPl = s.ok ? s.pl : null; s.ok = true; s.fail = false; s.ping = s.ping || 0; s.blk = true;   // server ishlayapti (sayt ko'radi), lekin bu kompyuterdan javob yo'q
            s.name = clean(r.name) || ip; s.map = clean(r.map); s.pl = r.pl || 0; s.max = r.max || 0; s.bots = r.bots || 0;
            if (r.players) PLAYERS[ip] = r.players.map(function (x) { return { name: x.name, score: x.score, timePlayedSeconds: x.time }; });
          } else { s.ok = false; s.fail = true; }
          fin();
        });
      }
      var tm = setTimeout(function () { if (!done) { netStat(s, 0); viaSite(); } }, 6000);
      if (!hasMM()) { clearTimeout(tm); viaSite(); return; }
      try {
        NC.matchmaking.getServerInfo(ip).then(function (r) {
          clearTimeout(tm);
          r = r || {};
          s.prevPl = s.ok ? s.pl : null; s.ok = true; s.fail = false; s.blk = false; s.ping = now() - t0; netStat(s, s.ping);
          s.name = clean(r.hostname) || ip; s.map = clean(r.map);
          s.pl = r.playersOnline || 0; s.max = r.playersMax || 0; s.bots = r.botsOnline || 0; s.pass = !!r.isPasswordProtected;
          fin();
        }, function () { clearTimeout(tm); netStat(s, 0); viaSite(); });
      } catch (e) { clearTimeout(tm); viaSite(); }
    })(queue.shift());
  }
}
/* server bilan aloqa sifati: so'rovlarning necha foizi javobsiz qoldi (yo'qotish) va ping qanchalik sakraydi (tebranish).
 * Oxirgi 10 ta so'rov hisobga olinadi. Tezkor o'yin va kirishdan oldingi tekshiruv shundan foydalanadi */
function netStat(s, ping) {
  s.nh = (s.nh || []).concat([ping || -1]).slice(-10);
}
function netQual(s) {
  var h = s.nh || [], lost = 0, ok = [], i;
  for (i = 0; i < h.length; i++) { if (h[i] < 0) lost++; else ok.push(h[i]); }
  var avg = 0, jit = 0;
  for (i = 0; i < ok.length; i++) avg += ok[i];
  avg = ok.length ? avg / ok.length : 0;
  for (i = 0; i < ok.length; i++) jit += Math.abs(ok[i] - avg);
  return { n: h.length, loss: h.length ? Math.round(lost * 100 / h.length) : 0, ping: Math.round(avg), jit: ok.length ? Math.round(jit / ok.length) : 0 };
}
function isX(s) { return PINNED.indexOf(s.ip) >= 0 || /x\s*client/i.test(s.name || ''); }
function isFavIp(ip) { return DB.fav.indexOf(ip) >= 0; }
function isFull(s) { return !!(s.ok && s.max && s.pl >= s.max); }
function modeOf(s) {
  var m = (s.map || '').toLowerCase(), n = (s.name || '').toLowerCase();
  if (/^zm_|zombie/.test(m) || /zombie|\bzm\b/.test(n)) return 'zm';
  if (/^gg_/.test(m) || /gungame|gun game/.test(n)) return 'gg';
  if (/^(jail_|jb_|ba_jail)/.test(m) || /jail/.test(n)) return 'jail';
  if (/^(kz_|bhop_|surf_|kzra_)/.test(m) || /\bkz\b|surf|bhop|climb/.test(n)) return 'kz';
  if (/^awp_/.test(m) || /\bawp\b/.test(n)) return 'awp';
  if (/^(aim_|fy_|35hp_)/.test(m)) return 'aim';
  if (/deathmatch|\bdm\b|csdm/.test(n)) return 'dm';
  if (/^(de_|cs_|as_)/.test(m)) return 'classic';
  return 'other';
}
var rTimer = 0;
function renderSoon() { if (rTimer) return; rTimer = setTimeout(function () { rTimer = 0; renderAll(); }, 250); }

function loadMaster() {
  setMaster(window.XC_MASTER && window.XC_MASTER.length ? window.XC_MASTER : []);
  try {
    var x = new XMLHttpRequest();
    x.open('GET', 'http://mmb.boost-top.com/ms.php?q=/v1/servers/cstrike&t=' + now(), true);
    x.onreadystatechange = function () {
      if (x.readyState !== 4 || !x.responseText) return;
      var out = [], re = /(?:^|\n)\s*(?:gs|ip)\s+([\d.]+:\d+)/g, m;
      while ((m = re.exec(x.responseText))) out.push(m[1]);
      if (out.length) setMaster(out);
    };
    x.send(null);
  } catch (e) {}
}
function setMaster(list) {
  var seen = {}; MASTER = [];
  each(PINNED.concat(list), function (ip) { ip = normIp(ip); if (ip && !seen[ip]) { seen[ip] = 1; MASTER.push(ip); } });
  if (MASTER.length > 400) MASTER.length = 400;
  if (curModal === 'mdServers' && srvTab === 'internet') each(MASTER, function (ip) { query(ip); });
  renderSoon();
}
function loadScript(src, ok, fail) {
  var done = false, el = document.createElement('script');
  el.src = src;
  var rm = function () { if (el.parentNode) el.parentNode.removeChild(el); };   // har 10 daqiqada yangi teg - eskilari qolib ketmasin
  el.onload = function () { if (!done) { done = true; ok(); } rm(); };
  el.onerror = function () { if (!done) { done = true; fail(); } rm(); };
  setTimeout(function () { if (!done) { done = true; fail(); } }, 6000);
  document.getElementsByTagName('head')[0].appendChild(el);
}
/* boost-top reklama ro'yxatlari.
 * top.php -> window.BOOST_TOP = [{ip, title, type?}, ...]  (TOP tarif; type 'fav'/'gm' bo'lsa - Sevimlilar tarifi)
 * fav.php -> window.BOOST_FAV = [...]  (ixtiyoriy: Sevimlilar tarifini olganlar)
 * Avval nisbiy yo'l (sahifa mmb.boost-top.com dan ochiladi) - o'yin brauzeri zamonaviy https ni ocholmasligi mumkin. */
var PROMO_FAV = [], SVC = {}, SORT_USER = false;
var SVC_ORDER = [['top', 'TOP'], ['boost', 'BOOST'], ['vip', 'VIP']];
function svcAny() { for (var i = 0; i < SVC_ORDER.length; i++) if ((SVC[SVC_ORDER[i][0]] || []).length) return true; return false; }
function svcIps() { var o = []; each(SVC_ORDER, function (g) { each(SVC[g[0]] || [], function (ip) { if (o.indexOf(ip) < 0) o.push(ip); }); }); return o; }
function svcBadges(ip) {
  var h = '';
  each(SVC_ORDER, function (g) { if ((SVC[g[0]] || []).indexOf(ip) >= 0) h += '<span class="svb ' + g[0] + '">' + g[1] + '</span>'; });
  if (srvTab !== 'favs' && PROMO_FAV.indexOf(ip) >= 0) h += '<span class="svb gm">\u2605</span>';
  return h;
}
function setSvc(o) {
  SVC = {};
  for (var k in o) if (o.hasOwnProperty(k) && o[k] && o[k].length != null) { SVC[k] = []; each(o[k], function (ip) { ip = normIp(ip); if (ip && SVC[k].indexOf(ip) < 0) SVC[k].push(ip); }); }
  each(svcIps(), function (ip) { query(ip); });
  renderSoon();
}
function loadList(urls, varName, cb) {
  var n = 0;
  function next() {
    if (n >= urls.length) { cb(null); return; }
    window[varName] = null;
    loadScript(urls[n++] + (urls[n - 1].indexOf('?') < 0 ? '?' : '&') + 't=' + now(), function () {
      if (window[varName] && window[varName].length != null) cb(window[varName]); else next();
    }, next);
  }
  next();
}
/* admin paneldagi "Reklama" serverlari: TOP ro'yxati tepasida ★ bilan, tezkor o'yin ham ularni afzal ko'radi */
var PROMO = [];
function loadPromo() {
  api('promo', {}, function (r) {
    if (!r.ok) return;
    PROMO = [];
    each(r.list || [], function (x) { var ip = itemIp(x); if (!ip) return; PROMO.push(ip); if (x.title) srv(ip).name = srv(ip).name || x.title; if (PINNED.indexOf(ip) < 0) PINNED.push(ip); query(ip); });
    renderSoon();
  });
}
var UNSTABLE = {};
function loadUnstable() { api('unstable', {}, function (r) { if (r && r.ok && r.u) UNSTABLE = r.u; }); }
function loadTop() {
  loadPromo(); loadUnstable();
  loadList(['top.php', 'http://boost-top.com/mmb/top.php', 'https://boost-top.com/mmb/top.php'], 'BOOST_TOP', function (l) { setTop(l || []); });
  setPromoFav([], true);
  loadList(['fav.php'], 'BOOST_FAV', function (l) { if (window.BOOST_SVC) setSvc(window.BOOST_SVC); if (l) setPromoFav(l); });
}
function itemIp(it) { if (typeof it === 'string') it = { ip: it }; var ip = normIp(it && (it.ip || it.addr || it.address)); if (ip && it.title && !srv(ip).name) srv(ip).name = it.title; return ip; }
/* ---- serverlar davlati (geo.php -> ip-api.com) va bayroq (saytdagi media/flags) ---- */
var GEO = {}, GEO_PEND = [], GEO_ASKED = {}, GEO_TM = 0;
try { GEO = JSON.parse(localStorage.getItem('xc_geo') || '{}') || {}; } catch (e) { GEO = {}; }
function hostOf(ip) { return String(ip || '').replace(/:\d+$/, ''); }
function flagOf(ip) {
  var cc = GEO[hostOf(ip)];
  if (!cc || !/^[a-z]{2}$/.test(cc)) { needGeo([ip]); return ''; }
  return '<img class="flg" src="geo.php?flag=' + cc + '" alt="" title="' + cc.toUpperCase() + '">';
}
function needGeo(ips) {
  each(ips, function (ip) { var h = hostOf(ip); if (h && !GEO[h] && !GEO_ASKED[h]) { GEO_ASKED[h] = 1; GEO_PEND.push(h); } });
  if (!GEO_PEND.length || GEO_TM) return;
  GEO_TM = setTimeout(function () {
    GEO_TM = 0;
    var list = GEO_PEND.splice(0, 300), x;
    try { x = new XMLHttpRequest(); x.open('POST', 'geo.php', true); x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded'); } catch (e) { return; }
    x.onreadystatechange = function () {
      if (x.readyState !== 4) return;
      var r = null; try { r = JSON.parse(x.responseText); } catch (e) {}
      if (!r) return;
      var n = 0;
      for (var h in r) if (r.hasOwnProperty(h) && /^[a-z]{2}$/.test(r[h])) { GEO[h] = r[h]; n++; }
      if (n) { try { localStorage.setItem('xc_geo', JSON.stringify(GEO)); } catch (e) {} renderSoon(); }
      if (GEO_PEND.length) needGeo([]);
    };
    x.send('ips=' + encodeURIComponent(list.join(',')));
  }, 400);
}
/* server qatori: bayroq + nom (kerak bo'lsa "...") + belgilar */
function c1row(s, name, badges) {
  var w = 300, re = /<span class="(?:svb|vb|xb)[^"]*">([^<]*)<\/span>/g, m;   // har belgi: ~9px harf + chekka
  while ((m = re.exec(badges))) w -= m[1].length * 9 + 16;
  return '<span class="c1">' + flagOf(s.ip) + '<span class="snm" style="max-width:' + Math.max(110, w) + 'px">' + esc(name) + '</span>' + badges + '</span>';
}
function setTop(list) {
  TOP = []; var fav = [];
  each(list || [], function (it) {
    var ip = itemIp(it); if (!ip) return;
    if (it && /^[a-z]{2}$/i.test(it.cc || '')) GEO[hostOf(ip)] = String(it.cc).toLowerCase();
    var tp = String((it && (it.type || it.tariff || it.t)) || '').toLowerCase();
    if (/fav|sevim|gm|izbr/.test(tp)) fav.push(ip); else TOP.push(ip);
  });
  if (fav.length) setPromoFav(fav, true);
  each(TOP, function (ip) { query(ip); });
  renderSoon();
}
/* har doim "Sevimlilar" da turadigan serverlar (egasining so'rovi) - fav.php ishlamasa ham */
var FAV_FIXED = ['212.47.58.89:27015', '212.47.58.40:27015'];
function setPromoFav(list, already) {
  PROMO_FAV = FAV_FIXED.slice();
  each(list, function (it) { var ip = already ? it : itemIp(it); if (ip && PROMO_FAV.indexOf(ip) < 0) PROMO_FAV.push(ip); });
  each(PROMO_FAV, function (ip) { query(ip); });
  renderSoon();
}

/* sevimli serverda joy bo'shashi + navbat */
var QUEUE_IP = '', QUEUE_TM = 0;
function onSrvUpdate(s) {
  if (QUEUE_IP === s.ip && s.ok && !isFull(s)) { var ip = QUEUE_IP; stopQueue(); toast(T('queue_free')); sfx('save'); doConnect(ip); }
  else if (QUEUE_IP === s.ip) queueBar();
  if (isFavIp(s.ip) && DB.notifyFav !== 0 && s.prevPl != null && s.max && s.prevPl >= s.max && s.pl < s.max && CONNECTED !== s.ip)
    toast(T('fav_free') + s.name, 5000);
}
function startQueue(ip) {
  stopQueue(); QUEUE_IP = ip; toast(T('queue'), 6000);
  var qn = 0;
  QUEUE_TM = setInterval(function () { if (!playing() || ++qn % 4 === 0) query(QUEUE_IP, true); }, 4000);   // o'yin paytida 16 s da bir (so'rov o'yinni qotiradi)
  queueBar();
}
function stopQueue() { QUEUE_IP = ''; clearInterval(QUEUE_TM); queueBar(); }
/* navbat ko'rinib tursin: pastda "Navbatda: server - 32/32 - Bekor qilish" */
function queueBar() {
  var b = $('qbar');
  if (!QUEUE_IP) { if (b) b.style.display = 'none'; return; }
  if (!b) { b = document.createElement('div'); b.id = 'qbar'; (document.getElementById('app') || document.body).appendChild(b); }
  var s = srv(QUEUE_IP);
  b.innerHTML = ico('clock') + ' ' + esc(T('q_wait')) + ' <b>' + esc(s.name || QUEUE_IP) + '</b>' + (s.ok ? ' \u00b7 ' + s.pl + '/' + s.max : '') + ' <a data-act="qstop">' + esc(T('q_stop')) + '</a>';
  b.style.display = 'block';
}

/* Menyu ochilganda ('show') yangilash. O'yin ustida (ESC) o'yin brauzeri har chizishni o'yinning asosiy oqimida qiladi:
 * hammasini bir yo'la (to'liq qayta chizish + do'stlar + hafta + serverlar) qilish kuchsiz kompyuterda ESC bosilganda
 * 1-2 soniya qotishga olib kelardi. O'yin ustida - bo'laklab (350 ms oraliq), menyu yopilsa to'xtaydi; kuchsiz
 * kompyuterda o'yin ustida haftalik reyting va server so'rovlari umuman qilinmaydi (menyudan chiqqach yangilanadi) */
var SHOW_TM = 0;
function showWork() {
  clearTimeout(SHOW_TM);
  var weak = !!CONNECTED && (DB.fx === 0 || (HW && hwClass() === 'weak'));
  var steps = [
    function () { if (UI_DIRTY) { UI_DIRTY = false; renderAll(); renderBar(); } },
    function () { if (weak) return; each(TOP.concat(PINNED).concat(DB.fav), function (ip) { query(ip); }); },
    function () { if (curModal === 'mdServers') { each(tabIps(), function (ip) { query(ip, true); }); if (srvSel) loadPlayers(srvSel); } if (CHAT && curModal === 'mdSide' && sideMode === 'chat') chatLoad(); },
    function () { loadFriends(); },
    function () { if (!weak) loadWeek(); },
    function () { ngFit(); }
  ];
  if (!CONNECTED) { each(steps, function (f) { try { f(); } catch (e) {} }); return; }
  var i = 0;
  function next() {
    if (i >= steps.length || !uiShown()) return;
    try { steps[i++](); } catch (e) {}
    SHOW_TM = setTimeout(next, 350);
  }
  SHOW_TM = setTimeout(next, 200);   // avval menyuning o'zi chizilib olsin
}

/* ============================================================ ulanish, tarix, K/D */
var CONNECTED = '', CUR = null;                 // CUR: joriy o'yin (tarix yozuvi)
function connect(ip) {
  ip = normIp(ip);
  if (!ip) return;
  BOT_PEND = null; BOT_SESS = null;                // botlar bilan mashqdan haqiqiy serverga o'tildi
  if (S.queue && isFull(srv(ip))) { startQueue(ip); return; }
  stopQueue();
  var alt = srv(ip).blk ? altAddr(ip) : null;
  if (alt) {                                       // bu manzil sizdan yopiq, shu serverning boshqa manzili ochiq - o'shanga
    toast(T('nc_alt').replace('{ip}', alt.ip), 6000);
    netCheck(alt.ip, function () { doConnect(alt.ip); }); return;
  }
  netCheck(ip, function () { doConnect(ip); });
}
/* bir server bir nechta manzilda (masalan 212.47.58.89 va proksi 157.22.130.26): nomi bir xil, bu kompyuterdan javob beradigani */
function srvKey(s) { var n = String(s && s.name || '').replace(/[^A-Za-z0-9]/g, '').toLowerCase(); return n.length >= 6 ? n : ''; }
function altAddr(ip) {
  var k = srvKey(srv(ip)), best = null; if (!k) return null;
  for (var i in SRV) if (SRV.hasOwnProperty(i) && i !== ip) { var o = SRV[i]; if (o.ok && !o.blk && srvKey(o) === k && (!best || o.ping < best.ping)) best = o; }
  return best;
}
/* kirishdan oldin aloqani tekshirish: serverga 3 ta qisqa so'rov (0.3 s oraliq). Yo'qotish yoki ping juda yuqori bo'lsa -
 * o'yinchiga aytamiz (lag kutilmasdan), u baribir kirishni tanlashi mumkin. Hammasi joyida bo'lsa - darhol kiradi */
var NC_BUSY = false;
function netCheck(ip, go) {
  if (NC_BUSY || CONNECTED || !hasMM() || DB.ncOff) return go();
  NC_BUSY = true;
  toast(T('nc_wait'), 2500);
  var pings = [], lost = 0, n = 0;
  function probe() {
    var t0 = now(), done = false;
    var tm = setTimeout(function () { if (!done) { done = true; lost++; netStat(srv(ip), -1); next(); } }, 2500);
    try {
      NC.matchmaking.getServerInfo(ip).then(function () { if (done) return; done = true; clearTimeout(tm); pings.push(now() - t0); netStat(srv(ip), now() - t0); next(); },
        function () { if (done) return; done = true; clearTimeout(tm); lost++; netStat(srv(ip), -1); next(); });
    } catch (e) { done = true; clearTimeout(tm); lost++; next(); }
  }
  function next() {
    if (++n < 3) return setTimeout(probe, 300);
    NC_BUSY = false;
    var avg = 0; each(pings, function (p) { avg += p; }); avg = pings.length ? Math.round(avg / pings.length) : 0;
    var loss = Math.round(lost * 100 / 3);
    if (loss < 34 && avg < 180) return go();
    /* sayt serverni ishlayapti deb ko'radi, faqat shu kompyuterning ping so'roviga javob yo'q (server so'rovlarni cheklaydi).
     * O'yin ulanishi odatda ishlaydi ("Connection accepted") - qo'rqitadigan savol bermaymiz, kiraveramiz */
    if (!pings.length && srv(ip).blk) { toast(T('nc_blk2'), 6000); return go(); }
    ask(T(pings.length ? 'nc_bad' : srv(ip).blk ? 'nc_blk' : 'nc_dead').replace('{p}', avg).replace('{l}', loss), go, false, false, true);
  }
  probe();
}
/* server parollari (VIP/admin, setinfo _pw): akkauntda saqlanadi, faqat SHU serverga ulanishdan oldin qo'yiladi.
 * Boshqa serverga ulanganda maydon tozalanadi - parol begona serverlarga yuborilmasin */
var PW_SET = {};
function srvPw(ip) { var r = null; each(DB.pw || [], function (x) { if (x.ip === ip) r = x; }); return r; }
/* VIP/admin kirish: AMX Mod X serverlari o'yinchini nik (login) + setinfo _pw (parol) bo'yicha taniydi.
 * Saqlangan serverga kirganda ikkalasi o'zi qo'yiladi; boshqa serverga o'tganda parol olib tashlanadi, nik odatdagisiga qaytadi */
var PW_NAME = false;
function pwIsLogin(n) { var r = false; each(DB.pw || [], function (x) { if (x.login && x.login === n) r = true; }); return r; }
/* VIP serverdan chiqildi (yoki menyu qayta yuklandi) - o'yindagi nik VIP login bo'lib qolgan bo'lsa, asl nikni qaytaramiz */
function pwRestoreName() {
  var nm = readCvar('name');
  if ((PW_NAME || (nm && pwIsLogin(nm))) && S && S.name) { cmd('name ' + q(fullName(S))); MYNAME = fullName(S); }
  PW_NAME = false;
}
function applyPw(ip) {
  var p = srvPw(ip);
  for (var f in PW_SET) if (PW_SET.hasOwnProperty(f) && (!p || p.f !== f)) { cmd('setinfo ' + f + ' ""'); delete PW_SET[f]; }
  if (p) { cmd('setinfo ' + p.f + ' ' + q(p.pw)); PW_SET[p.f] = 1; }
  if (p && p.login) { cmd('name ' + q(p.login)); MYNAME = p.login; PW_NAME = p.login; }
  else if (p && S && S.name && S.tag) { cmd('name ' + q(S.name)); MYNAME = S.name; PW_NAME = S.name; }   // VIP aniq nik bo'yicha - klan tegi xalaqit beradi
  else pwRestoreName();
}
var PW_IP = '';
function openPw(ip) {
  var p = srvPw(ip) || {}; PW_IP = ip;
  openSide('srvpw', T('pw_title'), '<div class="pwbox"><b class="pws">' + esc(srv(ip).name || ip) + '</b>' +
    '<p>' + esc(T('pw_help')) + '</p>' +
    '<div class="lbl">' + esc(T('pw_login')) + '</div><input class="tx big" id="pwsL" maxlength="31" value="' + esc(p.login || '') + '" placeholder="' + esc(T('pw_loginph')) + '">' +
    '<div class="lbl">' + esc(T('pw_pass')) + '</div><input class="tx big" id="pwsP" type="password" maxlength="40" value="' + esc(p.pw || '') + '">' +
    '<div class="lbl sm">' + esc(T('pw_field')) + '</div><input class="tx" id="pwF" maxlength="20" value="' + esc(p.f || '_pw') + '" style="width:140px">' +
    '<div class="pwbt"><a class="btn red" data-act="pwsave">' + esc(T('pw_save')) + '</a>' + (p.pw ? ' <a class="btn" data-act="pwdel">' + esc(T('pw_delb')) + '</a>' : '') + '</div>' +
    '<p class="mut">' + esc(T('pw_note')) + '</p></div>');
  setTimeout(function () { try { $(p.login ? 'pwsP' : 'pwsL').focus(); } catch (e) {} }, 50);
}
function pwSave(ip, del) {
  var side = curModal === 'mdSide' && $('pwsP'), iL = $(side ? 'pwsL' : 'pwL'), iP = $(side ? 'pwsP' : 'pwP'), old = srvPw(ip);
  DB.pw = (DB.pw || []).filter(function (x) { return x.ip !== ip; });
  var pw = del || !iP ? '' : String(iP.value || '').replace(/["\\;]/g, '').slice(0, 40);
  var lg = del || !iL ? '' : String(iL.value || '').replace(/["\\;\n]/g, '').replace(/^\s+|\s+$/g, '').slice(0, 31);
  var fe = side ? $('pwF') : null, fld = del ? '' : (fe ? String(fe.value || '').replace(/[^\w]/g, '') : '') || (old && old.f) || '_pw';
  if (pw) DB.pw.push({ ip: ip, f: fld, pw: pw, login: lg });
  persist(); cloudSave(); toast(T(pw ? 'pw_saved' : 'pw_del'), 6000);
  if (CONNECTED === ip) { applyPw(ip); if (pw) toast(T('pw_reconn'), 7000); }
  if (curModal === 'mdServers') { if (del && $('pwL')) { $('pwL').value = ''; $('pwP').value = ''; } renderInfo(); } else { openServers(srvTab); srvSel = ip; renderServers(); }
}
/* ---- serverning kirish paroli (sv_password): oddiy CS da "parolni kiriting" oynasi chiqardi, NextClient menyusida chiqmaydi.
 * Parolli server (ro'yxatda PW) - ulanishdan oldin so'raymiz; server "parol noto'g'ri/kerak" desa (konsol) - yana so'raymiz.
 * Parol shu server uchun eslab qolinadi; boshqa serverga ulanishda 'password' bo'shatiladi (begona serverga ketmasin) ---- */
var SPW_ON = false, SPW_TRY = null;
function spwSet(ip) {
  var pw = DB.spw && DB.spw[ip];
  if (pw) { cmd('password ' + q(pw)); SPW_ON = true; }
  else if (SPW_ON) { cmd('password ""'); SPW_ON = false; }
}
function spwAsk(ip, wrong) {
  if (DB.spw && DB.spw[ip] && wrong) { delete DB.spw[ip]; persist(); }
  ask(T(wrong ? 'spw_bad' : 'spw_ask').replace('{s}', srv(ip).name || ip), function (v) {
    v = String(v || '').replace(/["\\;\n]/g, '').slice(0, 60);
    if (!v) return;
    DB.spw = DB.spw || {}; DB.spw[ip] = v; persist();
    doConnect(ip, true);
  }, false, true);
}
/* ulanish rad etildi: server to'la / ban / kick - oddiy CS kabi sababini ko'rsatamiz (oldin o'yinchi shunchaki menyuga qaytardi) */
function rejConsole(txt) {
  if (!SPW_TRY || now() - SPW_TRY.t > 40000) return;
  var k = /server is full|server full|сервер (заполнен|полон)/i.test(txt) ? 'full' : /\bbann?ed\b|you are banned|забанен|бан\b/i.test(txt) ? 'ban'
    : /\bkicked\b|кикнут|выкинут/i.test(txt) ? 'kick' : /connection rejected|rejected|отклон/i.test(txt) && !/password/i.test(txt) ? 'rej' : '';
  if (!k) return;
  var ip = SPW_TRY.ip; SPW_TRY = null;
  CLK['rej_' + k] = (CLK['rej_' + k] || 0) + 1; CLK_N++;
  setTimeout(function () {
    var b = k === 'full' ? '<a class="btn red" data-act="rejq">' + esc(T('rj_queue')) + '</a> ' : '';
    REJ_IP = ip;
    openSide('rej', T('rj_t_' + k), '<div class="rejw"><b>' + esc(srv(ip).name || ip) + '</b><p>' + esc(T('rj_' + k)) + '</p><div class="rejr mut">' + esc(String(txt).replace(/\s+/g, ' ').slice(0, 160)) + '</div>' +
      b + '<a class="btn" data-act="quick">' + esc(T('rj_other')) + '</a></div>');
  }, 700);
}
var REJ_IP = '';
function spwConsole(txt) {
  if (!SPW_TRY || now() - SPW_TRY.t > 40000 || !/password/i.test(txt) || !/(invalid|bad|wrong|incorrect|requir|need|enter|неверн|нужен)/i.test(txt)) return;
  var ip = SPW_TRY.ip, had = !!(DB.spw && DB.spw[ip]); SPW_TRY = null;
  srv(ip).pass = true;
  setTimeout(function () { spwAsk(ip, had); }, 600);   // o'yin menyuga qaytib bo'lsin
}
function doConnect(ip, pwDone) {
  if (!pwDone && srv(ip).pass && !(DB.spw && DB.spw[ip])) return spwAsk(ip, false);   // parolli server - avval parol
  spwSet(ip); SPW_TRY = { ip: ip, t: now() };
  applyPw(ip);
  toast(T('connecting') + (srv(ip).name || ip));
  if (!cmd('connect ' + ip)) toast(T('no_api'));
  else startGame(ip);
}
function startGame(ip) {
  var h = DB.hist[0];
  if (h && h.ip === ip && now() - h.t < 90000) { CUR = h; return; }
  var s = srv(ip);
  CUR = { ip: ip, name: s.name || ip, map: s.map || '', t: now(), d: 0, k: 0, x: 0 };
  XP0 = ME ? ME.xp : null;
  DB.hist.unshift(CUR);
  if (DB.hist.length > 300) DB.hist.length = 300;
  persist(); renderSoon(); cloudSave();
}
function pad(n) { return (n < 10 ? '0' : '') + n; }
/* Demo yozish: o'yinchi serverga to'liq kirgach ('putinserver') boshlanadi - ulanish/yuklanish paytida
 * "record" ishlamaydi. Ro'yxatga faqat konsolda "Recording to ..." chiqqanda qo'shiladi (konsol API bo'lmasa - darhol). */
var REC = '', REC_TM = 0;
function demoName() { var d = new Date(); return 'xc_' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '_' + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds()); }
function demoAdd(nm) {
  if (!nm || (DB.demos && DB.demos[0] && DB.demos[0].n === nm)) return;
  var sv = srv(CONNECTED);
  DB.demos = [{ n: nm, s: sv.name || CONNECTED, m: sv.map || '', t: now() }].concat(DB.demos || []).slice(0, 30); persist();
}
function startRecord(delay) {
  clearTimeout(REC_TM);
  REC_TM = setTimeout(function () {
    if (!S.demo || !CONNECTED || REC) return;
    REC = demoName();
    cmd('record ' + REC);
    var nm = REC; setTimeout(function () { if (REC === nm) demoAdd(nm); }, 8000);   // konsol javobi kelmasa ham (xato yo'q bo'lsa) ro'yxatga
  }, delay);
}
/* mikrofon: birinchi bosishda o'yin ovoz yozish qurilmasini ochadi - ba'zi kompyuterlarda 2-3 soniya qotadi.
 * Serverga kirgach (xarita yuklangach) qurilmani bir marta oldindan ochib qo'yamiz - gapirganda qotmaydi. */
function voiceWarm() {
  if (!S || S.voice === 0 || S.micwarm === 0) return;
  setTimeout(function () { if (CONNECTED && !uiShown()) { cmd('+voicerecord'); setTimeout(function () { cmd('-voicerecord'); }, 120); } else if (CONNECTED) setTimeout(voiceWarm, 15000); }, 20000);
}
/* Demo ko'rish boshqaruvi: F6 pauza, F7 sekinroq, F8 tezroq, F9 oddiy tezlik. Tezlik host_framerate bilan
 * (har kadr demo vaqtini belgilangan miqdorda suradi; 1/fps_max = oddiy tezlik). Tugmalar faqat demo paytida bog'lanadi,
 * tugagach (yoki serverga ulanganda) host_framerate 0 va o'yinchining tugmalari qaytariladi - onlayn o'yinga ta'sir qilmasin. */
var DEMO_END_T = 0, DEMO_PLAY = false, DEMO_KEYS = ['F6', 'F7', 'F8', 'F9'], DEMO_CUR = '', DEMO_SPD = 2, DEMO_PAUSE = false;
var DEMO_SP = [0.25, 0.5, 1, 2, 4, 8];
function demoPlay(nm) {
  nm = String(nm || '').replace(/[^\w\-]/g, '');
  if (!nm) return;
  var f = 1 / Math.max(30, Math.min(1000, Number(S && S.fps) || 100)), sp = DEMO_SP, vol = S && S.vol != null ? S.vol : 0.8;
  for (var i = 0; i < sp.length; i++) {
    var hf = sp[i] === 1 ? 0 : Math.round(f * sp[i] * 1e6) / 1e6;
    /* 1x dan boshqa tezlikda ovoz o'chiriladi: o'yin ovozi vaqtga bog'langan - pauza/sekinda oxirgi tovush takrorlanib qoladi */
    var snd = sp[i] === 1 ? 'volume ' + vol : 'volume 0; stopsound';
    cmd('alias xcd_' + i + ' "host_framerate ' + hf + '; ' + snd + '; alias xcd_up xcd_' + Math.min(i + 1, sp.length - 1) + '; alias xcd_dn xcd_' + Math.max(i - 1, 0) +
      '; alias xcd_p xcd_pz; alias xcd_back xcd_' + i + '; echo X CLIENT demo: ' + sp[i] + 'x"');
  }
  cmd('alias xcd_pz "host_framerate 0.000001; volume 0; stopsound; alias xcd_p xcd_back; echo X CLIENT demo: pauza (F6 - davom)"');
  cmd('xcd_2');
  cmd('bind F6 xcd_p'); cmd('bind F7 xcd_dn'); cmd('bind F8 xcd_up'); cmd('bind F9 xcd_2');
  if (QUEUE_IP) stopQueue();                         // navbat demo paytida serverga ulab yubormasin
  cmd('cl_filterstuffcmd 1');                        // demo ichiga yozilgan server buyruqlari (connect/retry/disconnect) demoni yopmasin
  DB.dplay = { n: nm, t: now() }; persist();         // menyu sahifasi demo paytida qayta yuklansa ham holat saqlansin
  DEMO_PLAY = true; DEMO_CUR = nm; DEMO_SPD = 2; DEMO_PAUSE = false;
  cmd('echo X CLIENT demo: F6 pauza, F7 sekinroq, F8 tezroq, F9 oddiy tezlik, F10 video yozish');
  cmd('mp3 stop'); MUSIC_ON = false;
  cmd('playdemo ' + nm);
}
function demoEnd(why) {
  if (DEMO_PLAY) cmd('echo [X CLIENT] demo tugadi: ' + (why || '?'));
  cmd('host_framerate 0');
  cmd('cl_filterstuffcmd 0');                        // demo uchun yoqilgan edi - qolib ketsa serverlar menyusining bandlari ishlamaydi
  if (!DEMO_PLAY) return;
  cmd('volume ' + (S && S.vol != null ? S.vol : 0.8));
  DEMO_PLAY = false; DEMO_PAUSE = false; DEMO_END_T = now();
  if (DB.dplay) { DB.dplay = null; persist(); }
  for (var i = 0; i < DEMO_KEYS.length; i++) cmd('unbind ' + DEMO_KEYS[i]);
  applyBinds();
  setTimeout(musicSync, 1500);
}
/* F10 videolari ro'yxati saytdan (launcher har video saqlanganda va har ochilishda yangilaydi) */
var VIDS_T = 0;
function vidsRefresh() {
  if (!PCID || now() - VIDS_T < 4000) return;
  VIDS_T = now();
  api('opts', { d: PCID }, function (r) {
    if (!r.ok || !r.o) return;
    OPTS.vids = r.o.vids || [];
    OPTS.f11 = r.o.f11 || null;
    if (curModal === 'mdSettings' && setTab === 'demo') $('setBody').innerHTML = PANES.demo();
  });
}
/* F11 skrinshotlar: launcher ro'yxat va 320px kichik rasmni yuboradi; bosilsa - launcher rasmni ochadi */
function shotsBox() {
  var sh = OPTS && OPTS.f11, g = '';
  each(sh || [], function (s) {
    var m = /^xc_(\d{4})(\d\d)(\d\d)_(\d\d)(\d\d)(\d\d)/.exec(s.n || ''); if (!m) return;
    var thu = PCID && DB.pck ? 'xc_api.php?a=vth&t=s&d=' + encodeURIComponent(PCID) + '&k=' + encodeURIComponent(DB.pck) + '&n=' + encodeURIComponent(s.n) : '';
    g += '<div class="sst"><a class="ssi" data-sopen="' + esc(s.n) + '" title="' + esc(T('ss_open')) + '"' + (thu ? ' style="background-image:url(\'' + thu + '\')"' : '') + '></a>' +
      '<span>' + esc(m[4] + ':' + m[5] + ' · ' + m[3] + '.' + m[2]) + '</span><a class="ssd" data-sdel="' + esc(s.n) + '" title="' + esc(T('vd_del')) + '">' + ico('trash') + '</a></div>';
  });
  var empty = !PCID ? 'sy_nolaunch' : sh === null || sh === undefined ? 'ss_old' : 'ss_none';
  return '<div class="ph2 m ssh">' + esc(T('ss_title')) + ' <a class="btn vfold" data-sfold="1">' + ico('folder') + ' ' + esc(T('vd_folder')) + '</a></div>' +
    (g ? '<div class="ssg">' + g + '</div>' : '<div class="empty">' + esc(T(empty)) + '</div>') +
    '<div class="mut" style="font-size:12px;margin-top:6px">' + esc(T('ss_note')) + '</div>';
}
function vidCmd(c, n, extra, quiet) {
  if (!PCID) { if (!quiet) toast(T('sy_nolaunch'), 4000); return; }
  var prm = { d: PCID, c: c, n: n || '' };
  if (extra) for (var ek in extra) if (extra.hasOwnProperty(ek)) prm[ek] = extra[ek];
  api('vcmd', prm, function (r) {
    if (!r.ok) { if (!quiet) toast(r.msg || 'Xato', 3500); return; }
    if (r.vids) OPTS.vids = r.vids;
    if (r.f11) OPTS.f11 = r.f11;
    if (c === 'trim') { setTimeout(function () { VIDS_T = 0; vidsRefresh(); }, 8000); setTimeout(function () { VIDS_T = 0; vidsRefresh(); }, 20000); }
    if (!quiet) toast(T({ del: 'vd_deleted', open: 'vd_opening', folder: 'vd_opening2', sopen: 'vd_opening', sfold: 'vd_opening2', sdel: 'vd_deleted', trim: 'vd_trimming', opt: 'vb_saved', edit: 'vd_editing', share: 'vs_wait' }[c] || 'saved'), c === 'share' ? 7000 : 5000);
    if (curModal === 'mdSettings' && setTab === 'demo') $('setBody').innerHTML = PANES.demo();
  });
}
/* avtomatik klip: 12 soniya ichida 3+ kill - launcher buferidan oxirgi 30 soniya saqlanadi (launcher buyruqni 4 soniyada oladi) */
var KILLT = [], ACL_T = 0;
function autoClipKill() {
  var t = now();
  KILLT.push(t); while (KILLT.length && t - KILLT[0] > 12000) KILLT.shift();
  if (KILLT.length < 3 || DB.acl === 0 || !rbOn() || !PCID || t - ACL_T < 25000) return;
  ACL_T = t; KILLT = [];
  setTimeout(function () { vidCmd('clip', '', null, true); }, 3000);   // kill'dan keyingi lahzalar ham tushsin
}
function mmss(v) { var m = /^\s*(\d+)(?::(\d{1,2}))?\s*$/.exec(String(v || '')); return m ? (m[2] != null ? +m[1] * 60 + +m[2] : +m[1]) : -1; }
/* demolar ro'yxati: launcher haqiqiy fayllarni beradi (OPTS.dmf) - o'chirilganlar chiqmaydi, menyu yozib ulgurmaganlari ham ko'rinadi.
 * Launcher eski bo'lsa (dmf yo'q) - menyu o'zi eslab qolgan ro'yxat */
var MENU_T0 = now(), DEMO_SEL = '';
function demoItems() {
  var db = DB.demos || [], f = OPTS && OPTS.dmf;
  if (!f || typeof f.length !== 'number') return db;
  var by = {}, out = [], seen = {};
  each(db, function (d) { by[d.n] = d; });
  each(f, function (n) {
    if (seen[n]) return; seen[n] = 1;
    var m = /^xc_(\d{4})(\d\d)(\d\d)_(\d\d)(\d\d)(\d\d)$/.exec(n);
    out.push(by[n] || { n: n, s: 'Demo', m: '', t: m ? new Date(+m[1], m[2] - 1, +m[3], +m[4], +m[5], +m[6]).getTime() : 0 });
  });
  each(db, function (d) { if (!seen[d.n] && d.t >= MENU_T0 - 60000) { out.unshift(d); seen[d.n] = 1; } });   // shu safar yozilgan - launcher hali bilmaydi
  out.sort(function (a, b) { return (b.t || 0) - (a.t || 0); });
  return out;
}
/* Demo bo'limidagi pult: menyu tugmalari F6-F9 bilan bir xil aliaslarni chaqiradi */
function demoCtl(c) {
  if (!DEMO_PLAY) {                                  // to'xtatilgan: ▶ - tanlangan (yoki eng yangi) demoni ochadi
    var it = demoItems(), nm = DEMO_SEL || (it[0] && it[0].n);
    if ((c === 'n' || c === 'p') && nm) { closeModal(); demoPlay(nm); return; }
    toast(T(it.length ? 'dm_first' : 'dm_none'), 3500); return;
  }
  if (c === 'stop') { demoEnd('stop tugmasi'); cmd('disconnect'); }
  else if (c === 'p') { cmd('xcd_p'); DEMO_PAUSE = !DEMO_PAUSE; }
  else if (c === 'dn') { DEMO_SPD = Math.max(0, DEMO_SPD - 1); DEMO_PAUSE = false; cmd('xcd_' + DEMO_SPD); }
  else if (c === 'up') { DEMO_SPD = Math.min(DEMO_SP.length - 1, DEMO_SPD + 1); DEMO_PAUSE = false; cmd('xcd_' + DEMO_SPD); }
  else if (c === 'n') { DEMO_SPD = 2; DEMO_PAUSE = false; cmd('xcd_2'); }
  if (curModal === 'mdSettings' && setTab === 'demo') showSetTab('demo');
}
function stopRecord() { clearTimeout(REC_TM); if (REC) { cmd('stop'); REC = ''; } }
/* ---- serverga kirish kuzatuvi: "Connecting to" dan o'yinga tushguncha (putinserver) qancha vaqt ketdi,
 * qaysi faylda to'xtadi. 60 s da kirolmasa - join_stuck, kirsa-yu sekin bo'lsa - join_slow, kutib chiqib ketsa - join_fail */
var JOIN = null, JOIN_TM = 0;
function joinX(j) { return 'ip=' + j.ip + ' sec=' + Math.round((now() - j.t) / 1000) + ' files=' + j.nf + ' fail=' + j.fail + ' http=' + j.http + ' ver=' + VERSION + ' last=' + String(j.last || '-').slice(0, 160); }
function joinProb(k, j) { api('prob', { k: k, d: PCID || '', x: joinX(j) }, function () {}); }
function joinStart(ip) {
  clearTimeout(JOIN_TM);
  JOIN = { ip: ip, t: now(), last: '', nf: 0, fail: 0, http: 0, stuck: 0 };
  var j = JOIN;
  JOIN_TM = setTimeout(function () { if (JOIN === j) { j.stuck = 1; joinProb('join_stuck', j); } }, 60000);
}
function joinLine(txt) {
  var c = /^\s*Connecting to\s+(\S+?)\.*\s*$/i.exec(txt);
  if (c) { if (!DEMO_PLAY) joinStart(c[1]); return; }
  if (!JOIN) return;
  if (/failed to transmit|Error: server failed/i.test(txt)) { JOIN.fail++; JOIN.last = txt.trim(); }
  else if (/^\s*\[HTTP\]/i.test(txt)) { JOIN.http = 1; JOIN.last = txt.trim(); }
  else if (/^\s*(processing|downloading|Downloading)\b/i.test(txt)) { JOIN.nf++; JOIN.last = txt.trim(); }
  else if (/connection rejected|server is full|banned|Bad password|Invalid protocol|Server shutting down|Disconnected|timed out/i.test(txt)) JOIN.last = txt.trim();
}
function joinDone() {
  if (!JOIN) return;
  var j = JOIN; JOIN = null; clearTimeout(JOIN_TM);
  if (now() - j.t >= 40000) joinProb('join_slow', j);
}
function joinAbort() {
  if (!JOIN) return;
  var j = JOIN; JOIN = null; clearTimeout(JOIN_TM);
  if (now() - j.t >= 8000) joinProb('join_fail', j);   // yuklanishda chiqib ketdi / uzildi
}
function onConnectEvt(addr, inGame) {
  if (inGame) joinDone();
  if (BOT_PEND) setTimeout(botsApply, 1500);       // botlar bilan mashq: xarita yuklandi - bot sonini qayta yuboramiz
  if (!isLocalAddr(addr)) AIMT = null;            // haqiqiy serverda aim test hisobi va chatga yozish bo'lmaydi
  if (isLocalAddr(addr)) { LOCAL_ON = true; fxClass(); sparks(); return; }   // o'z serveri (botlar) - haqiqiy o'yin funksiyalarisiz
  addr = normIp(addr);
  if (!addr) return;
  /* demo ham "ulanish" hodisasini beradi (yozilgan server manzili bilan) - bu o'yin emas: statistika, demo yozish, musiqa o'chirish kerak emas */
  if (DEMO_PLAY) return;
  cmd('host_framerate 0');          // demo o'zi ham ulanish hodisasini berishi mumkin - demo paytida tegmaymiz (serverga ulanish 'Connecting to' bilan ushlanadi)
  if (QUEUE_IP && addr !== QUEUE_IP && addr !== CONNECTED) stopQueue();   // hozirgi serverning o'z hodisalari (xarita almashishi) bekor qilmaydi   // boshqa serverga (konsol, o'yin ro'yxati) kirildi - navbat bekor
  if (addr !== CONNECTED) { CONNECTED = addr; ESC_OPEN = false; gpStart(addr); setTimeout(restCheck, 3000); setTimeout(function () { if (CONNECTED === addr) aimNetApply(addr); }, inGame ? 1500 : 6000);
    if (inGame && OPTS && (OPTS.ontop || OPTS.flash)) vidCmd('conn', '', { ta: (OPTS.ontop ? 1 : 0) | (OPTS.flash ? 2 : 0) }, true);   /* serverga ulandi: oyna tepaga / ikonka miltillaydi (launcher) */
    if (!inGame) applyPw(addr); startGame(addr); musicSync();   // serverda mp3 chalinmasin: o'yin ovozlarini bo'g'adi
    pingPresence(); renderAll(); sparks(); voiceWarm(); }
  if (S.demo) startRecord(inGame ? 1500 : 25000);   // 'connect' dan keyin 'putinserver' kelmasa ham 25 soniyadan so'ng urinamiz
}
function onDisconnectEvt() {
  var was = CONNECTED;
  if (JOIN && now() - JOIN.t > 1500) joinAbort();
  if (LOCAL_ON || (BOT_SESS && !CONNECTED)) { LOCAL_ON = false; BOT_SESS = null; BOT_PEND = null; if (AIMT) { if (AIMT.t0) aimtEnd(); AIMT = null; } fxClass(); sparks(); if (!was) return; }   // botlar bilan mashq tugadi
  gpEnd();
  setTimeout(musicSync, 500);
  if (CUR) { CUR.d = Math.round((now() - CUR.t) / 1000); persist(); cloudSave(); sendStat(CUR); }
  stopRecord();
  var fin = CUR;
  if (fin && !DEMO_PLAY) { VIDS_T = 0; setTimeout(vidsRefresh, 2000); setTimeout(misCheck, 8000); }   // o'yindan keyin vazifalar bajarilgan bo'lishi mumkin
  if (fin && !DEMO_PLAY) setTimeout(function () { if (!CONNECTED && !DEMO_PLAY) gameSummary(fin); }, 5000);   // qayta ulanish bo'lmasa - xulosa
  if (fin && !DEMO_PLAY && !ME) setTimeout(function () { if (!CONNECTED && !DEMO_PLAY && !ME && !curModal && regOfferDue()) { regOfferMark(); openSide('rgo', T('ro_btn'), '<div class="ydc">' + regOfferHtml(1) + '</div>'); } }, 6500);
  if (fin && !DEMO_PLAY && !DB.fq && fin.d >= 60) { DB.fq = 1; persist(); setTimeout(function () { firstAskLater(0); }, 1000); }   // birinchi o'yin: "qanday bo'ldi?" (bir marta)
  CUR = null;                                        // demo ko'rganda konsoldagi kill'lar oxirgi o'yinga qo'shilmasin
  CONNECTED = ''; renderAll(); pingPresence(); sparks();
  // o'yinchi o'zi menyudan chiqmagan bo'lsa (menyu yopiq) - qayta ulanamiz
  var shown = false;
  shown = uiShown();
  /* demo ochilganda ham o'yin serverdan uziladi - bu tarmoq uzilishi emas: qayta ulanmaymiz (aks holda 3 soniyada demo yopilardi) */
  var demo = DEMO_PLAY || now() - DEMO_END_T < 8000;
  if (S.reconn && was && !shown && !demo) setTimeout(function () { if (!CONNECTED && !DEMO_PLAY) cmd('retry'); }, 3000);
}
/* konsoldan o'ldirish/o'lish hisobi: "Player1 killed Player2 with ak47" */
var MYNAME = '', CONLOG = [];
var CON_N = 0, CON_K = 0;   // tashxis: konsoldan nechta qator keldi, nechtasi kill deb tanildi (stat bilan serverga)
function onConsole(txt) {
  txt = String(txt || ''); CON_N++;
  spwConsole(txt); rejConsole(txt);
  CONLOG.push(txt); if (CONLOG.length > 400) CONLOG.shift();
  joinLine(txt);
  var r = /Recording to (\S+?)(?:\.dem)?\.?\s*$/i.exec(txt);
  if (r && REC && r[1].indexOf(REC) === 0) demoAdd(REC);
  else if (REC && /(can'?t|cannot|not) record|must be connected/i.test(txt)) { REC = ''; if (S.demo && CONNECTED) startRecord(10000); }   // erta bo'ldi - keyinroq qayta
  /* demo tugadi yoki serverga ulanyapti - oddiy tezlik. Faqat aniq qatorlar: "Couldn't open file overviews/..." (radar xaritasi) demo xatosi emas */
  if (DEMO_PLAY) { var dm = /^\s*Completed demo|^\s*ERROR: couldn'?t open\.?\s*$|^\s*Connecting to/i.exec(txt); if (dm) demoEnd(dm[0]); }
  if (/\b(wrote|writing|saved)\b.*\.(bmp|tga|jpg|png)\b/i.test(txt)) toast(T('sh_saved'), 2500);   // F5: skrinshot saqlandi
  /* kill qatorlari bo'laklab keladi: "Ism" + " killed " + "Ism2" + " with ak47" + "\n" (har biri alohida hodisa) -
   * shuning uchun qatorni yig'ib, "\n" kelganda tekshiramiz (avval har bo'lak alohida tekshirilib, kill hech qachon tanilmasdi) */
  if (!KILLBUF && /^\s*(\*\*\*\s*)?.+? killed .+? with (a headshot from )?[\w\-]+[\s*]*$/.test(txt)) { killLine(txt.replace(/\s+$/, '')); return; }   // butun qator bitta hodisada kelgan
  KILLBUF += txt; clearTimeout(KILLBUF_TM);
  if (KILLBUF.length > 600) KILLBUF = KILLBUF.slice(-600);
  var nl = KILLBUF.lastIndexOf('\n');
  if (nl >= 0) { var lines = KILLBUF.slice(0, nl).split('\n'); KILLBUF = KILLBUF.slice(nl + 1); each(lines, function (ln) { if (ln) killLine(ln); }); }
  if (KILLBUF) KILLBUF_TM = setTimeout(function () { var ln = KILLBUF; KILLBUF = ''; if (ln) killLine(ln); }, 250);   // "\n" kelmasa
}
var KILLBUF = '', KILLBUF_TM = 0;
function killLine(txt) {
  if (AIMT && AIMT.on) {                           // aim test (o'z serverida, CUR yo'q bo'lishi mumkin)
    var am = /^(.+?) killed (.+?) with (a headshot from )?([\w\-]+)/.exec(txt.replace(/^\s*(\*\*\*\s*)?/, '')), mine = function (n) { return !!n && (n === MYNAME || (S && (n === S.name || n === fullName(S)))); };
    if (am && mine(am[1]) && !mine(am[2])) aimtKill(!!am[3]);
  }
  if (!CUR || !MYNAME) return;
  if (KILL_SAMPLE.length < 3 && / killed /i.test(txt) && txt.length < 160) KILL_SAMPLE.push(txt.trim());   // tashxis: kill qatorlari qanday ko'rinishda keladi
  /* "A killed B with ak47", "*** A killed B with a headshot from ak47 ***", "A + C killed B with m4a1" (C - yordam bergan) */
  var m = /^(.+?) killed (.+?) with (a headshot from )?([\w\-]+)/.exec(txt.replace(/^\s*(\*\*\*\s*)?/, ''));
  if (!m) return;
  /* server nikka prefiks qo'shgan bo'lsa ham o'zimizni taniymiz */
  if (m[1] !== MYNAME && m[1].split(' + ')[0] !== MYNAME && isMyName(m[1].split(' + ')[0])) m[1] = MYNAME + m[1].slice(m[1].split(' + ')[0].length);
  if (m[2] !== MYNAME && isMyName(m[2])) m[2] = MYNAME;
  CON_K++;
  var kp = m[1].split(' + '), killer = kp.length === 2 && kp[0] !== MYNAME && m[1] !== MYNAME ? kp[0] : m[1];
  if (m[1] !== MYNAME && kp.length === 2 && kp[0] === MYNAME) killer = MYNAME;
  if (killer === MYNAME && m[2] !== MYNAME) { autoClipKill();
    CUR.k = (CUR.k || 0) + 1; CUR.w = CUR.w || {}; CUR.w[m[4]] = (CUR.w[m[4]] || 0) + 1;
    if (m[3]) { CUR.h = (CUR.h || 0) + 1; CUR.wh = CUR.wh || {}; CUR.wh[m[4]] = (CUR.wh[m[4]] || 0) + 1; }
    CUR.s = (CUR.s || 0) + 1; if (CUR.s > (CUR.bs || 0)) CUR.bs = CUR.s; persist(); annKill(m[4], !!m[3], CUR.s); }
  else if (m[2] === MYNAME) { CUR.x = (CUR.x || 0) + 1; CUR.s = 0; persist(); }
  else if (kp.length === 2 && kp[1] === MYNAME) { CUR.a = (CUR.a || 0) + 1; persist(); }
}
/* ---- kill ovozlari (faqat o'yinchining o'ziga eshitiladi): ketma-ket kill (5 soniya ichida), seriya (o'lmasdan), headshot, pichoq, granata.
 * Fayllar launcher bilan keladi: cstrike/sound/xclient/ann/<til>/<nom>.wav. Til - menyu tili (uz / ru / en) */
var ANN_T = 0, ANN_N = 0, ANN_LAST = 0;
function annLang() { var l = DB.lang || 'uz'; return l === 'uz' ? 'uz' : /^(ru|ua|kz|kg|tj)$/.test(l) ? 'ru' : 'en'; }
function annKill(wpn, hs, streak) {
  if (true) return;                              // egasining so'rovi bilan o'chirildi (serverlarda o'z ovoz plaginlari bor)
  if (!S || S.ann === 0 || DEMO_PLAY) return;
  var t = now(); ANN_N = t - ANN_T <= 5000 ? ANN_N + 1 : 1; ANN_T = t;
  var id = ANN_N >= 5 ? 'ace' : ANN_N === 4 ? 'k4' : ANN_N === 3 ? 'k3' : ANN_N === 2 ? 'k2'
    : streak === 7 ? 'legend' : streak === 5 ? 'unstop' : streak === 3 ? 'onfire'
    : wpn === 'knife' ? 'knife' : wpn === 'grenade' ? 'grenade' : hs ? 'hs' : '';
  if (!id || (t - ANN_LAST < 700 && id === 'hs')) return;          // oddiy headshot ketma-ket ovozni bosib ketmasin
  ANN_LAST = t; cmd('play xclient/ann/' + annLang() + '/' + id + '.wav');
}
function bestServer() {
  var best = null;
  // do'stlar o'ynayotgan server, past ping va o'yinchi ko'pligi ustun
  function score(s) { var q = netQual(s); return (isX(s) ? 1000 : 0) + friendsAt(s.ip).length * 300 + Math.min(s.pl || 0, 28) * 10 - (s.ping || 300) / 4 - q.loss * 6 - q.jit / 2 - (UNSTABLE[s.ip] || 0) * 400; }   // yo'qotish va tebranish - lag; boshqa o'yinchilarda o'yin paytida ping sakragan server - pastroqda
  for (var ip in SRV) {
    var s = SRV[ip];
    if (!s.ok || s.pass || isFull(s)) continue;
    if (!best || score(s) > score(best)) best = s;
  }
  return best;
}
function quick() { var b = bestServer(); if (b) connect(b.ip); else toast(T('no_srv')); }

/* ============================================================ bosh ekran */
function pbar(s) { var p = s.max ? Math.min(100, Math.round(s.pl * 100 / s.max)) : 0; return '<span class="pbar"><i style="width:' + p + '%"></i></span>'; }
function renderHome() {
  var b = CONNECTED ? srv(CONNECTED) : bestServer();
  // turnir kartasi
  // X TOP serverlar
  var html = '', list = PROMO.concat((TOP.length ? TOP : PINNED).filter(function (ip) { return PROMO.indexOf(ip) < 0; }));
  each(list.slice(0, 5), function (ip, i) {
    var s = srv(ip);
    var meta = s.ok ? pbar(s) + s.pl + '/' + s.max + ' \u00b7 ' + esc(s.map) : (s.fail ? T('offline') : esc(ip));
    html += '<div class="tr' + (i === 0 ? ' r1' : '') + '" data-ip="' + esc(ip) + '"><div class="rk">' + (i + 1) + '</div>' +
      '<div class="nm">' + (PROMO.indexOf(ip) >= 0 ? '<span class="crown">\u2605</span>' : '') + flagOf(ip) + esc(s.name || ip) + '</div><div class="mt">' + meta + '</div>' +
      '<div class="go">' + esc(T('join')) + '</div></div>';
  });
  $('topList').innerHTML = html || '<div class="empty">' + esc(T('no_top')) + '</div>';
  // TOP hafta
  var wk = '';
  each(WEEK.slice(0, 3), function (u, i) {
    wk += '<div class="tr' + (i === 0 ? ' r1' : '') + '" data-act="stats"><div class="rk">' + (i + 1) + '</div>' +
      '<div class="nm one">' + crown(u) + esc(u.name) + '</div>' +
      '<div class="sc">' + u.k + ' <small>kill \u00b7 K/D ' + u.kd + '</small></div></div>';
  });
  if (CHAMP && CHAMP.name) wk += '<div class="mut" style="font-size:12px;padding:6px 2px 0">\u265b ' + esc(T('ch_last').replace('{n}', CHAMP.name).replace('{k}', CHAMP.k)) + '</div>';
  $('weekList').innerHTML = wk || '<div class="empty">' + esc(T('no_week')) + '</div>';
  // do'stlar onlayn
  var fr = '', on = 0;
  each(FRIENDS, function (f) {
    if (!f.online) return;
    on++;
    if (on > 3) return;
    var s = f.server ? srv(f.server) : null;
    fr += '<div class="tr"' + (f.server ? ' data-ip="' + esc(f.server) + '"' : ' style="cursor:default"') + '><div class="rk c av2" style="' + avStyle(f) + '">' + avInner(f, f.name) + '</div>' +
      '<div class="nm">' + crown(f) + esc(f.name) + '</div><div class="mt"><span class="gm">\u25cf</span> ' + esc((f.mob ? T('fr_mob') + (f.server ? ' \u00b7 ' : '') : '') + (f.server ? ((s && s.name) || f.server) + (f.map ? ' \u00b7 ' + f.map : '') : f.mob ? '' : T('fr_menu'))) + '</div>' +
      (f.server ? '<div class="go">' + esc(T('join')) + '</div>' : '') + '</div>';
  });
  if (ME && on < 3) fr += '<div class="tr frinv" data-act="ref"><div class="rk c">' + ico('gift') + '</div><div class="nm">' + esc(T('rf_cta')) + '</div><div class="mt">' + esc(T('rf_cta2')) + '</div></div>';
  $('frList').innerHTML = fr || '<div class="empty">' + (ME ? esc(T('no_fr')) : '<a data-act="login">' + esc(T('no_fr_login')) + '</a>') + '</div>';
  $('acct').style.display = ME || acxHidden() ? 'none' : ''; var xp = $('xpromo'); if (xp) xp.style.display = DB.pxx && now() - DB.pxx < 3 * 864e5 ? 'none' : ''; $('frCard').style.display = ME ? '' : 'none';
  var mc = $('mobCard'); if (mc) mc.style.display = ME && !LITE && !(DB.mobx && now() - DB.mobx < 14 * 864e5) ? '' : 'none';   // telefon ilovasi - akkaunti borlarga, yopsa 14 kun ko'rinmaydi
  $('frCnt').innerHTML = on ? on : '';
  $('mFriends').innerHTML = on ? esc(T('fr_on').replace('{n}', on)) : '';
  renderBar();
}
/* avatar: rasm bo'lsa rasm, bo'lmasa ism harfi + tanlangan rang */
function avStyle(u) { return u && /^#[0-9a-fA-F]{6}$/.test(u.avc || '') ? 'background:' + u.avc + ';' : ''; }
function avInner(u, name) {
  if (u && u.av) return '<img src="' + esc(u.av) + '" alt="">';
  return esc(String(name || (u && u.name) || 'X').charAt(0).toUpperCase() || 'X');
}
/* ---- admin paneldagi e'lonlar: pastki chiziqda yangiliklar lentasi (yangilik / reklama / muhim) ----
 * Bir nechta bo'lsa - navbat bilan almashadi. Matn joyiga sig'masa - yugurib o'tadi (o'yin ustida - yugurmaydi).
 * E'londa server IP bo'lsa - bosilganda shu serverga kiradi. */
var ANN = [], ANN_I = -1, ANN_TM = 0;
function loadAnn() { api('news', {}, function (r) { ANN = r.ok && r.ann ? r.ann : []; renderAnn(); }); }
function newsBox() {
  var el = $('bNews'), bar = $('bar');
  if (!el && bar) { el = document.createElement('div'); el.id = 'bNews'; bar.appendChild(el); }   // oxirida: chap va o'ng yozuvlar orasidagi bo'sh joyni egallaydi
  return el;
}
function renderAnn() {
  var el = newsBox(); if (!el) return;
  clearTimeout(ANN_TM);
  if (playing() && el.innerHTML) { ANN_TM = setTimeout(renderAnn, 8000); return; }   // o'yin paytida sahifani o'zgartirmaymiz (qayta chizish - FPS)
  if (!ANN.length) { el.style.display = 'none'; el.innerHTML = ''; return; }
  el.style.display = '';
  ANN_I = (ANN_I + 1) % ANN.length;
  var a = ANN[ANN_I], ty = /^(info|warn|promo)$/.test(a.type) ? a.type : 'info', ip = /^[a-z0-9.\-]{3,64}:\d{2,5}$/i.test(a.ip || '') ? a.ip : '';
  el.className = 'nw-' + ty + (ip ? ' nlink' : '');
  el.setAttribute('data-newsip', ip);
  el.innerHTML = '<div class="nw"><span class="ntg"><i></i>' + esc(T('nw_' + ty)) + '</span><div class="nb"><span class="nx in">' + esc(a.text) +
    (ip ? ' <b class="ngo">\u25b6 ' + esc(T('nw_go')) + '</b>' : '') + '</span></div></div>';
  var nb = el.querySelector('.nb'), nx = el.querySelector('.nx'), tg = el.querySelector('.ntg'), wait = 8000;
  var pad = tg ? tg.offsetWidth + 12 : 112; if (nb) nb.style.paddingLeft = pad + 'px';   // yorliq kengligi tilga qarab har xil
  var room = nb ? nb.offsetWidth - pad : 0;
  if (nb && nx && nx.offsetWidth > room + 4 && !lowFx()) {   // sig'madi - yuguruvchi qator
    var sec = Math.max(8, (nx.offsetWidth + room) / 70);
    nx.className = 'nx mq'; nx.style.webkitAnimationDuration = sec + 's';
    wait = sec * 1000;
  }
  if (ANN.length > 1 || wait > 8000) ANN_TM = setTimeout(renderAnn, wait);
}
function renderBar() {
  if (playing()) { UI_DIRTY = true; return; }
  each(['miResume', 'miPlist', 'miDisc'], function (id) { var e = $(id); if (e) e.style.display = CONNECTED ? '' : 'none'; });   // serverda: o'yinga qaytish, o'yinchilar, chiqish - menyuning tepasida
  var on = 0, cnt = 0;
  for (var ip in SRV) if (SRV[ip].ok) { cnt++; on += SRV[ip].pl || 0; }
  $('bOnline').innerHTML = on; $('bServers').innerHTML = cnt || MASTER.length;
  var nm = ME ? ME.name : ((S && S.name) || T('guest_name'));
  $('meName').innerHTML = ME ? nickHtml(ME, nm) : esc(nm);
  var mc = $('mChest'); if (mc) { var cn = ME && ME.chests ? ME.chests : 0; mc.innerHTML = cn ? String(cn) : ''; mc.style.display = cn ? 'inline-block' : 'none'; }
  $('meAv').innerHTML = avInner(ME, nm); $('meAv').style.cssText = avStyle(ME); $('meAv').className = 'av' + frameCls(ME);
  $('meLvl').innerHTML = ME ? esc(T('lvl').replace('{n}', ME.level)) : '';
  $('meXp').style.width = ME ? Math.round(ME.lvlxp * 100 / (ME.lvlmax || 1000)) + '%' : '0';
  $('meVip').style.display = ME && ME.vip ? '' : 'none';
  $('bCloud').innerHTML = !ME && !CONNECTED ? '<a class="lgin" data-act="login">' + esc(T('ac_short')) + ' \u2192</a>' : esc(CONNECTED ? T('st_in') + (srv(CONNECTED).name || CONNECTED) : (ME.cloudt ? T('b_saved') : ''));
  $('bVer').innerHTML = esc((VERSION ? 'v' + VERSION + ' \u00b7 ' : '') + 'X CLIENT');
}

/* ============================================================ KIRISH ekrani */
var lgReg = false;
function openLogin() { openModal('mdLogin'); renderLoginForm(); setTimeout(function () { try { (lgReg && $('lgLogin').value ? $('lgPass') : $('lgLogin')).focus(); } catch (e) {} }, 50); }
/* login: saytdagi login_norm bilan bir xil - bo'shliq -> _, o'/g' tutuqlari olib tashlanadi, kirill -> lotin */
var LG_TR = { 'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'yo', 'ж': 'j', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u', 'ф': 'f', 'х': 'x', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'sh', 'ъ': '', 'ы': 'i', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya', 'ў': 'o', 'қ': 'q', 'ғ': 'g', 'ҳ': 'h' };
function loginNorm(v) {
  v = String(v || '').replace(/^\s+|\s+$/g, ''); var o = '';
  for (var i = 0; i < v.length; i++) { var c = v.charAt(i), l = c.toLowerCase(); if (LG_TR.hasOwnProperty(l)) { var t = LG_TR[l]; o += c !== l && t ? t.charAt(0).toUpperCase() + t.slice(1) : t; } else o += c; }
  o = o.replace(/['`\u02bb\u02bc\u2018\u2019]/g, '').replace(/[\s.\-]+/g, '_').replace(/[^A-Za-z0-9_]/g, '').replace(/_+/g, '_');
  return o.slice(0, 20);
}
/* ro'yxatdan o'tishda: login maydoniga o'yindagi nik (klan tegisiz) o'zi yoziladi; yozilayotganda band/bo'shligi tekshiriladi */
var LGCHK_TM = 0, LGCHK_V = '';
function lgCheck() {
  clearTimeout(LGCHK_TM); var el = $('lgChk'); if (!el) return;
  if (!lgReg) { el.innerHTML = ''; el.className = 'lchk'; return; }
  var v = loginNorm($('lgLogin').value);
  if (v.length < 3) { el.innerHTML = $('lgLogin').value ? esc(T('lg_short')) : ''; el.className = 'lchk no'; return; }
  LGCHK_TM = setTimeout(function () {
    LGCHK_V = v;
    api('login_check', { login: v }, function (r) {
      if (!lgReg || LGCHK_V !== v || !r.ok) return;
      if (r.free) { el.className = 'lchk ok'; el.innerHTML = '\u2713 ' + esc(T('lg_free').replace('{l}', r.login)); }
      else { el.className = 'lchk no'; el.innerHTML = '\u2717 ' + esc(T('lg_busy')) + (r.sug ? ' <a data-lgsug="' + esc(r.sug) + '">' + esc(r.sug) + '</a>' : ''); }
    });
  }, 450);
}
function lgKbCheck() {
  var el = $('lgKb'); if (!el) return;
  el.innerHTML = /[\u0400-\u04FF]/.test($('lgPass').value) ? '\u26a0 ' + esc(T('lg_kbru')) : '';
}
(function () {
  var lg = $('lgLogin'), pw = $('lgPass');
  if (lg) lg.addEventListener('input', lgCheck, false);
  if (pw) { pw.addEventListener('input', lgKbCheck, false); pw.addEventListener('keyup', lgKbCheck, false); }
})();
function renderLoginForm() {
  $('lgTitle').innerHTML = esc(T(lgReg ? 'lg_reg' : 'lg_title'));
  $('lgGo').innerHTML = esc(T(lgReg ? 'lg_regbtn' : 'lg_go'));
  $('lgSwitch').innerHTML = esc(T(lgReg ? 'lg_tolog' : 'lg_toreg'));
  $('lgEmail').style.display = $('lgEmailL').style.display = $('lgRef').style.display = $('lgRefL').style.display = lgReg ? '' : 'none';
  $('lgErr').innerHTML = '';
  if (lgReg && !$('lgLogin').value) { var nk = (S && S.name) || MYNAME || ''; nk = loginNorm(nk); if (nk.length >= 3 && !/^player/i.test(nk)) $('lgLogin').value = nk; }
  lgCheck(); lgKbCheck();
}
function doLogin() {
  var lg = $('lgLogin').value.replace(/^\s+|\s+$/g, ''), pw = $('lgPass').value;
  $('lgErr').innerHTML = esc(T('lg_wait'));
  api(lgReg ? 'register' : 'login', lgReg ? { login: lg, pass: pw, email: $('lgEmail').value, ref: $('lgRef').value.replace(/^\s+|\s+$/g, '') } : { login: lg, pass: pw }, function (r) {
    if (!r.ok) { $('lgErr').innerHTML = esc(r.msg || 'Xato'); return; }
    if (lgReg && r.me && r.me.login && r.me.login !== lg) toast(T('lg_norm').replace('{l}', r.me.login), 9000);   // "Ali Valiyev" -> Ali_Valiyev
    $('lgPass').value = '';
    if (lgReg && $('lgRef').value) setTimeout(function () { toast(r.referr ? T('rf_bad') + ': ' + r.referr : T('rf_ok'), 8000); }, 1500);
    DB.forget = $('lgRemember').className.indexOf('on') >= 0 ? 0 : 1;
    afterLogin(r);
  });
}

/* parolni tiklash: login/email -> emailga kod -> kod + yangi parol */
function forgot() {
  ask(T('rs_ask'), function (who) {
    who = String(who || '').replace(/^\s+|\s+$/g, '');
    if (!who) return;
    toast(T('lg_wait'));
    api('reset_req', { login: who }, function (r) {
      if (!r.ok) return toast(r.msg || 'Xato', 7000);
      toast(T('rs_sent').replace('{e}', r.email), 7000);
      ask(T('rs_code').replace('{e}', r.email), function (code, np) {
        api('reset_do', { login: r.login, code: code, newpass: np }, function (r2) {
          if (!r2.ok) return toast(r2.msg || 'Xato', 6000);
          DB.forget = 0;
          afterLogin(r2);
          toast(T('rs_ok'), 5000);
        });
      }, true, false, false, true);
    });
  });
}

/* ============================================================ SERVERLAR oynasi */
var srvTab = 'internet', srvSel = '', srvSort = 'pl', srvDesc = true;
var FLT = { ping: false, notempty: false, notfull: false };
/* LAN: menyu tarmoqni o'zi ko'ra olmaydi - launcher lokal tarmoqqa keng tarqatma so'rov yuboradi (CS ning "Локальная сеть" kabi)
 * va topganini saytga qo'yadi; menyu 3-9 soniya ichida oladi. Launchersiz (NextClient o'zi) - faqat IP bo'yicha qo'shish */
var LAN_IPS = [], LAN_T0 = 0, LAN_ST = '';
function lanStart() {
  if (!PCID) { LAN_ST = 'nol'; renderServers(); return; }
  if (now() - LAN_T0 < 5000) return;
  LAN_T0 = now(); LAN_ST = 'scan'; vidCmd('lan', '', null, true); renderServers();
  var tries = 0;
  (function poll() {
    setTimeout(function () {
      api('langet', { d: PCID }, function (r) {
        tries++;
        if (r && r.ok && r.t && r.now && r.t >= r.now - Math.round((now() - LAN_T0) / 1000) - 2) {
          LAN_IPS = [];
          each(r.list || [], function (x) { var s = srv(x.ip); s.ok = true; s.fail = false; s.name = x.name || x.ip; s.map = x.map || ''; s.pl = x.pl | 0; s.max = x.max | 0; LAN_IPS.push(x.ip); query(x.ip, true); });
          LAN_ST = LAN_IPS.length ? '' : 'none'; if (srvTab === 'lan') { if (!srvSel && LAN_IPS[0]) srvSel = LAN_IPS[0]; renderServers(); }
          return;
        }
        if (tries < 4) poll(); else { LAN_ST = 'none'; if (srvTab === 'lan') renderServers(); }
      });
    }, tries ? 3000 : 3500);
  })();
}
function openServers(tab) { openModal('mdServers'); setSrvTab(tab || 'internet'); each(tabIps(), function (ip) { query(ip, true); }); }
function setSrvTab(tab) {
  if (tab !== srvTab) SORT_USER = false;
  srvTab = tab;
  each(document.querySelectorAll('#srvTabs a'), function (a) { a.className = a.getAttribute('data-tab') === tab ? 'on' : ''; });
  if (tab === 'friends') loadFriends();
  if (tab === 'lan') lanStart();
  var ips = tabIps();
  each(ips, function (ip) { query(ip); });
  if (!srvSel || ips.indexOf(srvSel) < 0) srvSel = ips[0] || '';
  if (srvSel) loadPlayers(srvSel);
  renderServers();
}
function tabIps() {
  if (srvTab === 'favs') { var fv = PROMO_FAV.slice(); each(DB.fav, function (ip) { if (fv.indexOf(ip) < 0) fv.push(ip); }); return fv; }
  if (srvTab === 'top') return TOP.slice();
  if (srvTab === 'lan') return LAN_IPS.slice();
  if (srvTab === 'friends') { var o = []; each(FRIENDS, function (f) { if (f.server && o.indexOf(f.server) < 0) o.push(f.server); }); return o; }
  if (srvTab === 'history') { var seen = {}, out = []; each(DB.hist, function (h) { if (!seen[h.ip]) { seen[h.ip] = 1; out.push(h.ip); } }); return out; }
  var net = svcIps(); each(MASTER, function (ip) { if (net.indexOf(ip) < 0) net.push(ip); }); return net;
}
function histOf(ip) { for (var i = 0; i < DB.hist.length; i++) if (DB.hist[i].ip === ip) return DB.hist[i]; return null; }
function friendsAt(ip) { var n = []; each(FRIENDS, function (f) { if (f.server === ip) n.push(f.name); }); return n; }
/* ---- o'z dropdown'imiz ---- */
var FMAP = '', FMODE = '', DD = null;
function ddItems(kind) {
  var out = [], maps = {}, keys = [], ip, m;
  if (kind === 'map') {
    for (ip in SRV) if (SRV[ip].ok && SRV[ip].map) maps[SRV[ip].map] = 1;
    for (m in maps) keys.push(m);
    keys.sort();
    out.push(['', T('f_map')]);
    each(keys, function (mp) { out.push([mp, mp]); });
  } else if (kind === 'mode') {
    out.push(['', T('f_mode')]);
    each(['classic', 'zm', 'awp', 'aim', 'dm', 'gg', 'jail', 'kz', 'other'], function (k) { out.push([k, T('md_' + k)]); });
  } else if (kind === 'xpre') {
    each(XPRE, function (p) { out.push([p[0], T(p[1])]); });
  } else if (kind === 'xsz') {
    each(SZ, function (z, i) { out.push([z, 'x' + (i + 1)]); });
  } else if (kind === 'res') {
    var mon = monRes();   // monitor o'lchami (launcher aytadi); o'yin ichida screen.* - o'yinning joriy o'lchami, monitor emas
    out.push(['', T('sy_res_auto') + (mon ? ' (' + mon[0] + ' \u00d7 ' + mon[1] + ')' : '')]);
    var sw = mon ? mon[0] : screen.width || 1920, sh = mon ? mon[1] : screen.height || 1080, seen = {}, ar = scrAr();
    var RES = { '43': ['1600x1200', '1280x960', '1152x864', '1024x768', '800x600', '640x480'], '169': ['2560x1440', '1920x1080', '1600x900', '1366x768', '1280x720'],
      '1610': ['1920x1200', '1680x1050', '1440x900', '1280x800'] };
    each([sw + 'x' + sh].concat(RES[ar] || []), function (r) {
      if (!seen[r] && (r !== sw + 'x' + sh || resAr(r) === ar)) { seen[r] = 1; out.push([r, r.replace('x', ' \u00d7 ')]); }
    });
  }
  return out;
}
/* ekran formati (NextClient "Формат экрана"): 4:3 / 16:9 / 16:10 - o'lchamlar ro'yxatini saralaydi */
function monRes() { var m = /^(\d{3,5})x(\d{3,5})$/.exec(OPTS && OPTS.scr || ''); return m ? [+m[1], +m[2]] : null; }
/* tanlangan o'lcham monitordan ancha kichik (eski tanlov qolib ketgan) - rasm xira. Lagni tuzatish ataylab kichraytirgan bo'lsa - aytmaymiz */
function resSmall() { var mon = monRes(), m = /^(\d+)x(\d+)$/.exec(OPTS && OPTS.res || ''); return !!(mon && m && +m[1] < mon[0] * 0.75 && OPTS.res !== DB.lagres); }
function resAr(r) { var m = /^(\d+)x(\d+)$/.exec(r || ''); if (!m) return ''; var k = m[1] / m[2]; return k < 1.45 ? '43' : k < 1.7 ? '1610' : '169'; }
function scrAr() { return DB.ar || resAr(OPTS.res) || resAr(OPTS.scr) || resAr((screen.width || 1920) + 'x' + (screen.height || 1080)) || '169'; }
function ddValue(kind) { return kind === 'map' ? FMAP : kind === 'mode' ? FMODE : kind === 'xpre' ? E.xp : kind === 'xsz' ? E.xs : OPTS.res || ''; }
function ddLabel(kind) {
  var v = ddValue(kind), items = ddItems(kind);
  for (var i = 0; i < items.length; i++) if (items[i][0] === v) return items[i][1];
  return v || items[0][1];
}
function ddOpen(el) {
  var kind = el.getAttribute('data-dd'), list = $('ddList'), h = '', v = ddValue(kind);
  if (DD === kind && list.style.display === 'block') { ddClose(); return; }
  DD = kind;
  each(ddItems(kind), function (it) { h += '<a class="' + (it[0] === v ? 'on' : '') + '" data-ddv="' + esc(it[0]) + '">' + esc(it[1]) + '</a>'; });
  list.innerHTML = h;
  // joylashuv: element ostida (#app koordinatalarida)
  var x = 0, y = 0, n = el;
  while (n && n.id !== 'app') { x += n.offsetLeft; y += n.offsetTop; n = n.offsetParent; }
  list.style.left = x + 'px'; list.style.top = (y + el.offsetHeight + 2) + 'px'; list.style.width = Math.max(170, el.offsetWidth) + 'px';
  list.style.display = 'block';
}
function ddClose() { DD = null; $('ddList').style.display = 'none'; }
function ddPick(v) {
  var kind = DD; ddClose();
  if (kind === 'map') { FMAP = v; renderServers(); }
  else if (kind === 'mode') { FMODE = v; renderServers(); }
  else if (kind === 'res') { OPTS.res = v; saveOpts(); showSetTab(setTab); }
  else if (kind === 'xpre') { each(XPRE, function (p) { if (p[0] === v) { E.xp = v; E.xt = p[2]; E.xs = p[3]; } }); showSetTab('hud'); }
  else if (kind === 'xsz') { E.xs = v; E.xp = presetOf(E); showSetTab('hud'); }
}
function fillSelects() {
  $('fMap').getElementsByTagName('span')[0].innerHTML = esc(ddLabel('map'));
  $('fMode').getElementsByTagName('span')[0].innerHTML = esc(ddLabel('mode'));
}
function renderServers() {
  if (curModal !== 'mdServers') return;
  var isHist = srvTab === 'history', isFav = srvTab === 'favs', isFr = srvTab === 'friends', isNet = srvTab === 'internet';
  $('favCnt').innerHTML = DB.fav.length ? '(' + DB.fav.length + ')' : '';
  $('h5').innerHTML = esc(isHist || isFav ? T('h_last') : isFr ? T('h_friend') : '');
  $('h6').innerHTML = esc(isHist ? T('h_res') : '');
  $('quickBtn').style.display = isNet ? '' : 'none';
  $('addIpBtn').style.display = '';                 // IP bo'yicha qo'shish - hamma bo'limda (sevimlilarga qo'shiladi)
  $('favNote').style.display = isFav && ME ? '' : 'none';
  $('clearHist').style.display = isHist ? '' : 'none';
  $('fMap').style.display = $('fMode').style.display = isNet ? '' : 'none';
  each(document.querySelectorAll('#srvTools .chip'), function (c) { c.style.display = isFav || isHist ? 'none' : ''; c.className = 'chip' + (FLT[c.getAttribute('data-flt')] ? ' on' : ''); });
  fillSelects();
  var extraH = isHist ? 80 : isFav ? 150 : 0;
  $('srvList').style.bottom = (10 + extraH) + 'px';
  $('srvExtra').style.height = extraH ? (extraH - 10) + 'px' : '0';

  var qs = ($('srvSearch').value || '').toLowerCase(), fmap = FMAP, fmode = FMODE;
  var rows = [];
  each(tabIps(), function (ip) {
    var s = srv(ip);
    if (isNet && !s.ok) return;
    if (qs && ((s.name || '') + ' ' + ip + ' ' + (s.map || '')).toLowerCase().indexOf(qs) < 0) return;
    if (isNet && fmap && s.map !== fmap) return;
    if (isNet && fmode && modeOf(s) !== fmode) return;
    if (!isFav && !isHist) {
      if (FLT.ping && !(s.ok && s.ping < 50)) return;
      if (FLT.notempty && !(s.pl > 0)) return;
      if (FLT.notfull && isFull(s)) return;
      if (FLT.nopw && s.pass) return;
    }
    rows.push(s);
  });
  if (!isHist) {
    rows.sort(function (a, b) {
      if (isFav) { var pa = PROMO_FAV.indexOf(a.ip) >= 0, pb = PROMO_FAV.indexOf(b.ip) >= 0; if (pa !== pb) return pa ? -1 : 1; }
      if (srvTab === 'top') return TOP.indexOf(a.ip) - TOP.indexOf(b.ip);   // reklama tartibi saqlanadi
      if (isX(a) !== isX(b)) return isX(a) ? -1 : 1;
      var va = a[srvSort], vb = b[srvSort];
      if (srvSort === 'name' || srvSort === 'map') { va = String(va || '').toLowerCase(); vb = String(vb || '').toLowerCase(); return (va < vb ? -1 : va > vb ? 1 : 0) * (srvDesc ? -1 : 1); }
      va = va == null ? 9999 : va; vb = vb == null ? 9999 : vb;
      return (va - vb) * (srvDesc ? -1 : 1);
    });
  }
  var html = '';
  function rowHtml(s) {
    var html = '';
    var pc = s.ping < 50 ? 'g' : s.ping < 100 ? 'y' : 'r', h = (isHist || isFav) ? histOf(s.ip) : null, c5 = '', c6 = '';
    if (h) c5 = isHist ? fmtTime(h.t) + (h.d ? ' \u00b7 ' + fmtDur(h.d) : '') : fmtTime(h.t);
    if (isFr) c5 = esc(friendsAt(s.ip).join(', '));
    if (isHist && h) c6 = (h.k || h.x) ? (h.k || 0) + ' / ' + (h.x || 0) : '\u2014';
    html += '<div class="sr' + (s.ip === srvSel ? ' on' : '') + '" data-ip="' + esc(s.ip) + '">' +
      '<span class="c0' + (isFavIp(s.ip) ? ' f' : '') + '" data-fav="' + esc(s.ip) + '">\u2605</span>' +
      c1row(s, (s.name || (h && h.name) || s.ip), s.pass ? '<span class="vb">PW</span>' : '') +
      '<span class="c2">' + (s.ok ? pbar(s) + s.pl + '/' + s.max : (s.fail ? '<span class="rd">' + T('offline') + '</span>' : '...')) + '</span>' +
      '<span class="c3">' + esc(s.map || (h && h.map) || '') + '</span>' +
      '<span class="c4">' + (s.ok ? (s.blk ? '<span class="pblk" title="' + esc(T('blk_t')) + '">?</span>' : '<i class="dot ' + pc + '"></i>' + s.ping) : '') + '</span>' +
      '<span class="c5">' + c5 + '</span><span class="c6">' + c6 + '</span></div>';
    return html;
  }
  if (isNet && !SORT_USER && svcAny()) {
    // saytdagi kabi: avval TOP, keyin BOOST, keyin VIP xizmatini olganlar (sayt tartibida), so'ng qolganlari
    var used = {};
    each(SVC_ORDER, function (g) {
      var part = '';
      each(SVC[g[0]] || [], function (ip) { for (var i = 0; i < rows.length; i++) if (rows[i].ip === ip) { part += rowHtml(rows[i]); used[ip] = 1; break; } });
      if (part) html += '<div class="sgh"><b class="svb ' + g[0] + '">' + g[1] + '</b>' + esc(T('sv_' + g[0])) + '</div>' + part;
    });
    var rest = '';
    each(rows, function (s) { if (!used[s.ip]) rest += rowHtml(s); });
    if (rest) html += (html ? '<div class="sgh">' + esc(T('sv_other')) + '</div>' : '') + rest;
  } else each(rows, function (s) { html += rowHtml(s); });
  var emptyMsg = srvTab === 'lan' ? T('lan_' + (LAN_ST || 'none')) : isFav ? T('empty_favs') : isHist ? T('empty_hist') : isFr ? (ME ? T('empty_frsrv') : T('no_fr_login')) : (isNet && running ? T('loading') : T('empty_list'));
  var lst = $('srvList'), st = lst.scrollTop;
  if (srvTab === 'lan') html = '<div class="lanhost"><a class="btn red" data-act="lanhost">+ ' + esc(T('lh_btn')) + '</a><span>' + esc(T('lh_s')) + '</span>' + refBtn('') + '</div>' + html;   // o'z serverini ochish - do'stlar shu ro'yxatda ko'radi
  lst.innerHTML = html || '<div class="empty">' + esc(emptyMsg) + '</div>';
  if (srvTab === 'lan' && !rows.length) lst.innerHTML += '<div class="empty">' + esc(emptyMsg) + '</div>';
  lst.scrollTop = st;

  if (isHist) renderHistStats();
  else if (isFav) $('srvExtra').innerHTML = '<div class="tip">' + T('fav_tip') + '</div>' +
      '<div class="tgl">' + esc(T('fav_n1')) + '<div class="tg' + (DB.notifyFav !== 0 ? ' on' : '') + '" data-dbtg="notifyFav"><i></i></div></div>' +
      '<div class="tgl">' + esc(T('fav_n2')) + '<div class="tg' + (DB.notifyFr !== 0 ? ' on' : '') + '" data-dbtg="notifyFr"><i></i></div></div>';
  else $('srvExtra').innerHTML = '';
  var on = 0, cnt = 0;
  for (var ip in SRV) if (SRV[ip].ok) { cnt++; on += SRV[ip].pl || 0; }
  $('srvFoot').innerHTML = esc(isFav ? DB.fav.length + ' \u2605' : T('srv_count').replace('{n}', cnt).replace('{p}', on));
  $('favBtn').innerHTML = '\u2605 ' + esc(isFavIp(srvSel) ? T('from_favs') : T('to_favs'));
  renderInfo();
}
function renderHistStats() {
  var today = new Date().toDateString(), tSec = 0, kills = 0, k = 0, x = 0, cnt = {}, best = '', bestN = 0;
  each(DB.hist, function (h) {
    var d = h.d || (h === CUR && CONNECTED ? Math.round((now() - h.t) / 1000) : 0);
    if (new Date(h.t).toDateString() === today) { tSec += d; kills += h.k || 0; }
    k += h.k || 0; x += h.x || 0;
    cnt[h.ip] = (cnt[h.ip] || 0) + d + 1;
    if (cnt[h.ip] > bestN) { bestN = cnt[h.ip]; best = h.ip; }
  });
  var bn = best ? (srv(best).name || (histOf(best) || {}).name || best) : '-';
  var box = function (i, key, v) { return '<div class="hs" style="left:' + (i * 216) + 'px"><small>' + esc(T(key)) + '</small><b>' + esc(v) + '</b></div>'; };
  $('srvExtra').innerHTML = box(0, 'hs_today', fmtDur(tSec)) + box(1, 'hs_kills', String(kills)) + box(2, 'hs_most', bn) + box(3, 'hs_kd', x ? (k / x).toFixed(2) : (k ? k.toFixed(2) : '-'));
}
var PLAYERS = {};
function srvq(ip, cb) {                          // sayt orqali server so'rovi (srvq.php): {ok,name,map,pl,max,bots,players:[{name,score,time}]}
  try {
    var x = new XMLHttpRequest(), done = false;
    x.open('GET', 'srvq.php?ip=' + encodeURIComponent(ip), true);
    x.onreadystatechange = function () { if (x.readyState !== 4 || done) return; done = true; var r = null; try { r = JSON.parse(x.responseText); } catch (e) {} cb(r); };
    setTimeout(function () { if (!done) { done = true; try { x.abort(); } catch (e) {} cb(null); } }, 9000);
    x.send(null);
  } catch (e) { cb(null); }
}
function setPlayers(ip, list) {
  list = list || [];
  list.sort(function (a, b) { return (b.score || 0) - (a.score || 0); });
  PLAYERS[ip] = list; if (ip === srvSel) renderInfo();
}
function loadPlayers(ip) {
  if (CONNECTED && normIp(ip) === CONNECTED) return queryViaSite(ip, true);
  /* NextClient ro'yxat bermasa (yoki server o'yinchi bor desa-yu ro'yxat bo'sh kelsa) - sayt orqali */
  var site = function () {
    srvq(ip, function (r) {
      if (r && r.ok) {                           // NextClient "0" degan bo'lsa ham - sayt ko'rgan sonni qo'yamiz
        var s = srv(ip); s.ok = true; s.fail = false; s.pl = r.pl || 0; s.max = r.max || s.max; if (r.map) s.map = clean(r.map); renderSoon();
      }
      setPlayers(ip, r && r.ok && r.players ? r.players.map(function (x) { return { name: x.name, score: x.score, timePlayedSeconds: x.time }; }) : []);
    });
  };
  if (!NC || !NC.matchmaking || !NC.matchmaking.getPlayersInfo) return site();
  try {
    NC.matchmaking.getPlayersInfo(ip).then(function (list) {
      if (!list || !list.length) return site();   // bo'sh ro'yxat - saytdan tekshiramiz (ba'zi serverlarni NextClient noto'g'ri o'qiydi)
      setPlayers(ip, list);
    }, site);
  } catch (e) { site(); }
}
/* ---- serverning soatlar bo'yicha gavjumligi ---- */
var SHIST = {};
function histBars(ip) {
  var h = SHIST[ip];
  if (!h || now() - h.at > 600000) {
    if (!h || !h.busy) { SHIST[ip] = { at: now(), busy: 1, h: h && h.h }; api('srvhist', { ip: ip }, function (r) { SHIST[ip] = { at: now(), h: r.ok ? r.h : null, max: r.max || 32, now: r.now }; if (srvSel === ip) renderInfo(); }); }
  }
  if (!h || !h.h) return '';
  var any = false, mx = 1, bars = '';
  each(h.h, function (v) { if (v >= 0) { any = true; if (v > mx) mx = v; } });
  if (!any) return '';
  each(h.h, function (v, i) {
    var ht = v < 0 ? 2 : Math.max(2, Math.round(v / mx * 34));
    bars += '<i class="' + (i === h.now ? 'on' : '') + '" style="height:' + ht + 'px" title="' + i + ':00 — ' + (v < 0 ? '?' : v) + '"></i>';
  });
  return '<div class="ph">' + esc(T('hs_busy')) + '</div><div class="hbars">' + bars + '</div><div class="hbl"><span>0</span><span>6</span><span>12</span><span>18</span><span>23</span></div>';
}
function sendStats() {
  var list = [], seen = {};
  each(svcIps().concat(TOP, PROMO_FAV, DB.fav, CONNECTED ? [CONNECTED] : []), function (ip) {
    var s = SRV[ip];
    if (seen[ip] || !s || !s.ok || list.length >= 40) return;
    seen[ip] = 1; list.push([ip, s.pl || 0, s.max || 32]);
  });
  if (list.length) api('srvstat', { s: JSON.stringify(list) });
}
/* VIP/admin kirish: server oynasida doim ochiq login va parol joyi */
/* parolli server (sv_password): server oynasida - kirish paroli holati va "Parol bilan kirish" */
function spwInline(ip) {
  var s = srv(ip), has = DB.spw && DB.spw[ip];
  if (!s.pass && !has) return '';
  return '<div class="spwin">' + ico('key') + ' <b>' + esc(T('spw_t')) + '</b> <span class="mut">' + esc(T(has ? 'spw_saved' : 'spw_need')) + '</span>' +
    '<a class="btn red" data-act="spwgo">' + esc(T(has ? 'spw_go2' : 'spw_go')) + '</a>' + (has ? '<a class="btn" data-act="spwdel">' + esc(T('pw_delb')) + '</a>' : '') + '</div>';
}
function pwInline(ip) {
  var p = srvPw(ip) || {}; PW_IP = ip;
  return '<div class="pwin" title="' + esc(T('pw_short')) + '"><div class="pwh"><a data-act="srvpw">?</a>' + ico('key') + ' ' + esc(T('pw_title')) + (p.pw ? '<span class="gr"> \u2713 ' + esc(T('pw_ok')) + '</span>' : '') + '</div>' +
    '<input class="tx" id="pwL" maxlength="31" value="' + esc(p.login || '') + '" placeholder="' + esc(T('pw_login')) + '">' +
    '<input class="tx" id="pwP" type="password" maxlength="40" value="' + esc(p.pw || '') + '" placeholder="' + esc(T('pw_pass')) + '">' +
    '<a class="btn red" data-act="pwsave">' + esc(T('pw_save')) + '</a>' + (p.pw ? '<a class="btn" data-act="pwdel">' + esc(T('pw_delb')) + '</a>' : '') +
    '</div>';
}
function renderInfo() {
  var box = $('srvInfo');
  /* ro'yxat har necha soniyada yangilanadi - yozilayotgan login/parol o'chib ketmasin */
  var ae = document.activeElement, keep = PW_IP === srvSel && $('pwL') ? { l: $('pwL').value, p: $('pwP').value, f: ae && (ae.id === 'pwL' || ae.id === 'pwP') ? ae.id : '' } : null;
  renderInfo2(box);
  if (keep && $('pwL')) { $('pwL').value = keep.l; $('pwP').value = keep.p; if (keep.f) try { var fe = $(keep.f); fe.focus(); fe.selectionStart = fe.selectionEnd = fe.value.length; } catch (e) {} }
}
function renderInfo2(box) {
  if (!srvSel) { box.innerHTML = '<div class="empty">' + esc(T('empty_list')) + '</div>'; return; }
  var s = srv(srvSel), pl = PLAYERS[srvSel], ph = '', h = histOf(srvSel);
  var onIt = CONNECTED && normIp(srvSel) === CONNECTED && ME, myN = S ? fullName(S) : '';
  if (pl && pl.length) each(pl.slice(0, 40), function (p) { var nm = clean(p.name) || '';
    ph += '<div class="pl">' + esc(nm || '...') + (onIt && nm && nm !== myN && nm !== MYNAME ? '<a class="plrep" data-cheat="' + esc(nm) + '" title="' + esc(T('ch_btn')) + '">&#9873;</a>' : '') + '<span>' + (p.score || 0) + ' \u00b7 ' + fmtShort(p.timePlayedSeconds) + '</span></div>'; });
  else ph = '<div class="empty" style="padding:8px 0">' + esc(pl ? T('no_players') : T('loading')) + '</div>';
  var pc = s.ping < 50 ? 'gr' : s.ping < 100 ? 'ye' : 'rd', mode = modeOf(s), fr = friendsAt(srvSel);
  var mapn = s.map || (h && h.map) || '';
  box.innerHTML = '<div class="mp' + (mode === 'zm' ? ' zm' : mode === 'awp' ? ' aw' : '') + '">' +
    (/^[\w\-.]{2,40}$/.test(mapn) ? '<img src="map.php?m=' + encodeURIComponent(mapn.toLowerCase()) + '" alt="" onerror="this.style.display=\'none\'">' : '') +
    '<span>' + esc(mapn || '?') + '</span></div>' +
    '<h3>' + flagOf(srvSel) + esc(s.name || (h && h.name) || srvSel) + '</h3><div class="ip"><input class="ipin" readonly value="' + esc(srvSel) + '"><a class="cpy" data-copyip="' + esc(srvSel) + '">' + esc(T('ip_copy')) + '</a></div>' +
      spwInline(srvSel) + pwInline(srvSel) +
    '<div class="ln">' + esc(T('ph_players')) + ' <b>' + (s.ok ? s.pl + '/' + s.max : '-') + '</b><span class="r ' + (s.blk ? 'mut' : pc) + '">' + (s.ok ? (s.blk ? esc(T('blk_s')) : '\u25cf ' + s.ping + ' ms') : esc(T('offline'))) + '</span></div>' +
    (s.ok && s.blk ? '<div class="mut" style="font-size:12px;margin:-4px 0 8px">' + esc(T('blk_t')) + '</div>' : '') +
    histBars(srvSel) +
    '<div class="ph">' + esc(T('ph_players')) + '</div><div class="pls">' + ph + '</div>' +
    (fr.length ? '<div class="fr3">' + esc(T('fr_here')) + '<span class="gr">' + esc(fr.join(', ')) + '</span></div>' : '') +
    (isX(s) ? '<div class="note">' + esc(T('vip_note')) + '</div>' : '');
}
function toggleFav(ip) {
  if (!ip) return;
  var i = DB.fav.indexOf(ip);
  if (i >= 0) { DB.fav.splice(i, 1); toast(T('removed')); } else { DB.fav.unshift(ip); query(ip); toast(T('added')); }
  persist(); cloudSave(); renderAll();
}

/* ============================================================ TURNIRLAR / DO'STLAR oynasi */
var sideMode = '';
function openSide(mode, title, body) {
  sideMode = mode;
  if (curModal !== 'mdSide') openModal('mdSide');
  $('sideTitle').innerHTML = esc(title); $('sideBody').innerHTML = body;
  layoutCheck('side/' + mode);
}
var SUGG = null;
var FR_REQ = [], FR_SENT = [], FR_Q = '', FR_SUG = null, FR_TM = 0, CHAT = null, CHAT_TM = 0, NOTIF_TM = 0, NOTIF_SEEN = {};
/* profil ramkasi: chempion - oltin, 20+ daraja - binafsha, 10+ - ko'k, 5+ - yashil */
/* reyting unvoni, rangli nik */
var RANKS = [['bronze', 0], ['silver', 400], ['gold', 900], ['plat', 1600], ['diamond', 2500], ['legend', 3600]];
function rankBadge(u) { var r = (u && u.rank) || 'bronze'; return '<span class="rkb rk-' + r + '">' + esc(T('rk_' + r)) + '</span>'; }
function nickHtml(u, name) { return '<span class="nk' + (u && u.nc ? ' nk-' + u.nc : '') + '">' + esc(name || (u && u.name) || '') + '</span>'; }
function frameCls(u) { if (!u) return ''; if (u.frame) return ' ' + u.frame; if (crown(u)) return ' fgold'; var l = u.level || 1; return l >= 20 ? ' fpurp' : l >= 10 ? ' fblue' : l >= 5 ? ' fgreen' : ''; }
function frAv(f) { return '<div class="rk c av2' + frameCls(f) + '" style="' + (f.online ? avStyle(f) : 'background:#4a4048') + '">' + avInner(f, f.name) + '</div>'; }
function openFriends() {
  if (!ME) { openLogin(); return; }
  var keep = $('frIn') ? $('frIn').value : FR_Q;
  var h = '<div class="addf"><input class="tx big" id="frIn" type="text" maxlength="20" autocomplete="off" placeholder="' + esc(T('fr_add')) + '" value="' + esc(keep) + '">' +
    '<a class="btn red" data-act="fradd">' + esc(T('fr_addb')) + '</a><div class="frsug" id="frSug"' + (FR_SUG ? '' : ' style="display:none"') + '>' + frSugHtml() + '</div></div>';
  h += '<div class="frtools"><a class="btn" data-act="clan">' + ico('flag') + ' ' + esc(T('cl_btn')) + (ME.clan ? ' [' + esc(ME.clan.tag) + ']' : '') + '</a><a class="btn" data-act="ref">\u2709 ' + esc(T('rf_btn')) + '</a></div>';
  if (SUGG && SUGG.list.length && !FR_Q) {
    h += '<div class="ph2 m">' + esc(T('sg_title')) + '</div><div class="sggl">';
    each(SUGG.list, function (x) {
      h += '<div class="sgg">' + frAv(x) + '<b data-frprof="' + esc(x.login) + '">' + esc(x.name) + '</b><small class="mut">' + esc(T('sg_with').replace('{s}', x.common)) + '</small><a class="btn" data-fradd2="' + esc(x.login) + '">' + esc(T('fr_add2')) + '</a></div>';
    });
    h += '</div>';
  }
  if (feat('suggest') && (!SUGG || now() - SUGG.t > 600000)) { SUGG = { t: now(), list: SUGG ? SUGG.list : [] }; api('suggest', {}, function (r) { if (r.ok) { SUGG.list = r.list || []; if (curModal === 'mdSide' && sideMode === 'friends' && SUGG.list.length) openFriends(); } }); }
  if (FR_REQ.length) {
    h += '<div class="ph2 m">' + esc(T('fr_req_t')) + ' (' + FR_REQ.length + ')</div>';
    each(FR_REQ, function (f) {
      h += '<div class="tr frq" style="cursor:default">' + frAv(f) + '<div class="nm">' + esc(f.name) + ' <span class="mut" style="font-weight:normal;font-size:12px">@' + esc(f.login) + '</span></div>' +
        '<div class="mt">' + esc(T('fr_wants')) + '</div><div class="fra"><a class="ok" data-fracc="' + esc(f.login) + '">' + esc(T('fr_acc')) + '</a><a data-frdec="' + esc(f.login) + '">' + esc(T('fr_dec')) + '</a></div></div>';
    });
    h += '<div class="ph2 m">' + esc(T('m_friends')) + '</div>';
  }
  each(FRIENDS, function (f) {
    var s = f.server ? srv(f.server) : null, un = f.unread ? '<b class="unb">' + f.unread + '</b>' : '';
    var offd = f.seen ? Math.floor((now() / 1000 - f.seen) / 86400) : 0;   // necha kundan beri kirmagan
    h += '<div class="tr" style="cursor:default">' + frAv(f) +
      '<div class="nm"><a class="frp" data-frprof="' + esc(f.login) + '">' + crown(f) + (f.clan ? '<span class="ctag">[' + esc(f.clan.tag) + ']</span> ' : '') + nickHtml(f) + '</a> ' + rankBadge(f) + ' <span class="mut" style="font-weight:normal;font-size:12px">' + esc(T('lvl').replace('{n}', f.level)) + '</span></div>' +
      '<div class="mt">' + (f.online ? '<span class="gm">●</span> ' + esc((f.mob ? T('fr_mob') + (f.server ? ' \u00b7 ' : '') : '') + (f.server ? T('fr_in') + ((s && s.name) || f.server) : f.mob ? '' : T('fr_menu'))) : esc(f.seen ? T('fr_last').replace('{t}', agoText(f.seen)) : T('fr_off'))) + '</div>' +
      '<div class="fra">' + (!f.online && offd >= 3 ? '<a class="inv" data-mcall="' + esc(f.login) + '">' + esc(T('mc_btn')) + '</a>' : '') + '<a data-frcmp="' + esc(f.login) + '">VS</a><a class="ch" data-chat="' + esc(f.login) + '" data-chatn="' + esc(f.name) + '">' + ico('chat') + ' ' + esc(T('ch_btn')) + un + '</a>' +
      (f.online ? '<a class="ring" data-ring="' + esc(f.login) + '" title="' + esc(T('rg_btn')) + '">' + ico('phone') + '</a><a class="duel" data-duelp="' + esc(f.login) + '" data-dueln="' + esc(f.name) + '" title="' + esc(T('du_btn')) + '">' + ico('swords') + '</a>' : '') +
      (CONNECTED && f.online && f.server !== CONNECTED ? '<a class="inv" data-inv="' + esc(f.login) + '">' + esc(T('iv_btn')) + '</a>' : '') +
      (f.server ? '<a class="ok" data-ip="' + esc(f.server) + '">' + esc(T('join')) + '</a>' : '<a data-frdel="' + esc(f.login) + '">' + esc(T('fr_del')) + '</a>') + '</div></div>';
  });
  if (!FRIENDS.length && !FR_REQ.length) h += '<div class="empty">' + esc(T('fr_none')) + '</div>';
  openSide('friends', T('m_friends'), h);
  var i = $('frIn'); if (i && keep) { try { i.focus(); i.setSelectionRange(keep.length, keep.length); } catch (e) {} }
}
/* qidiruv: 2 ta harfdan keyin ostida variantlar ("li" -> limonchik ...) */
function frSugHtml() {
  if (!FR_SUG) return '';
  if (!FR_SUG.length) return '<div class="sg em">' + esc(T('fr_noresult')) + '</div>';
  var h = '';
  each(FR_SUG, function (f) {
    var b = f.st === 'friend' ? '<span class="sgs">' + esc(T('fr_isf')) + '</span>' : f.st === 'sent' ? '<span class="sgs">' + esc(T('fr_sent')) + '</span>' :
      f.st === 'req' ? '<a class="sgb" data-fracc="' + esc(f.login) + '">' + esc(T('fr_acc')) + '</a>' : '<a class="sgb" data-fradd2="' + esc(f.login) + '">' + esc(T('fr_add2')) + '</a>';
    h += '<div class="sg">' + frAv(f) + '<b>' + esc(f.name) + '</b><small>@' + esc(f.login) + ' · ' + esc(T('lvl').replace('{n}', f.level)) + '</small>' + b + '</div>';
  });
  return h;
}
function frSearch(v) {
  FR_Q = v; clearTimeout(FR_TM);
  v = String(v || '').replace(/\s+/g, '');
  if (v.length < 2) { FR_SUG = null; var b0 = $('frSug'); if (b0) b0.style.display = 'none'; return; }
  FR_TM = setTimeout(function () {
    api('user_search', { q: v }, function (r) {
      if (!r.ok || FR_Q.replace(/\s+/g, '') !== v) return;
      FR_SUG = r.list || []; var b = $('frSug'); if (b) { b.innerHTML = frSugHtml(); b.style.display = 'block'; }
    });
  }, 300);
}
function frAdd(login) {
  api('friend_add', { login: login }, function (r) {
    if (!r.ok) return toast(r.msg);
    toast(r.st === 'friend' ? T('fr_now') : T('fr_sent_t'), 3500);
    if (SUGG) { SUGG.list = SUGG.list.filter(function (x) { return x.login.toLowerCase() !== login.toLowerCase(); }); if (curModal === 'mdSide' && sideMode === 'friends') openFriends(); }
    if (FR_SUG) each(FR_SUG, function (f) { if (f.login.toLowerCase() === login.toLowerCase()) f.st = r.st; });
    loadFriends();
  });
}
/* yozishma */
function openChat(login, name) {
  CHAT = { login: login, name: name || login, list: [] };
  var h = '<div class="chh"><a class="btn" data-act="frback">' + esc(T('ch_back')) + '</a><b>' + esc(CHAT.name) + '</b></div>' +
    '<div class="chbox" id="chatBox"><div class="empty">' + esc(T('loading')) + '</div></div>' +
    '<div class="chin"><input class="tx big" id="chatIn" type="text" maxlength="300" autocomplete="off" placeholder="' + esc(T('ch_ph')) + '"><a class="btn red" data-act="chatsend">' + esc(T('ch_send')) + '</a></div>';
  openSide('chat', T('ch_title').replace('{n}', CHAT.name), h);
  try { $('chatIn').focus(); } catch (e) {}
  chatLoad();
}
function chatRender() {
  var b = $('chatBox'); if (!b || !CHAT) return;
  var me = ME ? ME.login.toLowerCase() : '', h = '';
  each(CHAT.list, function (m) {
    var d = new Date(m.t * 1000);
    h += '<div class="cm' + (m.f === me ? ' me' : '') + '"><span>' + esc(m.m) + '<i>' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + '</i></span></div>';
  });
  b.innerHTML = h || '<div class="empty">' + esc(T('ch_empty')) + '</div>';
  b.scrollTop = b.scrollHeight;
}
function chatLoad() {
  clearTimeout(CHAT_TM);
  if (!CHAT || curModal !== 'mdSide' || sideMode !== 'chat') return;
  if (playing()) { CHAT_TM = setTimeout(chatLoad, 15000); return; }   // menyu yopiq, o'yindasiz - 4 s da so'ramaymiz
  var c = CHAT;
  api('msg_list', { login: c.login }, function (r) {
    var cbx = $('chatBox');
    if (CHAT !== c || !cbx) return;                 // chat yopilgan (ESC/X) - javob kelguncha oyna yo'q
    if (r.ok) { var n = (r.list || []).length; if (n !== c.list.length || !cbx.getElementsByTagName('div').length) { c.list = r.list || []; chatRender(); } }
    each(FRIENDS, function (f) { if (f.login.toLowerCase() === c.login.toLowerCase()) f.unread = 0; }); NOTIF_SEEN['m:' + c.login.toLowerCase()] = 0; frBadge();
    CHAT_TM = setTimeout(chatLoad, 4000);
  });
}
function chatSend() {
  var i = $('chatIn'); if (!i || !CHAT) return;
  var v = String(i.value || '').replace(/^\s+|\s+$/g, ''); if (!v) return;
  i.value = '';
  CHAT.list.push({ f: ME.login.toLowerCase(), m: v, t: Math.floor(now() / 1000) }); chatRender();
  api('msg_send', { login: CHAT.login, text: v }, function (r) { if (!r.ok) toast(r.msg); chatLoad(); });
}
/* bildirishnoma: 15 soniyada bir - yangi xabarlar va do'stlik so'rovlari */
var NOTIF = { unread: [], req: [] }, NOTIF_N = 0;
function frBadge() {
  var n = FR_REQ.length; each(NOTIF.unread, function (u) { if (!(CHAT && sideMode === 'chat' && curModal === 'mdSide' && CHAT.login.toLowerCase() === u.login)) n += u.n; });
  var e = $('mFrNew'); if (e) { e.innerHTML = n ? String(n) : ''; e.style.display = n ? 'inline-block' : 'none'; }
}
function pollNotif() {
  clearTimeout(NOTIF_TM);
  if (!ME) return;
  if (++NOTIF_N % 4 === 0 && !playing()) loadFriends();             // daqiqada bir: do'stlar qaysi serverga kirdi
  api('notif', {}, function (r) {
    NOTIF_TM = setTimeout(pollNotif, playing() ? 60000 : 15000);   // o'yin paytida daqiqada bir (har so'rov - o'yinda kichik qotish)
    if (!r.ok) return;
    NOTIF = { unread: r.unread || [], req: r.req || [] };
    if (r.inv && r.inv.length && !DB.dnd) showInvite(r.inv[r.inv.length - 1]);   // do'st chaqirdi
    if (r.ring && !DB.dnd) showRing(r.ring);
    if (r.dinv && !DB.dnd) showDuelInv(r.dinv);
    DUEL = r.duel && r.duel.st === 'on' ? r.duel : null; duelBar();
    if (r.dres) duelResult(r.dres);
    if (r.wallnew && ME) toastAct(T('wl_new').replace('{n}', r.wallnew), 'data-frprof', ME.login, 8000);
    each(r.ringans || [], function (a) {
      toast((a.ok ? T('rg_yes') : T('rg_no')).replace('{n}', a.from), 7000);
      if (a.ok) openChat(a.login, a.from);
    });
    if (r.calls && r.calls.length) {                                   // "Sizni sog'indik" - uzoq kirmaganda do'stlar chaqirgan
      var nm = []; each(r.calls, function (c) { if (nm.indexOf(c.from) < 0) nm.push(c.from); });
      toast(T('mc_got').replace('{n}', nm.slice(0, 3).join(', ')), 9000);
    }
    var changed = (r.req || []).length !== FR_REQ.length;
    each(NOTIF.req, function (q) { if (!NOTIF_SEEN['r:' + q.login]) { NOTIF_SEEN['r:' + q.login] = 1; if (!DB.dnd) toast(T('fr_newreq').replace('{n}', q.name), 6000); changed = true; } });
    each(NOTIF.unread, function (u) {
      var k = 'm:' + u.login, inChat = CHAT && sideMode === 'chat' && curModal === 'mdSide' && CHAT.login.toLowerCase() === u.login;
      if (!inChat && (NOTIF_SEEN[k] || 0) < u.n) { if (!DB.dnd) toast(T('fr_newmsg').replace('{n}', u.name).replace('{c}', u.n), 6000); changed = true; }
      NOTIF_SEEN[k] = u.n;
    });
    if (changed) loadFriends(); else frBadge();
  });
}

/* profil rasmi: tayyor rasmlar + o'z rasmini brauzer orqali (mmb.boost-top.com/rasm.html) */
function openAvatars() {
  if (!ME) return openLogin();
  var h = '<div class="ph2">' + esc(T('av_pick')) + '</div><div class="avg">';
  for (var i = 1; i <= 12; i++) h += '<a data-avpre="' + i + '"><img src="av/p' + i + '.png" alt=""></a>';
  h += '</div><div class="ph2 m">' + esc(T('av_own')) + '</div><div class="avown">' + esc(T('av_own2')) +
    '<div class="avurl"><input class="ipin" readonly value="mmb.boost-top.com/rasm.html"><a class="cpy" data-copyip="mmb.boost-top.com/rasm.html">' + esc(T('ip_copy')) + '</a></div></div>' +
    (ME.av ? '<a class="btn" style="margin:16px 0 0" data-act="avdel">' + esc(T('av_del')) + '</a>' : '');
  openSide('avatars', T('av_title'), h);
}

/* ============================================================ SOZLAMALAR */
var DEF = {
  name: '', tag: 'X | ', net: 'fast', aimnet: 1, dl: 1, spray: 1, mp3off: 0, hand: 1, fastsw: 1, aws: 1, buykeys: 0, queue: 1, reconn: 1, rest: 0, demo: 0, dmig: 0, dmig2: 0,
  sens: 2.5, zoom: 1.2, raw: 1, filter: 0, inv: 0,
  vol: 0.8, mus: 0.4, voice: 1, vscale: 1, mute: 1, micwarm: 1, micfix: 0,
  fps: 100, showfps: 0, uisnd: 1, uics: 0, uimig: 0, ultra: 0, ann: 1, gamma: 2.5, bright: 1, fov: 90, vmfov: 90, hor: 1, vsync: 0, dyn: 1, decals: 1000,
  xp: 'pro', xt: 0, xs: 'small', xc: '50 250 50', xtr: 0, xdyn: 0, xthick: 1, xgap: 3, xout: 0, netg: 0, hs: 1, radar: 1, cid: 1, nover: 1, dmax: 5,
  rscale: 115, ropac: 100, rnames: 0, rhp: 0, rmode: 1, rround: 1, rrot: 1, rmap: 0.8,
  vmx: 0, vmy: 0, vmz: 0, vmshift: 0, bobst: 0, lagst: 0, camint: 0,
  roll: 0, rollspd: 200, bobv: 0.13, bobl: 0.32, boblow: 8, bobcam: 1, lagsc: 1, lagsp: 8, fovlerp: 0, camsc: 1,
  rtracks: 0, rfull: 1, rbg: 0, rallies: 1, rns: 0.8, rhs: 1, dtime: 6, drpc: 1, drpcs: 1, drpcj: 1, mmusic: 1,
  bob: 0.01, picmip: 0, detail: 0, shadows: 1, minm: 0, interp: 0.01, lw: 1, lc: 1, hisnd: 1, mixa: 0.1, loop: 0, saytm: 5, ngpos: 1, pro: 0, gfxc: '', xgm: 0, xmig: 0, pmig: 0, gmig: 0,
  awps: 0, awpz: 1, awpxc: '0 230 255', awpxs: 'small'
};
var S = null, E = null;
var CVARS = { sens: 'sensitivity', zoom: 'zoom_sensitivity_ratio', raw: 'm_rawinput', filter: 'm_filter', vol: 'volume', vscale: 'voice_scale', voice: 'voice_enable',
  fps: 'fps_max', showfps: 'cl_showfps', gamma: 'gamma', bright: 'brightness', hdm: 'cl_himodels', fov: 'fov_angle', vmfov: 'viewmodel_fov', hor: 'fov_horplus', xt: 'cl_crosshair_type', xs: 'cl_crosshair_size',
  xc: 'cl_crosshair_color', xtr: 'cl_crosshair_translucent', xdyn: 'cl_dynamiccrosshair', hand: 'cl_righthand', fastsw: 'hud_fastswitch', dl: 'cl_allowdownload',
  spray: 'cl_allowupload', mute: 'snd_mute_losefocus', vsync: 'gl_vsync', dyn: 'r_dynamic', cid: 'hud_centerid', radar: 'cl_radartype', dmax: 'hud_deathnotice_max', decals: 'mp_decals',
  ropac: 'hud_radar_opacity', rnames: 'hud_radar_names', rhp: 'hud_radar_health', rmode: 'hud_radar_mode', rround: 'hud_radar_round', rrot: 'hud_radar_rotate', rmap: 'hud_radar_map_scale',
  vmx: 'viewmodel_offset_x', vmy: 'viewmodel_offset_y', vmz: 'viewmodel_offset_z', vmshift: 'viewmodel_disable_shift', bobst: 'cl_bobstyle', lagst: 'viewmodel_lag_style',
  roll: 'cl_rollangle', rollspd: 'cl_rollspeed', bobv: 'cl_bobamt_vert', bobl: 'cl_bobamt_lat', boblow: 'cl_bob_lower_amt', bobcam: 'cl_bob_camera',
  lagsc: 'viewmodel_lag_scale', lagsp: 'viewmodel_lag_speed', fovlerp: 'fov_lerp', camsc: 'camera_movement_scale',
  rtracks: 'hud_radar_tracks', rfull: 'hud_radar_fullmap', rbg: 'hud_radar_bg', rallies: 'hud_radar_allies', rns: 'hud_radar_name_size', rhs: 'hud_radar_health_size',
  dtime: 'hud_deathnotice_time', drpc: 'cl_discordrpc', drpcs: 'cl_discordrpc_server', drpcj: 'cl_discordrpc_join',
  bob: 'cl_bob', picmip: 'gl_picmip', detail: 'r_detailtextures', shadows: 'cl_shadows', minm: 'cl_minmodels', interp: 'ex_interp', lw: 'cl_lw', lc: 'cl_lc',
  hisnd: 'hisound', mixa: '_snd_mixahead', loop: 'voice_loopback', saytm: 'hud_saytext_time', ngpos: 'net_graphpos' };
function loadSettings() {
  S = copy(DEF);
  if (DB.set) for (var k in DB.set) if (DB.set.hasOwnProperty(k) && DEF.hasOwnProperty(k)) S[k] = DB.set[k];
  if (!(S.mixa >= 0.1)) S.mixa = 0.1;              // 0.05 (eski PRO CFG) - ovoz buferi juda kichik: FPS tushsa ovoz qotib takrorlanadi va uziladi
  /* pritsel otganda kattalashmaydi - hech qaysi CFG da (egasining talabi); saqlangan eski 1 lar ham 0 bo'ladi */
  S.xdyn = 0; cmd('cl_dynamiccrosshair 0');
  if (!S.uimig) { S.uics = 0; S.uimig = 1; if (DB.set) DB.set = S; }   // yangi yumshoq menyu ovozlari hammaga
  /* standart pritsel: kichik, yashil (eski standart qizil edi) - bir marta; o'yinchi o'zi tanlagan boshqa rangga tegmaymiz */
  if (!S.xgm) { if (S.xc === '255 59 59') S.xc = '50 250 50'; if (!S.xs || S.xs === 'auto') S.xs = 'small'; S.xgm = 1; if (DB.set) DB.set = S; }
  /* spray: o'zimiznikini yuborish va boshqalarnikini ko'rish doim yoqiq (X CLIENT spreyi hamma serverda ko'rinsin) */
  S.spray = 1; S.dl = 1; cmd('cl_allowupload 1'); cmd('cl_allowdownload 1');
  cmd('host_framerate 0');                         // demo tezligi oldingi ishga tushishdan qolib ketgan bo'lsa
  /* "Avto grafika" (bekor qilindi) grafikani pasaytirib yuborgan o'yinchilarda - to'liq grafikani qaytaramiz */
  /* eski PRO CFG soya va dinamik yorug'likni o'chirgan edi - bir marta qaytaramiz (yangi PRO CFG grafikaga tegmaydi) */
  if (!S.dmig2) { S.demo = 0; S.dmig = 1; S.dmig2 = 1; DB.set = S; }   // .dem avtomatik yozish o'chirildi: Demo bo'limida endi faqat F10 videolari (demo ko'rish NextClient ni yiqitardi)
  if (S.pro && !S.pmig) { S.shadows = 1; S.dyn = 1; S.pmig = 1; S.gfxc = ''; DB.set = S; }
  /* detal teksturalar (devorlarga naqsh) va baland gamma xaritalarni g'alati va og'ir ko'rsatdi - bir marta CS 1.6 holatiga */
  if (!S.gmig) {
    var gm = S.gamma > 2.6;
    S.detail = 0; if (gm) S.gamma = 2.5; S.gmig = 1; if (DB.set) DB.set = S;
    cmd('r_detailtextures 0'); if (gm) cmd('gamma 2.5');   // saqlangan sozlamasi yo'q o'yinchida ham o'yinga darhol
  }
  if (S.gfxc) {
    // CS 1.6 standarti: detal teksturalar o'chiq, soya va yorug'lik yoqiq
    var g = { detail: 0, shadows: 1, dyn: 1 };
    for (var gk in g) if (g.hasOwnProperty(gk)) S[gk] = g[gk];
    if (S.decals < 1000) S.decals = 1000; S.hisnd = 1; if (S.mixa > 0.1) S.mixa = 0.1;
    S.gfxc = ''; DB.set = S;
  }
}
function seedFromGame() {
  if (!canRead()) return;
  for (var k in CVARS) {
    if (!CVARS.hasOwnProperty(k)) continue;
    var v = readCvar(CVARS[k]);
    if (v == null || v === '') continue;
    if (typeof DEF[k] === 'number') { var n = parseFloat(v); if (!isNaN(n)) S[k] = Math.round(n * 100) / 100; } else S[k] = String(v).replace(/^\s+|\s+$/g, '');
  }
  for (var xk in XSUP) if (XSUP.hasOwnProperty(xk) && XSUP[xk]) { var xv = parseFloat(readCvar(XSUP[xk])); if (!isNaN(xv)) S[xk] = Math.round(xv * 10) / 10; }
  var pitch = parseFloat(readCvar('m_pitch')); if (!isNaN(pitch)) S.inv = pitch < 0 ? 1 : 0;
  var ng = parseFloat(readCvar('net_graph')); if (!isNaN(ng)) S.netg = ng > 0 ? 1 : 0;
  var old = parseFloat(readCvar('hud_deathnotice_old')); if (!isNaN(old)) S.hs = old > 0 ? 0 : 1;
  var dv = parseFloat(readCvar('scr_drawversion')); if (!isNaN(dv)) S.nover = dv > 0 ? 0 : 1;
  var rs = parseFloat(readCvar('hud_radar_scale')); if (!isNaN(rs)) S.rscale = Math.round(rs * 100);
  // eski NextClient "extra_small" ni katta (auto) qilib chizadi - eng kichigi "small"
  if (S.xs === 'auto') S.xs = 'large';
  if (SZ.indexOf(S.xs) < 0) S.xs = 'small';
  S.xc = String(S.xc).replace(/\s+/g, ' ');
  S.xp = presetOf(S);
  var nm = readCvar('name');
  if (nm && pwIsLogin(nm)) nm = '';                  // VIP/admin login (applyPw qo'ygan) - o'yinchining o'z niki emas
  if (nm) { MYNAME = nm; var tm = /^(X \| |\[[A-Za-z0-9]{2,5}\] )/.exec(nm); S.tag = tm ? tm[1] : ''; S.name = nm.slice(S.tag.length); }
}
var NETS = { slow: [25000, 60, 60], mid: [50000, 101, 101], fast: [100000, 101, 105] };
var BUY = [['F1', 'buy m4a1; buy ak47; buyammo1; buyammo1'], ['F2', 'buy awp; buyammo1; buyammo1'], ['F3', 'buy vesthelm; buy defuser'], ['F4', 'buy hegren; buy flash; buy flash; buy sgren']];
var RTAG = { silver: 'Silver', gold: 'Gold', plat: 'Plat', diamond: 'Diamond', legend: 'Legend' };
/* o'yindagi nik: [unvon] (ixtiyoriy, Sozlamalar > O'yin) + klan tegi + nik. Bronza unvoni ko'rsatilmaydi */
function fullName(s) { var r = s && s.rtag && ME && RTAG[ME.rank] ? '[' + RTAG[ME.rank] + ']' : ''; return (r + (s.tag || '') + s.name).slice(0, 31); }
var ULTRA_WAS = false;  // asl qiymatlar faqat o'yinchi "Ultra yengil" ni o'chirganda yuboriladi (qon va h.k. ni o'zi o'chirganlarga tegmaymiz)
function sndSet(c, cv, v) { var cur = parseFloat(readCvar(cv)); if (!isNaN(cur) && Math.abs(cur - Number(v)) > 1e-6) c.push(cv + ' ' + v); }
/* Aniq tegish: o'q tekkan-tekmagani serverda hal bo'ladi - CFG uni "kuchaytira" olmaydi. Lekin noto'g'ri tarmoq sozlamasi
 * (internetga mos kelmaydigan updaterate/interp) o'yinchi ko'rgan raqib joyini serverdagidan siljitadi va "o'q tegmadi" bo'ladi.
 * Serverga kirganda shu serverning ping/yo'qotish/tebranishiga mos qiymatlar qo'yiladi; cl_lc/cl_lw (lag kompensatsiyasi) doim yoqiq */
var AIMNET = null;
function aimNetCalc(ip) {
  var s = srv(ip), q = netQual(s), p = q.n ? q.ping : (s.ping || 0), l = q.loss, j = q.jit;
  if (!p && !q.n) return null;
  var t = (l >= 10 || p > 150 || j > 40) ? 'bad' : (l >= 3 || p > 80 || j > 20) ? 'mid' : 'good';
  var v = { good: [100000, 101, 105, 0.01], mid: [50000, 101, 101, 0.02], bad: [30000, 60, 66, 0.04] }[t];
  return { t: t, p: p, l: l, rate: v[0], up: v[1], cmd: v[2], interp: v[3] };
}
window.XC_NETHIST = function (ip, nh) { srv(ip).nh = nh; };   // avtomatik test uchun (tests/menu/aimnet.js)
function aimNetCmds(a) { return ['rate ' + a.rate, 'cl_updaterate ' + a.up, 'cl_cmdrate ' + a.cmd, 'ex_interp ' + a.interp, 'cl_lc 1', 'cl_lw 1']; }
function aimNetApply(ip, quiet) {
  if (!S.aimnet || !ip) { AIMNET = null; return; }
  var a = aimNetCalc(ip);
  if (!a) { var n = NETS[S.net] || NETS.fast; AIMNET = null; each(['rate ' + n[0], 'cl_updaterate ' + n[1], 'cl_cmdrate ' + n[2], 'ex_interp ' + S.interp, 'cl_lc 1', 'cl_lw 1'], function (c) { cmd(c); }); return; }   // ma'lumot yo'q - o'yinchining o'z sozlamasi
  var same = AIMNET && AIMNET.ip === ip && AIMNET.t === a.t; a.ip = ip; AIMNET = a;
  each(aimNetCmds(a), function (c) { cmd(c); });
  if (!quiet && !same) toast(T('an_set').replace('{t}', T('an_' + a.t)).replace('{p}', a.p).replace('{l}', a.l), 4500);
}
function settingsCmds(s) {
  var n = NETS[s.net] || NETS.fast, c = [];
  if (PW_NAME && CONNECTED) c.push('name ' + q(PW_NAME));      // shu serverda VIP nik bilan kirilgan - tegli nik bilan almashtirmaymiz
  else if (s.name) c.push('name ' + q(fullName(s)));
  c.push('rate ' + n[0], 'cl_updaterate ' + n[1], 'cl_cmdrate ' + n[2]);
  c.push('cl_allowdownload 1', 'cl_allowupload 1', 'cl_righthand ' + s.hand, 'hud_fastswitch ' + s.fastsw);
  c.push('mp3volume ' + (s.mp3off ? 0 : s.mus));
  c.push('setinfo _cl_autowepswitch ' + (s.aws === 0 ? 0 : 1));   // yangi qurol olganda unga o'tish (oddiy CS sozlamasi)
  c.push('sensitivity ' + s.sens, 'zoom_sensitivity_ratio ' + s.zoom, 'm_rawinput ' + s.raw, 'm_filter ' + s.filter, 'm_pitch ' + (s.inv ? -0.022 : 0.022));
  c.push('volume ' + s.vol, 'voice_enable ' + s.voice, 'voice_scale ' + s.vscale, 'snd_mute_losefocus ' + s.mute, 'voice_dsound ' + (s.micfix ? 0 : 1));
  // fps_override 1 bo'lmasa NextClient FPS ni 100 da ushlab qoladi
  // cl_dlmax standart (512): 1024 ba'zi serverlar himoyasida (DProto/ReChecker) "FakePlayers" deb kick qilinishi mumkin
  c.push('fps_override ' + (s.fps > 100 ? 1 : 0), 'cl_showfps ' + s.showfps, 'cl_dlmax 512', 'm_customaccel 0');
  c.push('fps_max ' + s.fps, 'gamma ' + s.gamma, 'brightness ' + (s.bright != null ? s.bright : 1), 'fov_angle ' + s.fov, 'viewmodel_fov ' + s.vmfov, 'fov_horplus ' + s.hor, 'gl_vsync ' + s.vsync, 'r_dynamic ' + s.dyn, 'mp_decals ' + Math.max(300, s.decals));   // kam bo'lsa spray o'q izlari orasida tez o'chib ketadi
  each(xhairCmds(s), function (x) { c.push(x); });
  /* NextClient video sozlamalari (o'z oynasidagi kabi): HD modellar, tashqi kontent, past grafika - dvigatel yozib qo'yadi, o'yin qayta
   * ochilganda kuchga kiradi. Faqat o'yinchi bu yerda o'zgartirgan bo'lsa yuboriladi (NextClient oynasidagi tanlovni bosib ketmasin) */
  if (s.hdmx) c.push('_sethdmodels ' + (s.hdm ? 1 : 0));
  if (s.addons === 0 || s.addons === 1) c.push('_setaddons_folder ' + s.addons);
  if (s.lowgfx === 0 || s.lowgfx === 1) c.push('_set_vid_level ' + s.lowgfx);
  // gl_picmip 0 va cl_minmodels 0 qotirilgan: aks holda serverning o'yinchi skinlari, qurollari va spray buziladi
  /* ultra yengil: teksturalarga tegmaydi (picmip/minmodels serverning skin va spreylarini buzadi) - faqat effektlar: yomg'ir/qor,
   * sprayt aralashuvi, qon/bo'laklar, jasadlar, oyna/suv akslari. O'chirilsa - CS 1.6 ning asl qiymatlari */
  if (s.ultra) c.push('cl_weather 0', 'gl_spriteblend 0', 'violence_hblood 0', 'violence_hgibs 0', 'cl_corpsestay 0', 'r_mirroralpha 0', 'gl_wateramp 0', 'gl_keeptjunctions 0');
  else if (s.ultra === 0 && ULTRA_WAS) c.push('cl_weather 1', 'gl_spriteblend 1', 'violence_hblood 1', 'violence_hgibs 1', 'cl_corpsestay 600', 'r_mirroralpha 1', 'gl_keeptjunctions 1');
  ULTRA_WAS = !!s.ultra;
  c.push('cl_bob ' + s.bob, 'gl_picmip 0', 'r_detailtextures ' + s.detail, 'cl_shadows ' + s.shadows, 'cl_minmodels 0',
    'ex_interp ' + s.interp, 'cl_lw ' + s.lw, 'cl_lc ' + s.lc, 'voice_loopback ' + s.loop,
    'hud_saytext_time ' + s.saytm, 'net_graphpos ' + s.ngpos);
  if (s.aimnet && AIMNET && CONNECTED === AIMNET.ip) each(aimNetCmds(AIMNET), function (x) { c.push(x); });   // o'yin ichida saqlansa - serverga mos qiymatlar qolsin
  c.push('net_graph ' + (s.netg ? 3 : 0), 'hud_deathnotice_old ' + (s.hs ? 0 : 1), 'hud_deathnotice_max ' + s.dmax, 'cl_radartype ' + s.radar, 'hud_centerid ' + s.cid, 'scr_drawversion ' + (s.nover ? 0 : 1));
  // PRO CFG qo'shimchasi: to'liq yugurish tezligi, eski ovoz tezlatkichlari o'chiq (qotish beradi), keraksiz effektlarsiz - yuqori va barqaror FPS
  if (s.pro) c.push('cl_forwardspeed 400', 'cl_sidespeed 400', 'cl_backspeed 400', 'cl_upspeed 400', 'cl_pitchup 89', 'cl_pitchdown 89',
    'cl_weather 0', 'cl_showevents 0', 'cl_timeout 60');
  /* ovoz tizimi sozlamalari: ba'zi NextClient versiyalarida ularni yuborish (qiymat o'zgarmasa ham) ovozni qayta ishga tushiradi
   * va o'yin qayta ochilguncha ovoz yo'qoladi. Faqat o'yindagi qiymat haqiqatan boshqacha bo'lsa yuboramiz, o'qib bo'lmasa - umuman yo'q */
  sndSet(c, 'hisound', s.hisnd); sndSet(c, '_snd_mixahead', s.mixa);
  if (s.pro) { sndSet(c, 's_a3d', 0); sndSet(c, 's_eax', 0); }
  /* o'q tekkan joydagi tutun/chang va gilzalar - standart: ular o'q qayerga ketayotganini ko'rsatadi (otdachani boshqarish uchun).
   * 0 qilinganda o'yinchilar "qurol sochilib ketyapti" deyishdi */
  c.push('max_shells 120', 'max_smokepuffs 120');
  /* NextClient'ning qo'shimcha sozlamalari (radar, qurol joylashuvi, kamera, Discord): bu versiyada bo'lmaganlari yuborilmaydi -
   * aks holda konsol har safar "Unknown command" bilan to'lib ketardi */
  var x = [];
  x.push('hud_radar_scale ' + (s.rscale / 100), 'hud_radar_opacity ' + s.ropac, 'hud_radar_names ' + s.rnames, 'hud_radar_health ' + s.rhp);
  x.push('hud_radar_mode ' + s.rmode, 'hud_radar_round ' + s.rround, 'hud_radar_rotate ' + s.rrot, 'hud_radar_map_scale ' + s.rmap);
  x.push('viewmodel_offset_x ' + s.vmx, 'viewmodel_offset_y ' + s.vmy, 'viewmodel_offset_z ' + s.vmz, 'viewmodel_disable_shift ' + s.vmshift,
    'cl_bobstyle ' + s.bobst, 'viewmodel_lag_style ' + s.lagst, 'camera_movement_interp ' + (s.camint ? 0.1 : 0));
  x.push('cl_rollangle ' + s.roll, 'cl_rollspeed ' + s.rollspd, 'cl_bobamt_vert ' + s.bobv, 'cl_bobamt_lat ' + s.bobl, 'cl_bob_lower_amt ' + s.boblow, 'cl_bob_camera ' + s.bobcam,
    'viewmodel_lag_scale ' + s.lagsc, 'viewmodel_lag_speed ' + s.lagsp, 'fov_lerp ' + s.fovlerp, 'camera_movement_scale ' + s.camsc);
  x.push('hud_radar_tracks ' + s.rtracks, 'hud_radar_fullmap ' + s.rfull, 'hud_radar_bg ' + s.rbg, 'hud_radar_allies ' + s.rallies, 'hud_radar_name_size ' + s.rns,
    'hud_radar_health_size ' + s.rhs, 'hud_deathnotice_time ' + s.dtime, 'cl_discordrpc ' + s.drpc, 'cl_discordrpc_server ' + s.drpcs, 'cl_discordrpc_join ' + s.drpcj);
  each(x, function (k) { if (ncHasC(k.split(' ')[0])) c.push(k); });
  if (s.buykeys) each(BUY, function (b) { c.push('bind ' + b[0] + ' ' + q(b[1])); });
  /* cl_filterstuffcmd faqat demo ko'rilayotganda 1: aks holda server menyularining bandlari (server o'yinchiga buyruq yuboradi) ishlamaydi.
   * Eski menyu demodan keyin uni 1 da qoldirib ketardi - har ochilishda tuzatiladi */
  if (!DEMO_PLAY) c.push('cl_filterstuffcmd 0');
  return c;
}
function applySettings(s) { each(settingsCmds(s), function (c) { cmd(c); }); if (MUSIC_ON) cmd('mp3volume ' + MVOL); if (GMUTE) cmd('volume 0'); if (s.name) MYNAME = fullName(s); if (s === S) binAliases(); }

/* saqlashdan keyin o'yindan qayta o'qib tekshirish */
var LAST_CHECK = null;
function verifySettings(s) {
  if (!canRead()) { toast(T('saved')); return; }
  var exp = {}, bad = [], ok = 0;
  for (var k in CVARS) if (CVARS.hasOwnProperty(k)) exp[CVARS[k]] = s[k];
  for (var xk in XSUP) if (XSUP.hasOwnProperty(xk) && XSUP[xk]) exp[XSUP[xk]] = xextVal(xk, s);
  exp.m_pitch = s.inv ? -0.022 : 0.022; exp.net_graph = s.netg ? 3 : 0; exp.hud_deathnotice_old = s.hs ? 0 : 1; exp.hud_radar_scale = s.rscale / 100;
  if (s.name) exp.name = fullName(s);
  for (var c in exp) {
    if (!exp.hasOwnProperty(c)) continue;
    var got = readCvar(c);
    if (got == null) continue;                              // klientda bunday kvar yo'q
    var want = String(exp[c]), a = parseFloat(got), b = parseFloat(want);
    var same = (!isNaN(a) && !isNaN(b) && /^[-\d.]+$/.test(want)) ? Math.abs(a - b) < 0.011 : got.replace(/\s+/g, ' ').toLowerCase() === want.toLowerCase();
    if (same) ok++; else bad.push(c + ': ' + got + ' \u2192 ' + want);
  }
  LAST_CHECK = { ok: ok, bad: bad };
  if (bad.length) toast(T('chk_bad').replace('{n}', bad.length), 4000);
  else toast(T('chk_ok').replace('{n}', ok));
  if (curModal === 'mdSettings' && setTab === 'system') showSetTab('system');
}

/* pritsel tayyor ko'rinishlari (NextClient: tur 0-3, o'lcham small/medium/large/auto) */
var XPRE = [['classic', 'x_classic', 0, 'medium'], ['pro', 'x_pro', 0, 'small'], ['dot', 'x_dot', 3, 'small'], ['t', 'x_t', 1, 'small'], ['circle', 'x_circle', 2, 'medium'], ['big', 'x_big', 0, 'large']];
function presetOf(s) {
  var i;
  for (i = 0; i < XPRE.length; i++) if (Number(s.xt) === XPRE[i][2] && s.xs === XPRE[i][3]) return XPRE[i][0];
  for (i = 0; i < XPRE.length; i++) if (Number(s.xt) === XPRE[i][2]) return XPRE[i][0];
  return 'classic';
}
/* pritsel galereyasi: tayyor pritsellar, bir bosishda qo'yiladi */
var XGAL = [['xg_green', 'X-0-2-0-0-00FF00'], ['xg_pro', 'X-0-1-0-0-32FF32'], ['xg_cyandot', 'X-3-1-0-0-00FFFF'], ['xg_redt', 'X-1-1-0-0-FF2020'], ['xg_ycirc', 'X-2-2-0-0-FFFF00'],
  ['xg_white', 'X-0-0-0-0-FFFFFF'], ['xg_pink', 'X-0-1-0-0-FF00FF'], ['xg_awp', 'X-3-0-0-0-FF3030'], ['xg_dyn', 'X-0-2-0-1-00FF00'], ['xg_glass', 'X-0-1-1-0-00BFFF'], ['xg_big', 'X-0-3-0-0-00FF00'], ['xg_bluet', 'X-1-2-0-0-3B6CFF']];
function xGallery() {
  var h = '<div class="ph2 m">' + esc(T('xg_title')) + '</div><div class="xgal">';
  each(XGAL, function (g) { var c = g[1].slice(-6); h += '<a data-xgal="' + g[1] + '"><i style="background:#' + c + '"></i>' + esc(T(g[0])) + '</a>'; });
  return h + '</div>';
}
var SZ = ['extra_small', 'small', 'medium', 'large'];   // NextClient: large eng katta (auto ham shunday); qalinlik doim 1 piksel
function xcode(s) {
  var hex = '';
  each(String(s.xc).split(' '), function (v) { var h = (Number(v) || 0).toString(16).toUpperCase(); hex += h.length < 2 ? '0' + h : h; });
  return 'X-' + s.xt + '-' + Math.max(0, SZ.indexOf(s.xs)) + '-' + (s.xtr ? 1 : 0) + '-' + (s.xdyn ? 1 : 0) + '-' + hex;
}
function applyCode(code) {
  var m = /^X-([0-3])-([0-3])-([01])-([01])-([0-9A-F]{6})$/i.exec(String(code).replace(/\s+/g, ''));
  if (!m) { toast(T('x_badcode')); return false; }
  E.xt = Number(m[1]); E.xs = SZ[Number(m[2])] || 'large'; E.xtr = Number(m[3]); E.xdyn = 0;
  E.xc = parseInt(m[5].slice(0, 2), 16) + ' ' + parseInt(m[5].slice(2, 4), 16) + ' ' + parseInt(m[5].slice(4, 6), 16);
  E.xp = presetOf(E);
  return true;
}

var setTab = 'game', HSUB = 'main';
/* pritsel: o'yinga darhol qo'llanadi (Saqlash bosilmasa - oyna yopilganda qaytariladi).
 * Qalinlik / interval / kontur: NextClient versiyasida shunday kvar bo'lsa - ishlaydi, bo'lmasa kulrang. */
var XEXT = { xthick: ['cl_crosshair_thickness', 'cl_crosshairthickness', 'cl_crosshair_width'],
  xgap: ['cl_crosshair_gap', 'cl_crosshairgap'],
  xout: ['cl_crosshair_outline', 'cl_crosshair_drawoutline', 'cl_crosshair_outline_draw', 'cl_crosshair_outline_thickness'] };
var XSUP = {}, XLIVE = false;
function detectXext() {
  XSUP = {};
  for (var k in XEXT) {
    if (!XEXT.hasOwnProperty(k)) continue;
    XSUP[k] = '';
    for (var i = 0; i < XEXT[k].length; i++) { var v = readCvar(XEXT[k][i]); if (v != null && v !== '') { XSUP[k] = XEXT[k][i]; break; } }
  }
}
function xextVal(k, s) { return k === 'xout' && /draw/.test(XSUP[k] || '') ? (s.xout > 0 ? 1 : 0) : s[k]; }
function xhairCmds(s) {
  // rang qo'shtirnoq bilan: GoldSrc kvarga faqat 1-so'zni yozadi (cl_crosshair_color 255 0 0 -> "255")
  var c = ['cl_crosshair_type ' + s.xt, 'cl_crosshair_size ' + s.xs, 'cl_crosshair_color ' + q(String(s.xc).replace(/[^\d ]/g, '')), 'cl_crosshair_translucent ' + s.xtr, 'cl_dynamiccrosshair 0'];
  for (var k in XSUP) if (XSUP.hasOwnProperty(k) && XSUP[k]) c.push(XSUP[k] + ' ' + xextVal(k, s));
  return c;
}
function xhairApply() { if (S && !DEMO_PLAY) each(xhairCmds(S), function (x) { cmd(x); }); }
function xLive() { if (!E) return; XLIVE = true; each(xhairCmds(E), function (x) { cmd(x); }); }
/* ---- profillar: 4 ta joy, har birida sozlamalar + tugmalar ---- */
function profSlots() {
  var p = DB.profiles || [], n = ['pf_n1', 'pf_n2', 'pf_n3', 'pf_n4'], out = [];
  for (var i = 0; i < 4; i++) out.push(p[i] || { n: T(n[i]), t: 0 });
  return out;
}
function profSave(i) {
  var p = DB.profiles || [], sl = profSlots()[i], set = copy(E);
  delete set.name; delete set.tag;
  p[i] = { n: sl.n, t: now(), s: set, b: copy(BINDS), b2: copy(BINDS2) };
  DB.profiles = p; persist(); cloudSave(); toast(T('pf_saved').replace('{n}', sl.n));
}
function profLoad(i) {
  var sl = (DB.profiles || [])[i]; if (!sl || !sl.s) return;
  for (var k in sl.s) if (sl.s.hasOwnProperty(k) && DEF.hasOwnProperty(k)) E[k] = sl.s[k];
  if (sl.b) { DB.binds = copy(sl.b); DB.binds2 = sl.b2 ? copy(sl.b2) : {}; loadBinds(); applyBinds(); persist(); }
  toast(T('pf_loaded').replace('{n}', sl.n), 4000);
}
/* ---- sezgirlik kalkulyatori (CS 1.6 m_yaw 0.022) ---- */
var CALC_G = [['cs2', 'CS2 / CS:GO', 1], ['val', 'Valorant', 3.181818], ['ow', 'Overwatch 2', 0.3], ['apex', 'Apex', 1]];
var CALC = 'cs2', CALC_V = '1';
function calcVal() {
  var v = parseFloat(String(CALC_V).replace(',', '.')), f = 1;
  each(CALC_G, function (g) { if (g[0] === CALC) f = g[2]; });
  return isNaN(v) ? 0 : Math.round(v * f * 100) / 100;
}
function calcOut() { var v = calcVal(); return v ? '= <b>' + v + '</b> CS 1.6' : ''; }
/* ---- tayyor uslublar (o'yin uslubi bo'yicha, haqiqiy o'yinchilar emas) ---- */
/* Tayyor CFG'lar - 4 guruh: [id, nom, izoh, qiymatlar, guruh]. Har biri to'liq: internet, interp, sezgirlik, pritsel, qurol ko'rinishi.
 * FPS 100 dan past bo'lsa - 100 (CS 1.6 fizikasi); grafika faqat "Kompyuter" guruhida o'zgaradi. */
var STYLES = [
  ['pro', 'st_pro', 'st_pro2', { net: 'fast', interp: 0.01, lw: 1, lc: 1, raw: 1, filter: 0, vsync: 0, hisnd: 1, mixa: 0.1, sens: 2, zoom: 1, xt: 0, xs: 'small', xc: '50 250 50', xtr: 0, xdyn: 0, bob: 0, fastsw: 1, vmfov: 90, dmax: 5 }, 'top'],
  ['rifle', 'st_rifle', 'st_rifle2', { net: 'fast', interp: 0.01, lw: 1, lc: 1, raw: 1, filter: 0, vsync: 0, hisnd: 1, mixa: 0.1, sens: 2.2, zoom: 1, xt: 0, xs: 'small', xc: '50 250 50', xtr: 0, xdyn: 0, bob: 0, fastsw: 1 }, 'top'],
  ['awp', 'st_awp', 'st_awp2', { net: 'fast', interp: 0.01, lw: 1, lc: 1, raw: 1, filter: 0, vsync: 0, hisnd: 1, mixa: 0.1, sens: 1.8, zoom: 0.85, xt: 0, xs: 'small', xc: '0 230 255', xtr: 0, xdyn: 0, bob: 0, fastsw: 1, awps: 1.5, awpz: 0.85, awpxs: 'small' }, 'top'],
  ['entry', 'st_entry', 'st_entry2', { net: 'fast', interp: 0.01, lw: 1, lc: 1, raw: 1, filter: 0, vsync: 0, hisnd: 1, mixa: 0.1, sens: 3.2, zoom: 1, xt: 0, xs: 'small', xc: '0 230 255', xtr: 0, xdyn: 0, bob: 0, fastsw: 1 }, 'top'],
  ['pistol', 'st_pistol', 'st_pistol2', { net: 'fast', interp: 0.01, lw: 1, lc: 1, raw: 1, filter: 0, vsync: 0, hisnd: 1, mixa: 0.1, sens: 2.4, zoom: 1, xt: 0, xs: 'small', xc: '255 255 255', xtr: 0, xdyn: 0, bob: 0, fastsw: 1 }, 'top'],
  ['low', 'st_low', 'st_low2', { net: 'fast', interp: 0.01, lw: 1, lc: 1, raw: 1, filter: 0, vsync: 0, hisnd: 1, mixa: 0.1, sens: 1.4, zoom: 0.9, xt: 0, xs: 'extra_small', xc: '255 255 255', xtr: 0, xdyn: 0, bob: 0 }, 'top'],
  ['high', 'st_high', 'st_high2', { net: 'fast', interp: 0.01, lw: 1, lc: 1, raw: 1, filter: 0, vsync: 0, hisnd: 1, mixa: 0.1, sens: 4.5, zoom: 1.2, xt: 0, xs: 'medium', xc: '255 210 60', xtr: 0, xdyn: 0, bob: 0 }, 'top'],
  ['classic', 'st_classic', 'st_classic2', { net: 'fast', interp: 0.01, lw: 1, lc: 1, raw: 1, filter: 0, vsync: 0, hisnd: 1, mixa: 0.1, sens: 2.5, zoom: 1.2, xt: 0, xs: 'medium', xc: '50 250 50', xtr: 0, xdyn: 0, bob: 0.01 }, 'top'],
  ['csgo', 'st_csgo', 'st_csgo2', { bobst: 2, bobv: 0.13, bobl: 0.32, boblow: 8, lagst: 2, lagsc: 1, fovlerp: 0.2, camint: 1, vmx: 1, vmy: 0, vmz: -1, vmfov: 90, xt: 0, xs: 'small', xc: '50 250 50', xdyn: 0 }, 'top'],
  ['new', 'st_new', 'st_new2', { sens: 3, zoom: 1.2, raw: 1, xt: 0, xs: 'medium', xc: '255 210 60', xdyn: 0, bob: 0.01 }, 'top'],
  ['clanwar', 'st_clanwar', 'st_clanwar2', { net: 'fast', interp: 0.01, lw: 1, lc: 1, raw: 1, filter: 0, vsync: 0, hisnd: 1, mixa: 0.1, voice: 1, vscale: 1.2, mp3off: 1, mmusic: 0, saytm: 8, netg: 0, dmax: 6, hs: 1, cid: 1 }, 'sit'],
  ['zombie', 'st_zombie', 'st_zombie2', { sens: 3.5, xdyn: 0, xs: 'medium', vol: 0.9, dmax: 8, saytm: 8, decals: 1000 }, 'sit'],
  ['dmcfg', 'st_dm', 'st_dm2', { net: 'fast', interp: 0.01, lw: 1, lc: 1, raw: 1, filter: 0, vsync: 0, hisnd: 1, mixa: 0.1, dmax: 8, dtime: 4, saytm: 4, hs: 1, cid: 0, decals: 1000, fastsw: 1 }, 'sit'],
  ['stream', 'st_stream', 'st_stream2', { netg: 0, showfps: 0, nover: 1, dmax: 5, saytm: 6, decals: 2000 }, 'sit'],
  ['vis', 'st_vis', 'st_vis2', { gamma: 2.7, dyn: 0, detail: 0, hor: 1, fov: 90, vmfov: 90 }, 'pc'],
  ['lowpc', 'st_lowpc', 'st_lowpc2', { detail: 0, shadows: 0, dyn: 0, vsync: 0, decals: 300, fps: 100, hisnd: 1, mixa: 0.15 }, 'pc'],
  ['slownet', 'st_slownet', 'st_slownet2', { net: 'slow', interp: 0.1, lw: 1, lc: 1 }, 'pc'],
  ['midnet', 'st_midnet', 'st_midnet2', { net: 'mid', interp: 0.05, lw: 1, lc: 1 }, 'pc'],
  ['csdef', 'st_csdef', 'st_csdef2', { sens: 3, zoom: 1.2, raw: 1, filter: 0, xt: 0, xs: 'medium', xc: '50 250 50', xtr: 0, xdyn: 0, fps: 100, interp: 0.1, net: 'slow', bob: 0.01, gamma: 2.5, fov: 90, vmfov: 90 }, 'def']
];
function applyStyle(id) {
  each(STYLES, function (x) { if (x[0] === id) for (var k in x[3]) if (x[3].hasOwnProperty(k)) E[k] = x[3][k]; });
  if (!(E.fps >= 100)) E.fps = 100;
  E.xp = presetOf(E); showSetTab('tools'); toast(T('st_ok'), 4000);
}
/* ---- kompyuter quvvati (XClient.exe aniqlaydi) ---- */
function hwClass() {
  if (!HW) return 'mid';
  var weakGpu = /intel.*(hd|gma|uhd)|sis |via |radeon.*(hd [2-5]|x[0-9])|geforce (6|7|8|9|2[0-9]{2}) /i.test(HW.gpu || '');
  if (HW.ram < 4600 || HW.cpu <= 2 || (weakGpu && HW.ram < 6000)) return 'weak';
  if (/windows (7|8|vista|xp)\b/i.test(HW.os || '')) return 'weak';   // eski Windows: o'yin brauzeri (CEF) bu yerda ko'proq yiqiladi (admin > Yiqilishlar)   // 4 GB li kompyuterlar ham (CS + menyu brauzeri)
  if (HW.ram >= 8000 && HW.cpu >= 4 && !weakGpu) return 'strong';
  return 'mid';
}
function hwText() {
  if (!HW) return T('hw_none');
  return Math.round(HW.ram / 1024) + ' GB RAM · ' + HW.cpu + ' ' + T('hw_cores') + (HW.gpu ? ' · ' + HW.gpu : '');
}
/* kompyuter quvvatiga mos grafika: FPS 100 da barqaror tursin (FPS tushganda o'yin qotadi).
 * 100 dan baland FPS faqat kuchli kompyuterda qoladi; kuchsizda ovoz ham yengilroq (hisound 0, bufer 0.15) */
function gfxPreset(c, s) {
  if (c === 'weak') return { detail: 0, shadows: 0, dyn: 0, vsync: 0, decals: 300, fps: 100, hisnd: 0, mixa: 0.15 };
  if (c === 'mid') return { detail: 0, shadows: 1, dyn: 0, vsync: 0, decals: Math.min(s.decals || 1000, 1000), fps: Math.min(s.fps || 100, 144) };
  return { detail: 1, shadows: 1, dyn: 1, vsync: 0 };
}
function hwAuto() {
  var c = hwClass(), v = gfxPreset(c, E);
  for (var k in v) if (v.hasOwnProperty(k)) E[k] = v[k];
  showSetTab('pro'); toast(T('hw_done').replace('{c}', T('hw_' + c)), 5000);
}
/* ---- o'yin paytida Windows'ni moslash (launcher 1.0.96+: quvvat rejimi, sichqoncha tezlashuvi, fon dasturlari, Game Bar) ---- */
function tunePane() {
  var row = function (k, label, sub) {
    return '<div class="fr w"><div class="lb">' + esc(T(label)) + '<small>' + esc(T(sub)) + '</small></div><div class="tg' + (OPTS[k] ? ' on' : '') + '" data-otg="' + k + '"><i></i></div></div>';
  };
  var h = '<div class="ph2 m">' + esc(T('tn_title')) + '</div>';
  if (!verGE(VERSION, '1.0.96')) return h + '<div class="mut" style="font-size:12px">' + esc(T('tn_old')) + '</div>';
  h += row('tune', 'tn_tune', 'tn_tune2');
  if (OPTS.tune) h += row('macc', 'tn_macc', 'tn_macc2') + row('bgp', 'tn_bgp', 'tn_bgp2');
  if (OPTS.dvr) h += '<div class="rowb"><b>' + esc(T('tn_dvr')) + '</b><small>' + esc(T('tn_dvr2')) + (OPTS.dvroff ? ' \u00b7 ' + esc(T('tn_dvrp')) : '') + '</small>' +
    (OPTS.dvroff ? '' : '<a class="btn red" data-act="dvroff">' + esc(T('tn_dvrb')) + '</a>') + '</div>';
  return h;
}
/* kuchsiz kompyuterga yengil grafika - bir bosishda (Saqlash bosish shart emas) */
function hwLight() {
  if (!S) return;
  var v = gfxPreset('weak', S); E = copy(S);
  for (var k in v) if (v.hasOwnProperty(k)) E[k] = v[k];
  S = copy(E); DB.set = S; persist(); applySettings(S); cloudSave();
  toast(T('hw_on'), 9000);
}
/* bir martalik takliflar (bittadan, "Bezovta qilmaslik" yoqilmagan bo'lsa): kuchsiz kompyuter, Windows Game Bar fon yozuvi */
function tuneHints() {
  if (!CONNECTED && HW && hwClass() === 'weak' && !DB.hwAsk && S) { DB.hwAsk = 1; persist(); return hwLight(); }
  /* 3 GB dan kam xotira (admin > Yiqilishlar: 2 GB li Windows 7 da 17 marta yiqilish) - "Ultra yengil" ham bir marta o'zi yoqiladi */
  if (!CONNECTED && HW && HW.ram && HW.ram < 3000 && !DB.ulAsk && S && !S.ultra) {
    DB.ulAsk = 1; E = copy(S);
    E.ultra = 1; E.detail = 0; E.shadows = 0; E.dyn = 0; E.vsync = 0; E.decals = 300; E.hisnd = 0; E.mixa = 0.15; E.bob = 0; if (!(E.fps >= 100)) E.fps = 100;
    S = copy(E); DB.set = S; persist(); applySettings(S); cloudSave(); toast(T('pr_ulok'), 7000); return;
  }
  if (DB.dnd || CONNECTED || curModal || !HW) return;   // kuchsiz kompyuter - so'ramasdan yengil grafika (Sozlamalarda qaytarsa bo'ladi)
  if (OPTS.dvr && !OPTS.dvroff && !DB.dvrAsk && verGE(VERSION, '1.0.96')) {
    DB.dvrAsk = 1; persist();
    ask(T('dvr_ask'), function () { OPTS.dvroff = 1; saveOpts(T('dvr_ok')); }, false, false, true);
  }
}
/* ---- kontent paketlari (saytdagi mmb/packs) ---- */
var PACKS = null;
function loadPacks() {
  var x; try { x = new XMLHttpRequest(); x.open('GET', 'packs.php?t=' + now(), true); } catch (e) { return; }
  x.onreadystatechange = function () {
    if (x.readyState !== 4) return;
    var r = null; try { r = JSON.parse(x.responseText); } catch (e) {}
    PACKS = r && r.length != null ? r : [];
    if (curModal === 'mdSettings' && setTab === 'cont') showSetTab('cont');
  };
  x.send(null);
  PACKS = undefined;
}
/* ---- spray: rasm -> 112x112 -> 255 rangli tempdecal.wad (WAD3, "{LOGO"); 255-indeks shaffof ----
 * Palitra rasmning o'zidan (median cut) olinadi - qat'iy palitradagidek dog'lar bo'lmaydi.
 * GoldSrc spray uchun eng ko'pi 14336 piksel: 112x112 = 12544. */
var SPR = 112;
function sprayPalette(px) {
  var cols = [], i;
  for (i = 0; i < px.length; i += 4) if (px[i + 3] >= 128) cols.push([px[i], px[i + 1], px[i + 2]]);
  if (!cols.length) cols.push([0, 0, 0]);
  var boxes = [cols];
  while (boxes.length < 255) {
    var bi = -1, best = -1, ch = 0;
    for (i = 0; i < boxes.length; i++) {
      if (boxes[i].length < 2) continue;
      for (var c = 0; c < 3; c++) {
        var mn = 255, mx = 0;
        for (var k = 0; k < boxes[i].length; k++) { var v = boxes[i][k][c]; if (v < mn) mn = v; if (v > mx) mx = v; }
        if (mx - mn > best) { best = mx - mn; bi = i; ch = c; }
      }
    }
    if (bi < 0 || best <= 0) break;
    var bx = boxes[bi];
    bx.sort(function (p, q) { return p[ch] - q[ch]; });
    var mid = bx.length >> 1;
    boxes.splice(bi, 1, bx.slice(0, mid), bx.slice(mid));
  }
  var pal = [];
  for (i = 0; i < boxes.length; i++) {
    var r = 0, g = 0, b = 0, n = boxes[i].length;
    for (var j = 0; j < n; j++) { r += boxes[i][j][0]; g += boxes[i][j][1]; b += boxes[i][j][2]; }
    pal.push([Math.round(r / n), Math.round(g / n), Math.round(b / n)]);
  }
  while (pal.length < 255) pal.push([0, 0, 0]);
  pal.push([0, 0, 255]);
  return pal;
}
function sprayNear(pal, cache, r, g, b) {
  var key = (r << 16) | (g << 8) | b;
  if (cache[key] != null) return cache[key];
  var bi = 0, bd = 1e9;
  for (var i = 0; i < 255; i++) { var p = pal[i], d = (p[0] - r) * (p[0] - r) * 3 + (p[1] - g) * (p[1] - g) * 4 + (p[2] - b) * (p[2] - b) * 2; if (d < bd) { bd = d; bi = i; } }
  return (cache[key] = bi);
}
function sprayLevel(px, w, h, f, pal, cache) {   // f marta kichraytirish (o'rtacha rang), indekslar
  var ow = w / f, oh = h / f, out = new Array(ow * oh);
  for (var y = 0; y < oh; y++) for (var x = 0; x < ow; x++) {
    var r = 0, g = 0, b = 0, a = 0, n = 0;
    for (var yy = 0; yy < f; yy++) for (var xx = 0; xx < f; xx++) {
      var o = ((y * f + yy) * w + (x * f + xx)) * 4;
      if (px[o + 3] >= 128) { r += px[o]; g += px[o + 1]; b += px[o + 2]; n++; }
      a++;
    }
    out[y * ow + x] = n * 2 < a ? 255 : sprayNear(pal, cache, Math.round(r / n), Math.round(g / n), Math.round(b / n));
  }
  return out;
}
function makeWad(px, w, h) {
  var pal = sprayPalette(px), cache = {};
  var mips = [sprayLevel(px, w, h, 1, pal, cache), sprayLevel(px, w, h, 2, pal, cache), sprayLevel(px, w, h, 4, pal, cache), sprayLevel(px, w, h, 8, pal, cache)];
  var sum = 0; each(mips, function (m) { sum += m.length; });
  var lump = 40 + sum + 2 + 768 + 2, total = 12 + lump + 32, b = new Array(total), i;
  for (i = 0; i < total; i++) b[i] = 0;
  function u32(o, v) { b[o] = v & 255; b[o + 1] = (v >> 8) & 255; b[o + 2] = (v >> 16) & 255; b[o + 3] = (v >> 24) & 255; }
  function str(o, t) { for (var k = 0; k < t.length; k++) b[o + k] = t.charCodeAt(k); }
  str(0, 'WAD3'); u32(4, 1); u32(8, 12 + lump);
  var m = 12; str(m, '{LOGO'); u32(m + 16, w); u32(m + 20, h);
  var off = 40; for (i = 0; i < 4; i++) { u32(m + 24 + i * 4, off); off += mips[i].length; }
  var o = m + 40;
  each(mips, function (mm) { for (var k = 0; k < mm.length; k++) b[o++] = mm[k]; });
  b[o] = 0; b[o + 1] = 1; o += 2;                   // 256 rang
  each(pal, function (c) { b[o++] = c[0]; b[o++] = c[1]; b[o++] = c[2]; });
  var d = 12 + lump; u32(d, 12); u32(d + 4, lump); u32(d + 8, lump); b[d + 12] = 0x43; str(d + 16, '{LOGO');
  var bin = ''; for (i = 0; i < total; i++) bin += String.fromCharCode(b[i]);
  return btoa(bin);
}
function sprayFrom(src) {
  if (!PCID) return toast(T('sy_nolaunch'), 5000);
  var im = new Image();
  im.onload = function () {
    var c = document.createElement('canvas'); c.width = SPR; c.height = SPR;
    var g = c.getContext('2d'), sz = Math.min(im.width, im.height);
    g.clearRect(0, 0, SPR, SPR);
    g.drawImage(im, Math.round((im.width - sz) / 2), Math.round((im.height - sz) / 2), sz, sz, 0, 0, SPR, SPR);
    var px; try { px = g.getImageData(0, 0, SPR, SPR).data; } catch (e) { return toast(T('a_photo_bad')); }
    var wad = makeWad(px, SPR, SPR);
    toast(T('lg_wait'));
    api('spray', { d: PCID, wad: wad }, function (r) {
      if (!r.ok) return toast(r.msg || 'Xato', 5000);
      try { DB.sprayPrev = c.toDataURL('image/png'); } catch (e) {}
      DB.sprayT = now(); persist();
      toast(T('sp_ok'), 6000);
      if (curModal === 'mdSettings' && setTab === 'cont') showSetTab('cont');
    });
  };
  im.onerror = function () { toast(T('a_photo_bad')); };
  im.src = src;
}
/* ---- mavzular: xc.css dagi qizil ranglarni boshqa rangga almashtiramiz ---- */
var THEMES = [['red', 0], ['orange', 30], ['gold', 48], ['green', 135], ['cyan', 188], ['blue', 212], ['purple', 272], ['pink', 325]];
function hsl2rgb(h, s, l) {
  function f(n) { var k = (n + h / 30) % 12, a = s * Math.min(l, 1 - l); return Math.round(255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)))); }
  return [f(0), f(8), f(4)];
}
function rgb2hsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  var mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn, h = 0, s = 0;
  if (d) {
    s = d / (1 - Math.abs(2 * l - 1));
    h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h = (h * 60 + 360) % 360;
  }
  return [h, s, l];
}
function themeColor(r, g, b, hue) {
  var c = rgb2hsl(r, g, b);
  if (c[1] < (c[2] < 0.4 ? 0.12 : 0.3) || c[2] < 0.06 || c[2] > 0.94 || (c[0] > 22 && c[0] < 338)) return null;   // faqat qizil tuslar (to'q ramkalar ham)
  return hsl2rgb(hue, c[1], c[2]);
}
function hex2(n) { var h = n.toString(16); return h.length < 2 ? '0' + h : h; }
/* rasmlar (logotiplar) ham tanlangan rangga bo'yaladi: canvas'da qizil piksellar tusini almashtiramiz */
var IMG_TH = {};
function recolorImages(hue) {
  each(document.querySelectorAll('img'), function (im) {
    var o = im.getAttribute('data-osrc') || im.getAttribute('src') || '';
    if (!/(^|\/)(logo|logo_big|spray_logo)\.png$/.test(o)) return;
    im.setAttribute('data-osrc', o);
    if (hue <= 0) { if (im.getAttribute('src') !== o) im.src = o; return; }
    var key = o + '|' + hue;
    if (IMG_TH[key]) { im.src = IMG_TH[key]; return; }
    var src = new Image();
    src.onload = function () {
      try {
        var c = document.createElement('canvas'); c.width = src.width; c.height = src.height;
        var x = c.getContext('2d'); x.drawImage(src, 0, 0);
        var d = x.getImageData(0, 0, c.width, c.height), px = d.data;
        for (var i = 0; i < px.length; i += 4) {
          if (px[i + 3] < 8) continue;
          if (hue > 0) { var t = themeColor(px[i], px[i + 1], px[i + 2], hue); if (t) { px[i] = t[0]; px[i + 1] = t[1]; px[i + 2] = t[2]; } }
        }
        x.putImageData(d, 0, 0); IMG_TH[key] = c.toDataURL('image/png');
        each(document.querySelectorAll('img[data-osrc="' + o + '"]'), function (m) { m.src = IMG_TH[key]; });
      } catch (e) {}
    };
    src.src = o;
  });
}
function themeHue(id) { var hue = -1; each(THEMES, function (x) { if (x[0] === id) hue = x[1]; }); return hue; }
/* Kun / tun rejimi: DB.day 0 - tun (qorong'i, asl), 1 - kun (yorug'), 2 - avto (7:00-19:00 kun).
 * CEF1 da CSS o'zgaruvchilari yo'q - shuning uchun xc.css ning hamma ranglari JS da o'giriladi:
 * qorong'i fon -> och, och matn -> to'q; yorqin aksent ranglar (qizil tugmalar) o'z joyida qoladi. */
function isDay() { var m = DB.day || 0; if (m === 2) { var h = new Date().getHours(); return h >= 7 && h < 19; } return m === 1; }
function dayColor(c) {
  var x = rgb2hsl(c[0], c[1], c[2]), h = x[0], sa = x[1], l = x[2];
  if (sa > 0.45 && l > 0.28 && l < 0.75) return hsl2rgb(h, sa, Math.min(l, 0.52));      // aksent: biroz to'qroq - och fonda o'qilsin
  if (l >= 0.35) return hsl2rgb(h, sa * 0.5, (1 - l) * 0.62);                             // matn: to'q, aniq o'qiladi
  return hsl2rgb(h, sa * 0.55, 0.1 + (1 - l) * 0.86);                                      // fon va ramkalar: och
}
var CSS_SRC = null, LOOK_DAY = false;
function applyTheme(id) {
  var hue = themeHue(id), day = isDay();
  LOOK_DAY = day;
  recolorImages(hue); renderTop2();
  var h0 = document.documentElement; h0.className = (h0.className || '').replace(/(^|\s)day(?=\s|$)/g, '') + (day ? ' day' : '');
  var fs = DB.fs || 1;
  applyBg();
  if (hue <= 0 && !day && fs === 1) { var o0 = $('thcss'); if (o0) o0.parentNode.removeChild(o0); return; }
  var conv = function (r, g, b) {
    var c = hue > 0 ? themeColor(r, g, b, hue) : null;
    if (day) c = dayColor(c || [r, g, b]);
    return c;
  };
  var build = function (src) {
    var css = src.replace(/#([0-9a-f]{6}|[0-9a-f]{3})\b/gi, function (m, h) {
      if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
      var c = conv(parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16));
      return c ? '#' + hex2(c[0]) + hex2(c[1]) + hex2(c[2]) : m;
    }).replace(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(,[^)]*)?\)/gi, function (m, r, g, b, a) {
      var c = conv(+r, +g, +b);
      return c ? (a ? 'rgba(' : 'rgb(') + c.join(',') + (a || '') + ')' : m;
    });
    if (fs !== 1) css = css.replace(/font-size:\s*(\d+(?:\.\d+)?)px/g, function (m, n) { return 'font-size: ' + Math.round(n * fs) + 'px'; });   // kattaroq yozuvlar
    if (day) css += '\n* { text-shadow: none !important; }\n';
    var old = $('thcss'); if (old) old.parentNode.removeChild(old);
    var st = document.createElement('style'); st.id = 'thcss'; st.innerHTML = css;
    document.getElementsByTagName('head')[0].appendChild(st);
  };
  if (CSS_SRC) return build(CSS_SRC);
  var x; try { x = new XMLHttpRequest(); x.open('GET', 'xc.css?th=' + now(), true); } catch (e) { return; }
  x.onreadystatechange = function () {
    if (x.readyState !== 4 || !x.responseText) return;
    CSS_SRC = x.responseText; build(CSS_SRC);
  };
  x.send(null);
}
function dayToggle() {
  DB.day = ((DB.day || 0) + 1) % 3; persist(); cloudSave(); statePush();
  applyTheme(DB.theme || 'red');
  toast(T('dn_' + DB.day), 3000);
}
setInterval(function () { if ((DB.day || 0) === 2 && isDay() !== LOOK_DAY) applyTheme(DB.theme || 'red'); }, 300000);   // avto: soat 7:00 / 19:00 da o'zi almashadi
function renderTop2() {
  var b = $('thbar');
  if (!b) { b = document.createElement('div'); b.id = 'thbar'; (document.getElementById('app') || document.body).appendChild(b); }
  var h = '';
  each(THEMES, function (x) { h += '<a class="' + ((DB.theme || 'red') === x[0] ? 'on' : '') + '" data-theme="' + x[0] + '" style="background:hsl(' + x[1] + ',85%,55%)" title="' + esc(T('th_' + x[0])) + '"></a>'; });
  var dm = DB.day || 0;
  h += '<i class="sp"></i><a class="dn" data-daymode="1">' + (dm === 1 ? '\u2600' : dm === 2 ? 'A' : '\u263e') + ' <span>' + esc(T('dn_s' + dm)) + '</span></a>';
  b.innerHTML = h;
  var lg = $('bLang');
  if (!lg) { var bar = $('bar'), v = $('bVer'); if (bar) { lg = document.createElement('div'); lg.id = 'bLang'; lg.className = 'lng'; lg.setAttribute('data-act', 'langmenu'); bar.insertBefore(lg, v); } }
  var fb = $('bFb');
  if (!fb) { var bar2 = $('bar'); if (bar2 && lg) { fb = document.createElement('div'); fb.id = 'bFb'; fb.className = 'lng fb'; fb.setAttribute('data-act', 'feedback'); bar2.insertBefore(fb, lg); } }
  if (fb) fb.innerHTML = '\u270e ' + esc(T('fb_btn'));
  if (lg) { var cur = null; each(LANGS, function (o) { if (o[0] === CUR_LANG) cur = o; }); lg.innerHTML = (cur ? langBox(cur) : '') + esc(cur ? cur[2] : '') + ' \u25b4'; }
}
/* ---- do'st profili: daraja, statistika, yutuqlar, oxirgi faollik ---- */
function openFrProfile(login) {
  api('uinfo', { login: login }, function (r) {
    if (!r.ok) return toast(r.msg || 'Xato');
    var u = r.u, st = u.st || {}, s = u.server ? srv(u.server) : null, last = u.last || null, ls = last ? srv(last.s) : null;
    var status = u.online ? '<span class="gm">\u25cf</span> ' + esc(u.server ? T('fr_in') + ((s && s.name) || u.server) + (u.map ? ' \u00b7 ' + u.map : '') : T('fr_menu'))
      : esc(T('fr_last').replace('{t}', agoText(u.seen)));
    var h = '<div class="fpro"><div class="fpav' + frameCls(u) + '" style="' + avStyle(u) + '">' + avInner(u, u.name) + '</div>' +
      '<div class="fpn">' + crown(u) + (u.clan ? '<span class="ctag">[' + esc(u.clan.tag) + ']</span> ' : '') + nickHtml(u) + ' <span class="mut">@' + esc(u.login) + '</span></div>' +
      '<div class="fprk">' + rankBadge(u) + ' <b>' + (u.rp || 0) + ' RP</b>' + (u.duels ? ' \u00b7 ' + esc(T('du_rec').replace('{w}', u.duels.w).replace('{l}', u.duels.l).replace('{d}', u.duels.d)) : '') + '</div>' +
      '<div class="mut">' + esc(T('lvl').replace('{n}', u.level)) + ' \u00b7 ID ' + esc(u.id) + (u.created ? ' \u00b7 ' + esc(T('fp_since').replace('{d}', new Date(u.created * 1000).toLocaleDateString())) : '') + '</div>' +
      '<div class="fpst">' + status + '</div>' +
      (last && !u.online ? '<div class="mut fpl">' + esc(T('fp_lastsrv')) + ': <b>' + esc((ls && ls.name) || last.s) + '</b>' + (last.m ? ' \u00b7 ' + esc(last.m) : '') + ' \u00b7 ' + esc(agoText(last.t)) + '</div>' : '') +
      '</div>' + statBox(st) +
      '<div class="fpg"><div><b>' + esc(fmtHours(st.t || 0)) + '</b><span>' + esc(T('ks_time')) + '</span></div><div><b>' + (st.best || 0) + '</b><span>' + esc(T('ks_best')) + '</span></div><div><b>' + (st.wk || 0) + '</b><span>' + esc(T('ks_week')) + '</span></div><div><b>' + (u.nfr || 0) + '</b><span>' + esc(T('m_friends')) + '</span></div></div>';
    var wp = ''; for (var w in (u.wpn || {})) if (u.wpn.hasOwnProperty(w)) wp += '<span class="wpt">' + esc(w) + ' <b>' + u.wpn[w] + '</b></span>';
    if (wp) h += '<div class="ph2 m">' + esc(T('fp_wpn')) + '</div><div>' + wp + '</div>';
    h += '<div class="ph2 m">' + esc(T('ac_title')) + ' (' + (u.ach || []).length + ')</div>' + achBadges(u.ach || []);
    var mine = ME && ME.login.toLowerCase() === u.login.toLowerCase();
    h += '<div class="ph2 m">' + esc(T('wl_title')) + '</div>';
    if (u.isfr || mine) h += '<div class="wladd"><input id="wlIn" class="tx" maxlength="200" placeholder="' + esc(T(mine ? 'wl_ph_me' : 'wl_ph')) + '"><a class="btn red" data-wallsend="' + esc(u.login) + '">' + esc(T('wl_send')) + '</a></div>';
    each(u.wall || [], function (w) {
      var can = mine || (ME && w.from.toLowerCase() === ME.login.toLowerCase());
      h += '<div class="wlr"><b data-frprof="' + esc(w.from) + '">' + esc(w.name) + '</b><small class="mut">' + esc(agoText(w.t)) + '</small>' + (can ? '<a class="wld" data-walldel="' + esc(w.id) + '" data-wallto="' + esc(u.login) + '">\u00d7</a>' : '') + '<div>' + esc(w.text) + '</div></div>';
    });
    if (!(u.wall || []).length) h += '<div class="mut">' + esc(T('wl_none')) + '</div>';
    h += '<div class="fpb">' + (u.isfr ? '<a class="btn" data-chat="' + esc(u.login) + '" data-chatn="' + esc(u.name) + '">' + ico('chat') + ' ' + esc(T('ch_btn')) + '</a>' +
      (u.online ? '<a class="btn" data-ring="' + esc(u.login) + '">' + ico('phone') + ' ' + esc(T('rg_btn')) + '</a><a class="btn" data-duelp="' + esc(u.login) + '" data-dueln="' + esc(u.name) + '">' + ico('swords') + ' ' + esc(T('du_btn')) + '</a>' : '') + '<a class="btn" data-frcmp="' + esc(u.login) + '">VS</a>' : '') +
      (u.server ? '<a class="btn red" data-ip="' + esc(u.server) + '">' + esc(T('join')) + '</a>' : '') + '<a class="btn" data-act="friends">\u2190 ' + esc(T('m_friends')) + '</a></div>';
    openSide('frprof', u.name, h);
  });
}
/* ---- qo'ng'iroq: do'st chaqirsa - ekranda katta oyna va qo'ng'iroq ovozi (30 soniya) ---- */
var RING = null, RING_TM = 0;
function showRing(r) {
  if (RING && RING.login === r.login) return;
  RING = r;
  var b = $('ringBox');
  if (!b) { b = document.createElement('div'); b.id = 'ringBox'; (document.getElementById('app') || document.body).appendChild(b); }
  b.innerHTML = '<div class="rgi">' + ico('phone') + '</div><b>' + esc(r.from) + '</b><span>' + esc(T('rg_in')) + '</span>' +
    '<div class="rgb"><a class="btn red" data-ringok="1">' + esc(T('rg_ans')) + '</a><a class="btn" data-ringok="0">' + esc(T('rg_dec')) + '</a></div>';
  b.style.display = 'block';
  var n = 0; clearInterval(RING_TM);
  var beep = function () { if (++n > 15 || !RING) { clearInterval(RING_TM); if (RING && n > 15) ringAnswer(false); /* javob berilmadi - qo'ng'iroq qilganga "band" deb boradi */ return; } cmd('play buttons/bell1.wav'); };
  beep(); RING_TM = setInterval(beep, 2000);
}
function ringAnswer(ok, silent) {
  var r = RING; RING = null; clearInterval(RING_TM);
  var b = $('ringBox'); if (b) b.style.display = 'none';
  if (!r) return;
  if (!silent) api('ring_ans', { to: r.login, ok: ok ? '1' : '0' }, function () {});
  if (ok) { if (r.srv && r.srv !== CONNECTED) connect(r.srv); else openChat(r.login, r.from); }
}
/* ---- reyting kartasi: unvon, RP, keyingi unvongacha ---- */
function rankCard(u) {
  if (!u) return '';
  var rp = u.rp || 0, i = 0; each(RANKS, function (r, k) { if (rp >= r[1]) i = k; });
  var nx = RANKS[i + 1], pct = nx ? Math.round(100 * (rp - RANKS[i][1]) / (nx[1] - RANKS[i][1])) : 100;
  return '<div class="rkcard rk-' + RANKS[i][0] + '"><div class="rkico">' + esc(T('rk_' + RANKS[i][0]).charAt(0)) + '</div><b>' + esc(T('rk_' + RANKS[i][0])) + '</b><span>' + rp + ' RP</span>' +
    '<div class="xpw"><i style="width:' + pct + '%"></i></div><small class="mut">' + (nx ? esc(T('rk_next').replace('{n}', nx[1] - rp).replace('{r}', T('rk_' + nx[0]))) : esc(T('rk_max'))) + ' \u00b7 ' + esc(T('rk_how')) + '</small></div>';
}
/* ---- sandiqlar: har darajada bittadan. Ichida XP, maxsus nik rangi, ramka ---- */
var NCOLS = ['red', 'orange', 'yellow', 'green', 'cyan', 'blue', 'purple', 'pink'], NRARE = ['gold', 'neon', 'ice', 'toxic', 'rainbow'], FRARE = ['ffire', 'fice', 'fneon', 'ftoxic', 'flegend'];
function openChests(keep) {
  if (!ME) return openLogin();
  var n = ME.chests || 0, inv = ME.inv || { nc: [], fr: [] };
  var h = '<div class="chst"><div class="chestbox' + (n ? '' : ' empty') + '" id="chBox"><i></i><b>' + n + '</b></div><div id="chRes"></div>' +
    (n ? '<a class="btn red big" data-act="chestopen">' + esc(T('ch_open')) + '</a>' : '<div class="mut">' + esc(T('ch_none')) + '</div>') + '<div class="mut small">' + esc(T('ch_how')) + '</div></div>';
  h += '<div class="ph2 m">' + esc(T('ch_nick')) + '</div><div class="ncl"><a class="' + (!ME.nc ? 'on' : '') + '" data-equipnc="">' + esc(T('ch_def')) + '</a>';
  each(NCOLS, function (c) { var ok = ME.level >= 10; h += '<a class="' + (ME.nc === c ? 'on' : '') + (ok ? '' : ' lock') + '" data-equipnc="' + c + '"><span class="nk nk-' + c + '">' + esc(ME.name) + '</span></a>'; });
  each(NRARE, function (c) { var ok = (inv.nc || []).indexOf(c) >= 0; h += '<a class="rare' + (ME.nc === c ? ' on' : '') + (ok ? '' : ' lock') + '" data-equipnc="' + (ok ? c : 'x') + '"><span class="nk nk-' + c + '">' + esc(ok ? ME.name : '???') + '</span></a>'; });
  h += '</div><div class="mut small">' + esc(T('ch_nick2')) + '</div><div class="ph2 m">' + esc(T('ch_frames')) + '</div><div class="frl"><a class="' + (!ME.frame ? 'on' : '') + '" data-equipfr=""><i class="av' + (ME.frame ? '' : frameCls(ME)) + '">' + avInner(ME) + '</i>' + esc(T('ch_def')) + '</a>';
  each(FRARE.concat((inv.fr || []).indexOf('fny') >= 0 || (MIS && MIS.ny) ? ['fny'] : []), function (f) { var ok = (inv.fr || []).indexOf(f) >= 0; h += '<a class="' + (ME.frame === f ? 'on' : '') + (ok ? '' : ' lock') + '" data-equipfr="' + (ok ? f : 'x') + '"><i class="av ' + f + '">' + (ok ? avInner(ME) : '?') + '</i>' + esc(T('fr_' + f)) + '</a>'; });
  openSide('chests', T('chs_title'), h + '</div>');
}
function chestOpen() {
  var b = $('chBox'); if (b) b.className = 'chestbox shake';
  api('chest_open', {}, function (r) {
    if (!r.ok) { if (b) b.className = 'chestbox'; return toast(r.msg || 'Xato', 5000); }
    setTimeout(function () {
      ME.chests = r.chests; ME.inv = r.inv; ME.xp = r.xp; ME.level = r.level; ME.lvlxp = r.lvlxp; renderBar();
      openChests(true);
      var w = r.rw, txt = w.type === 'xp' ? '+' + w.xp + ' XP' : w.type === 'nick' ? T('ch_got_nick') + ': ' + T('nc_' + w.id) : w.type === 'frame' ? T('ch_got_frame') + ': ' + T('fr_' + w.id) : '+1000 XP' + (w.id ? ' + ' + T('fr_' + w.id) : '');
      var el = $('chRes'); if (el) el.innerHTML = '<div class="chrw rr-' + w.rar + '"><small>' + esc(T('rr_' + w.rar)) + '</small><b>' + esc(txt) + '</b></div>';
      sfx('save');
    }, 1300);
  });
}
/* ---- duel: do'stni N daqiqaga chaqirish, kim ko'p kill qilsa ---- */
var DUEL = null, DUEL_INV = null, DUEL_TM = 0;
function showDuelInv(d) {
  if (DUEL_INV && DUEL_INV.id === d.id) return;
  DUEL_INV = d;
  var b = $('ringBox');
  if (!b) { b = document.createElement('div'); b.id = 'ringBox'; (document.getElementById('app') || document.body).appendChild(b); }
  b.innerHTML = '<div class="rgi du">' + ico('swords') + '</div><b>' + esc(d.from) + '</b><span>' + esc(T('du_in').replace('{m}', d.mins)) + '</span>' +
    '<div class="rgb"><a class="btn red" data-duelok="1">' + esc(T('du_acc')) + '</a><a class="btn" data-duelok="0">' + esc(T('rg_dec')) + '</a></div>';
  b.className = 'du'; b.style.display = 'block';
  cmd('play buttons/bell1.wav');
}
function duelAnswer(ok) {
  var d = DUEL_INV; DUEL_INV = null; var b = $('ringBox'); if (b) { b.style.display = 'none'; b.className = ''; }
  if (!d) return;
  api('duel_ans', { id: d.id, ok: ok ? '1' : '0' }, function (r) { if (r.ok && r.duel) { DUEL = r.duel; duelBar(); toast(T('du_go'), 7000); } });
}
function duelBar() {
  var b = $('duelBar');
  if (!DUEL) { if (b) b.style.display = 'none'; clearInterval(DUEL_TM); DUEL_TM = 0; return; }
  if (!b) { b = document.createElement('div'); b.id = 'duelBar'; (document.getElementById('app') || document.body).appendChild(b); }
  var tick = function () {
    if (!DUEL || playing()) return;                 // o'yin paytida chizmaymiz - menyu ochilganda 'show' qayta chizadi
    var left = Math.max(0, DUEL.end - Math.floor(now() / 1000)), f = null;
    each(FRIENDS, function (x) { if (x.login.toLowerCase() === String(DUEL.op).toLowerCase()) f = x; });
    b.innerHTML = ico('swords') + ' ' + esc(T('du_bar')) + ' <b>' + DUEL.me_k + '</b> : <b>' + DUEL.op_k + '</b> ' + esc(DUEL.opn) + ' \u00b7 ' + Math.floor(left / 60) + ':' + ('0' + left % 60).slice(-2) +
      (f && f.server && f.server !== CONNECTED ? ' <a class="btn red" data-ip="' + esc(f.server) + '">' + esc(T('du_join')) + '</a>' : '');
  };
  b.style.display = 'block'; tick(); clearInterval(DUEL_TM); DUEL_TM = setInterval(tick, 1000);
}
function duelResult(d) {
  if (d.st === 'no') return toast(T('du_no').replace('{n}', d.opn), 6000);
  var k = d.win === 'me' ? 'du_win' : d.win === 'op' ? 'du_lose' : 'du_draw';
  openSide('duelres', T('du_title'), '<div class="dures ' + d.win + '"><b>' + esc(T(k)) + '</b><div class="dusc">' + d.me_k + ' : ' + d.op_k + '</div><span>' + esc(T('du_vs').replace('{n}', d.opn)) + '</span><p>' + esc(T(k + '2')) + '</p></div>');
  if (d.win === 'me') sfx('save');
}
/* ---- o'yin xulosasi: serverdan chiqqanda (2+ daqiqa o'ynalgan bo'lsa) ---- */
var XP0 = null, GS_LAST = null;
/* ---- mehmon: o'yindan keyin "Akkaunt oching - +500 XP va sandiq" (2 kunda bir, ko'pi 4 marta) ---- */
function regOfferDue() { return !ME && !DB.dnd && (DB.rgn || 0) < 4 && now() - (DB.rgo || 0) > 2 * 864e5; }
function regOfferMark() { DB.rgo = now(); DB.rgn = (DB.rgn || 0) + 1; persist(); }
function regOfferHtml(force) {
  if (!force) { if (!regOfferDue()) return ''; regOfferMark(); }
  return '<div class="rgo"><b>' + esc(T('ro_t')) + '</b><p>' + esc(T('ro_d')) + '</p><a class="btn red" data-act="regoffer">' + esc(T('ro_btn')) + '</a></div>';
}
/* ---- birinchi ochilish: 3 ta slayd ---- */
var TOUR_I = 0, TOUR = [['\u25B6', 'tr_1t', 'tr_1d'], ['\u265B', 'tr_2t', 'tr_2d'], ['\u2605', 'tr_3t', 'tr_3d']];
function tourShow() {
  if (DB.tour) return;
  if (DB.dnd || (DB.hist && DB.hist.length) || ME || DB.token) { DB.tour = 1; persist(); return; }   // eski o'yinchilarga ko'rsatmaymiz
  if (CONNECTED || curModal || playing()) return setTimeout(tourShow, 30000);
  TOUR_I = 0; tourDraw(); openModal('mdTour');
}
function tourDraw() {
  var t = TOUR[TOUR_I], d = '', last = TOUR_I === TOUR.length - 1;
  for (var i = 0; i < TOUR.length; i++) d += '<i' + (i === TOUR_I ? ' class="on"' : '') + '></i>';
  $('trI').innerHTML = t[0]; $('trT').innerHTML = esc(T(t[1])); $('trD').innerHTML = esc(T(t[2])); $('trDots').innerHTML = d;
  $('trNext').innerHTML = esc(T(last ? 'tr_go' : 'tr_next')); $('trSkip').innerHTML = esc(T('tr_skip'));
  $('trReg').innerHTML = esc(T('tr_reg')); $('trReg').style.display = last && !ME ? '' : 'none';
}
function tourEnd() { DB.tour = 1; persist(); closeModal(); }
function gameSummary(g) {
  if (!g || DB.dnd || DB.gsum === 0 || (g.d || 0) < 120 || (g.k || 0) + (g.x || 0) < 2) return;
  if (curModal && curModal !== 'mdSide') return;                // o'yinchi boshqa oynada - xalaqit bermaymiz
  var kd = g.x ? (g.k / g.x).toFixed(2) : String(g.k || 0), hs = g.k ? Math.round((g.h || 0) * 100 / g.k) : 0;
  var fav = '', fn = 0; for (var w in g.w || {}) if (g.w.hasOwnProperty(w) && g.w[w] > fn) { fn = g.w[w]; fav = w; }
  var clips = 0;
  each(OPTS && OPTS.vids || [], function (v) {
    var m = /^xc_(\d{4})(\d\d)(\d\d)_(\d\d)(\d\d)(\d\d)$/.exec(v.n || '');
    if (m && new Date(+m[1], m[2] - 1, +m[3], +m[4], +m[5], +m[6]).getTime() >= g.t - 60000) clips++;
  });
  var xp = ME && XP0 != null && ME.xp >= XP0 ? ME.xp - XP0 : 0;
  var row = function (l, v) { return '<div class="kv"><span>' + esc(T(l)) + '</span><b>' + esc(String(v)) + '</b></div>'; };
  var h = '<div class="ydc gsum"><div class="gsh">' + esc(g.name || g.ip) + (g.map ? ' \u00b7 ' + esc(g.map) : '') + ' \u00b7 ' + esc(fmtHours(g.d)) + '</div>' +
    '<div class="ydg"><div><b>' + (g.k || 0) + '</b><span>' + esc(T('ks_k')) + '</span></div><div><b>' + (g.x || 0) + '</b><span>' + esc(T('ks_d')) + '</span></div>' +
    '<div><b>' + kd + '</b><span>K/D</span></div><div><b>' + hs + '%</b><span>' + esc(T('gs_hs')) + '</span></div></div>' +
    '<div class="stmore">' + row('gs_streak', g.bs || 0) + row('gs_hsn', g.h || 0) + (g.a ? row('gs_assist', g.a) : '') + (fav ? row('gs_fav', fav + ' (' + fn + ')') : '') +
    (xp ? row('gs_xp', '+' + xp + ' XP') : '') + (clips ? row('gs_clips', clips) : '') + (ME && DB.dstk && now() - DB.dstk.t < 86400000 ? row('dc_tmr', '+' + dailyXp(DB.dstk.s + 1) + ' XP' + ((DB.dstk.s + 1) % 7 === 0 ? ' + ' + T('dc_chest') : '')) : '') + '</div>' +
    '<p class="mut">' + esc(T((g.k || 0) >= 25 || kd >= 2 ? 'gs_great' : (g.k || 0) >= 10 ? 'gs_good' : 'gs_ok')) + '</p>' +
    (LITE ? '<div class="gslite" data-act="promo">' + ico('gift') + ' <b>' + esc(T('lp_gs')) + '</b><span>' + esc(T('lp_gs2')) + '</span></div>' : ME ? '' : regOfferHtml()) +
    (ME ? '<a class="btn red" data-act="gsshare">' + ico('share') + ' ' + esc(T('gs_share')) + '</a> ' : '') +
    refBtn('') + ' ' +
    (clips ? '<a class="btn red" data-act="gsvids">' + ico('play') + ' ' + esc(T('gs_vids')) + '</a> ' : '') +
    '<a class="btn" data-act="gsoff">' + esc(T('gs_off')) + '</a></div>';
  GS_LAST = g;
  openSide('gsum', T('gs_title'), h);
}
/* ---- "Kechagi o'yiningiz": kun boshida qisqa xulosa ---- */
function showYesterday(y) {
  var kd = y.d ? (y.k / y.d).toFixed(2) : String(y.k);
  openSide('yday', T('yd_title'), '<div class="ydc"><div class="ydg"><div><b>' + esc(fmtHours(y.t)) + '</b><span>' + esc(T('ks_time')) + '</span></div><div><b>' + y.g + '</b><span>' + esc(T('ks_g')) + '</span></div><div><b>' + y.k + '</b><span>' + esc(T('ks_k')) + '</span></div><div><b>' + kd + '</b><span>K/D</span></div></div>' +
    '<p>' + esc(T('yd_best').replace('{n}', y.best || 0)) + (y.top ? '<br>' + esc(T('yd_srv').replace('{s}', y.top)) : '') + '</p><p class="mut">' + esc(T(y.k >= 30 ? 'yd_great' : 'yd_ok')) + '</p></div>');
}
/* "Muammo bor" - diagnostika: versiya, kompyuter, o'yin sozlamalari, menyu tezligi va xatolari (konsol logi bilan birga yuboriladi) */
function diagText() {
  var L = ['===== X CLIENT DIAGNOSTIKA =====', 'Menyu: v' + (window.XC_V || '?') + ' · launcher v' + (VERSION || '?') + ' · ' + new Date().toString(),
    'Kompyuter: ' + (PCID || 'noma\'lum') + (HW ? ' · CPU ' + (HW.cpu || '?') + ' yadro · RAM ' + (HW.ram || '?') + ' MB · GPU ' + (HW.gpu || '?') + ' · ekran ' + (HW.res || '') : ''),
    'Akkaunt: ' + (ME ? ME.login + ' (' + ME.level + '-daraja)' : 'kirmagan') + ' · til: ' + CUR_LANG + ' · beta: ' + (window.XC_BETA ? 'ha' : 'yo\'q'),
    'Server: ' + (CONNECTED || 'ulanmagan') + (CONNECTED && SRV[CONNECTED] ? ' · ' + (SRV[CONNECTED].name || '') + ' · ping ' + (SRV[CONNECTED].ping || '?') : ''),
    'Menyu: ochilish ' + Math.round(PERF.load) + ' ms · eng katta qotish ' + Math.round(PERF.lag) + ' ms · menyu FPS ' + (PERF.fps || '?') + ' · yengil rejim: ' + (lowFx() ? 'ha' : 'yo\'q'),
    'Menyu xatolari: ' + ((window.XC_ERRS || []).join(' | ') || 'yo\'q')];
  var cv = ['fps_max', 'fps_override', 'gl_vsync', 'rate', 'cl_updaterate', 'cl_cmdrate', 'ex_interp', 'm_rawinput', 'sensitivity', 'volume', 'voice_enable', 'voice_modenable', 'voice_dsound', 'voice_forcemicrecord', 'voice_scale', 'voice_loopback', '_snd_mixahead', 'hisound', 'net_graph', 'developer', 'gl_texturemode', 'r_detailtextures', 'gamma', 'brightness'];
  var o = []; each(cv, function (n) { var v = readCvar(n); if (v != null) o.push(n + '=' + v); });
  L.push('Sozlamalar: ' + (o.join(' · ') || 'o\'qib bo\'lmadi'));
  return L.join('\n');
}
/* ---- menyu tezligi: ochilish vaqti, eng katta qotish, menyu FPS - sessiyada bir marta (admin panel > Tezlik) ---- */
var PERF = { t0: 0, load: 0, lag: 0, fps: 0, sent: false };
function perfStart() {
  try { var nt = window.performance && performance.timing && performance.timing.navigationStart; PERF.load = nt ? now() - nt : 0; } catch (e) {}
  var last = now();
  var iv = setInterval(function () { var t = now(); if (uiShown() && !document.webkitHidden) PERF.lag = Math.max(PERF.lag, t - last - 250); last = t; }, 250);
  var raf = window.requestAnimationFrame || window.webkitRequestAnimationFrame;
  if (raf) setTimeout(function () { var n = 0, t1 = now(); var f = function () { n++; if (now() - t1 < 3000) raf(f); else PERF.fps = Math.round(n * 1000 / (now() - t1)); }; raf(f); }, 8000);
  setTimeout(function () { clearInterval(iv); perfSend(); }, 120000);
}
function perfSend() {
  if (PERF.sent) return; PERF.sent = true;
  api('perf', { v: window.XC_V || '', load: Math.round(PERF.load), lag: Math.round(PERF.lag), fps: PERF.fps, game: CONNECTED ? 1 : 0, low: lowFx() ? 1 : 0 }, function () {});
}
/* ko'rinish buzilsa (blok o'z panelidan chiqib ketsa) - admin panelga xato sifatida yuboriladi (sessiyada bir marta) */
var LAYOUT_SENT = {};
function layoutCheck(where) {
  setTimeout(function () {
    try {
      var bad = '', sb = document.querySelector('.modal.on #setBody');
      if (sb) each(sb.children, function (c) { if (!bad && !/(^|\s)(pane|hsub|kpick)(\s|$)/.test(c.className || '') && c.getBoundingClientRect().width) bad = (c.className || c.tagName) + ' panel tashqarisida'; });
      each(document.querySelectorAll('.modal.on .pane'), function (pn) {
        if (bad) return; var pr = pn.getBoundingClientRect(); if (!pr.width) return;
        each(pn.children, function (c) { if (bad) return; var r = c.getBoundingClientRect(); if (r.width && (r.left < pr.left - 6 || r.right > pr.right + 6)) bad = (c.className || c.tagName); });
        var sib = pn.nextSibling; if (!bad && sib && sib.className && /pane/.test(sib.className)) { var sr = sib.getBoundingClientRect(); if (sr.width && pr.right > sr.left + 6) bad = 'panes-overlap'; }
      });
      if (bad && !LAYOUT_SENT[where]) { LAYOUT_SENT[where] = 1; api('jserr', { msg: 'layout: ' + where + ' (' + String(bad).slice(0, 60) + ')', src: 'layout', line: 0, ver: window.XC_V || '' }, function () {}); }
    } catch (e) {}
  }, 400);
}
/* CFG kodini qo'yish (kod yozilganda yoki "Mashhur CFGlar" dan) */
function cfgUse(code) {
  api('cfg_get', { code: code }, function (r) {
    if (!r.ok || !r.cfg) return toast(r.msg || T('cf_bad'));
    if (curModal !== 'mdSettings') openSettings('tools');
    var c2 = r.cfg; for (var k in c2.s || {}) if (c2.s.hasOwnProperty(k) && DEF.hasOwnProperty(k) && k !== 'name' && k !== 'tag') E[k] = c2.s[k];
    if (c2.b) { DB.binds = c2.b; DB.binds2 = c2.b2 || {}; loadBinds(); applyBinds(); persist(); }
    E.xp = presetOf(E); toast(T('cf_loaded'), 6000); showSetTab('tools');
  });
}
function openCfgTop() {
  api('cfg_top', {}, function (r) {
    if (!r.ok) return toast(r.msg || 'Xato');
    var h = '<div class="mut" style="margin-bottom:10px">' + esc(T('ct_sub')) + '</div>';
    each(r.list || [], function (x, i) {
      h += '<div class="ctr"><span class="rk c">' + (i + 1) + '</span><b>' + esc(x.title) + '</b><small class="mut">' + (x.who ? '@' + esc(x.who) + ' \u00b7 ' : '') + esc(T('ct_uses').replace('{n}', x.uses)) + ' \u00b7 ' + esc(x.code) + '</small>' +
        '<a class="btn" data-cfglike="' + esc(x.code) + '">\u2665 ' + x.likes + '</a><a class="btn red" data-cfguse="' + esc(x.code) + '">' + esc(T('ct_use')) + '</a></div>';
    });
    if (!(r.list || []).length) h += '<div class="empty">' + esc(T('ct_none')) + '</div>';
    openSide('cfgtop', T('ct_title'), h);
  });
}
/* "Taklif / shikoyat": matn admin panelga (Fikrlar) va Telegram'ga boradi */
var FBK = 'idea';
function openFeedback() {
  FBK = 'idea';
  var h = '<div class="mut" style="margin-bottom:10px">' + esc(T('fb_sub')) + '</div><div class="seg">';
  each(['idea', 'bug', 'complain'], function (k) { h += '<a class="' + (k === FBK ? 'on' : '') + '" data-fbk="' + k + '">' + esc(T('fb_' + k)) + '</a>'; });
  h += '</div><textarea id="fbTx" maxlength="1500" style="width:100%;height:150px;margin:8px 0 12px;padding:10px;box-sizing:border-box;resize:none" placeholder="' + esc(T('fb_ph')) + '"></textarea>' +
    '<a class="btn red" data-act="fbsend">' + esc(T('fb_send')) + '</a>';
  openSide('feedback', T('fb_title'), h);
  setTimeout(function () { try { $('fbTx').focus(); } catch (e) {} }, 50);
}
function sendFeedback() {
  var x = $('fbTx'), v = x ? clean(x.value) : '';
  if (v.length < 3) return toast(T('fb_short'));
  api('feedback', { text: v, kind: FBK, nick: MYNAME || (S && S.name) || '', ver: VERSION }, function (r) {
    if (!r.ok) return toast(r.msg || 'Xato');
    closeModal(); toast(T('fb_ok'), 5000);
  });
}
/* net_graph yoqilgan bo'lsa (o'yin uni ekranning pastki burchagiga chizadi) - pastki chiziqdagi yozuvlar shu burchakdan
 * chetga suriladi, ustma-ust tushmaydi. net_graphpos: 1 - o'ngda (odatiy), 2 - o'rtada, 3 - chapda */
function ngFit() {
  var b = $('bar'); if (!b) return;
  var ng = Number(readCvar('net_graph')) || 0, pos = Number(readCvar('net_graphpos')) || 1;
  var c = ng > 0 ? (pos === 3 ? ' ngl' : pos === 2 ? '' : ' ngr') : '';
  b.className = (b.className || '').replace(/(^|\s)ng[lr](?=\s|$)/g, '') + c;
}
setInterval(function () { if (!playing()) ngFit(); }, 5000);   // o'yin paytida tekshirmaymiz
function langMenu() {
  var p = $('lngpop');
  if (p) { p.parentNode.removeChild(p); return; }
  p = document.createElement('div'); p.id = 'lngpop';
  var h = '';
  each(LANGS, function (o) { h += '<a class="' + (CUR_LANG === o[0] ? 'on' : '') + '" data-lang="' + o[0] + '">' + langBox(o) + esc(o[2]) + '</a>'; });
  p.innerHTML = h; (document.getElementById('app') || document.body).appendChild(p);
}
function openSettings(tab) {
  detectXext();
  seedFromGame();
  E = copy(S);
  openModal('mdSettings');
  showSetTab(tab || (DEMO_PLAY ? 'demo' : setTab));   // demo ko'rilayotganda sozlamalar pult bilan ochiladi
}
function showSetTab(tab) {
  var nm = $('fName'); if (nm && E) E.name = nm.value.replace(/["\\;]/g, '').slice(0, 28);
  setTab = tab;
  if (!PCID && (tab === 'cont' || tab === 'pro' || tab === 'system') && now() - OPTS_TRY > 5000) { OPTS_TRY = now(); loadOpts(); }   // launcher keyinroq ochilgan bo'lsa - qayta topamiz
  each(document.querySelectorAll('#setTabs a'), function (a) { a.className = a.getAttribute('data-tab') === tab ? 'on' : ''; });
  $('setBody').innerHTML = (PANES[tab] || PANES.game)();
  $('setNote').innerHTML = esc(ME && DB.autosave ? T('note_cloud') : T('note_local'));
  if (tab === 'demo') vidsRefresh();
  if (tab === 'hud') { drawXhair(); drawScope(); if (XLIVE || E && S && xcode(E) !== xcode(S)) xLive(); }
  layoutCheck('settings/' + tab);
}
/* Video bo'limi: launcher sozlamalari (OPTS - o'yin ochilishida qo'llanadi) va ekran formati */
function vseg(k, cur, opts) { var h = ''; each(opts, function (o) { h += '<a class="' + (cur === o[0] ? 'on' : '') + '" data-vseg="' + k + '" data-v="' + o[0] + '">' + esc(T(o[1])) + '</a>'; }); return h; }
function votg(k, label, sub) { return '<div class="fr w"><div class="lb">' + esc(T(label)) + (sub ? '<small>' + esc(T(sub)) + '</small>' : '') + '</div><div class="tg' + (OPTS[k] ? ' on' : '') + '" data-otg="' + k + '"><i></i></div></div>'; }
function tg(key, label, sub) {
  return '<div class="fr w"><div class="lb">' + esc(T(label)) + (sub ? '<small>' + esc(T(sub)) + '</small>' : '') + '</div>' +
    '<div class="tg' + (E[key] ? ' on' : '') + '" data-tg="' + key + '"><i></i></div></div>';
}
function sl(key, label, min, max, step, sub, unit) {
  return '<div class="fr"><div class="lb">' + esc(T(label)) + (sub ? '<small>' + esc(T(sub)) + '</small>' : '') + '</div><div class="ct2"><div class="sl">' +
    '<input type="range" min="' + min + '" max="' + max + '" step="' + step + '" value="' + E[key] + '" data-sl="' + key + '"' + (unit ? ' data-u="' + unit + '"' : '') + '><div class="vv" id="vv_' + key + '">' + E[key] + (unit || '') + '</div></div></div></div>';
}
function seg(key, label, opts) {
  var h = '';
  each(opts, function (o) { h += '<a class="' + (String(E[key]) === String(o[0]) ? 'on' : '') + '" data-seg="' + key + '" data-v="' + esc(o[0]) + '">' + esc(T(o[1])) + '</a>'; });
  return '<div class="fr"><div class="lb">' + esc(T(label)) + '</div><div class="ct2 seg">' + h + '</div></div>';
}
function rowb(title, sub, act, btn) {
  return '<div class="rowb"><b>' + esc(T(title)) + '</b><small>' + esc(T(sub)) + '</small><a class="btn" data-act="' + act + '">' + esc(T(btn)) + '</a></div>';
}
function daysAgo(t) { return Math.max(0, Math.floor((now() / 1000 - t) / 86400)); }
var PANES = {
  game: function () {
    var nets = '';
    each([['slow', 'n_slow', 'n_slow2'], ['mid', 'n_mid', 'n_mid2'], ['fast', 'n_fast', 'n_fast2']], function (o) {
      nets += '<a class="' + (E.net === o[0] ? 'on' : '') + '" data-seg="net" data-v="' + o[0] + '">' + esc(T(o[1])) + '<small>' + esc(T(o[2])) + '</small></a>';
    });
    return '<div class="pane l"><div class="ph2">' + esc(T('g_player')) + '</div>' +
      '<div class="fr"><div class="lb">' + esc(T('g_name')) + '</div><div class="ct2"><input class="tx" id="fName" maxlength="28" value="' + esc(E.name) + '"></div></div>' +
      seg('tag', 'g_tag', [['X | ', 'X |'], ['[UZ] ', '[UZ]']].concat(ME && ME.clan ? [['[' + ME.clan.tag + '] ', '[' + ME.clan.tag + ']']] : []).concat([['', 'g_none']])) +
      '<div class="ph2 m">' + esc(T('g_net')) + '</div><div class="big">' + nets + '</div>' +
      '<div class="mut" style="margin:10px 0 14px;font-size:12px">' + esc(T('g_net_note')) + '</div>' + tg('aimnet', 'g_aimnet', 'g_aimnet2') + tg('reconn', 'g_reconn') + tg('rtag', 'g_rtag', 'g_rtag2') + tg('rest', 'g_rest', 'g_rest2') + '</div>' +
      '<div class="pane r"><div class="ph2">' + esc(T('g_server')) + '</div>' +
      tg('queue', 'g_queue', 'g_queue2') + tg('mp3off', 'g_mp3', 'g_mp32') + tg('hand', 'g_hand') + tg('fastsw', 'g_fast') + tg('aws', 'g_aws', 'g_aws2') +
      (ncHas('cl_discordrpc') ? '<div class="ph2 m">Discord</div>' + tg('drpc', 'g_drpc', 'g_drpc2') + tg('drpcs', 'g_drpcs') + tg('drpcj', 'g_drpcj') : '') + '</div>';
  },
  keys: function () {
    var rows = '';
    each(ACTIONS, function (ac) {
      var k = BINDS[ac[0]] || '', k2 = BINDS2[ac[0]] || '', w1 = KEYWAIT === ac[0] && KEYSLOT === 1, w2 = KEYWAIT === ac[0] && KEYSLOT === 2;
      rows += '<div class="kb">' + esc(CUR_LANG === 'ru' || LFALL[CUR_LANG] === 'ru' ? ac[2] : ac[1]) +
        '<span class="k1' + (w1 ? ' w' : '') + '" data-bind="' + esc(ac[0]) + '">' + (w1 ? esc(T('k_press')) : esc(keyLabel(k) || '\u2014')) + '</span>' +
        '<span class="k2' + (w2 ? ' w' : '') + '" data-bind2="' + esc(ac[0]) + '">' + (w2 ? esc(T('k_press')) : esc(keyLabel(k2) || '+')) + '</span></div>';
    });
    return '<div class="pane full"><div class="ph2">' + esc(T('k_title')) + '<span class="mut" style="float:right;letter-spacing:0;font-weight:normal">' + esc(T('k_note2')) + '</span></div>' +
      '<div class="kcols">' + rows + '</div>' +
      '<div class="ph2 m">' + esc(T('k_buy')) + '</div>' + tg('buykeys', 'k_buy2') +
      '<div class="mut" style="font-size:12px;line-height:20px">F1: M4A1/AK-47 \u00b7 F2: AWP \u00b7 F3: Kevlar+Helmet, Defuse kit \u00b7 F4: HE + 2\u00d7Flash + Smoke</div>' +
      '<a class="btn" style="margin:14px 8px 0 0" data-act="keysdef">' + esc(T('k_def')) + '</a><a class="btn out" style="margin:14px 0 0" data-act="keysfactory">' + esc(T('k_factory')) + '</a></div>' +
      (KEYWAIT ? '<div class="kpick">' + esc(T('k_pick')) + ' ' + ['MOUSE3', 'MOUSE4', 'MOUSE5', 'MWHEELUP', 'MWHEELDOWN', 'SHIFT', 'CTRL', 'ALT', 'SPACE', 'TAB', 'CAPSLOCK'].map(function (k) { return '<a data-pickkey="' + k + '">' + esc(LANG.uz['kp_' + k] != null ? T('kp_' + k) : k) + '</a>'; }).join('') + '<a data-pickkey="">' + esc(T('cancel')) + '</a></div>' : '');
  },
  mouse: function () {
    return '<div class="pane l"><div class="ph2">' + esc(T('mo_title')) + '</div>' + sl('sens', 'mo_sens', 0.5, 10, 0.1) + sl('zoom', 'mo_zoom', 0.2, 3, 0.05) +
      '<div class="ph2 m">' + esc(T('aw_title')) + '</div>' + sl('awps', 'aw_sens', 0, 10, 0.1) + sl('awpz', 'aw_zoom', 0.2, 3, 0.05) +
      '<div class="mut" style="font-size:12px;line-height:18px">' + esc(T('aw_note')) + '</div></div>' +
      '<div class="pane r"><div class="ph2">&nbsp;</div>' + tg('raw', 'mo_raw', 'mo_raw2') + tg('filter', 'mo_filter') + tg('inv', 'mo_inv') + '</div>';
  },
  sound: function () {
    return '<div class="pane l"><div class="ph2">' + esc(T('so_title')) + '</div>' + sl('vol', 'so_vol', 0, 1, 0.05) + sl('mus', 'so_mus', 0, 1, 0.05) + sl('vscale', 'so_vscale', 0, 2, 0.1) + '</div>' +
      '<div class="pane r"><div class="ph2">&nbsp;</div>' + tg('voice', 'so_voice') + tg('micwarm', 'so_micwarm', 'so_micwarm2') + tg('micfix', 'so_micfix', 'so_micfix2') + tg('loop', 'so_loop') + tg('mute', 'so_mute') + tg('uisnd', 'so_ui', 'so_ui2') +
      '<div class="ph2 m">' + esc(T('so_q')) + '</div>' + tg('hisnd', 'so_hi') + seg('mixa', 'so_mix', [[0.1, 'so_mix2'], [0.15, 'so_mix3']]) + '</div>';
  },
  video: function () {
    return '<div class="pane l"><div class="ph2">' + esc(T('v_title')) + '</div>' +
      seg('fps', 'v_fps', [[100, '100'], [144, '144'], [200, '200'], [300, '300'], [500, '500']]) +
      '<div class="mut" style="margin:-6px 0 8px;font-size:12px">' + esc(T('v_fps2')) + '</div>' +
      sl('bright', 'v_brt', 0, 2, 0.1) + sl('gamma', 'v_gam', 1, 3, 0.1) + sl('fov', 'v_fov', 70, 100, 1, 'v_fov2') + sl('vmfov', 'v_vm', 70, 100, 1) + sl('decals', 'v_dec', 300, 4000, 100) +
      tg('showfps', 'v_showfps') + tg('dyn', 'v_dyn') + tg('lowgfx', 'v_low', 'v_rs') + '</div>' +
      '<div class="pane r"><div class="ph2">' + esc(T('v_scr')) + '</div>' +
      '<div class="fr"><div class="lb">' + esc(T('v_ar')) + '</div><div class="ct2 seg">' + vseg('ar', scrAr(), [['43', 'v_ar43'], ['169', 'v_ar169'], ['1610', 'v_ar1610']]) + '</div></div>' +
      '<div class="fr"><div class="lb">' + esc(T('sy_screen')) + '</div><div class="ct2"><a class="dd wide" data-dd="res"><span>' + esc(ddLabel('res')) + '</span><i>\u25be</i></a></div></div>' +
      (resSmall() ? '<div class="chk bad" style="margin:4px 0 8px">' + esc(T('v_small').replace('{m}', monRes().join('\u00d7')).replace('{r}', OPTS.res.replace('x', '\u00d7'))) + ' <a class="btn red" data-act="resauto" style="margin-left:6px">' + esc(T('v_small_go')) + '</a></div>' : '') +
      '<div class="fr"><div class="lb">' + esc(T('v_mode')) + '</div><div class="ct2 seg">' + vseg('win', String(winEff()), [['0', 'v_m_full'], ['1', 'v_m_win'], ['2', 'v_m_bl']]) + '</div></div>' +
      '<div class="mut small" style="margin:-4px 0 10px">' + esc(T(winEff() === 2 ? 'v_m_blh' : winEff() === 0 ? 'v_m_fullh' : 'v_m_winh')) + '</div>' +
      tg('vsync', 'v_vsync') + tg('hdm', 'v_hdm', 'v_rs') + tg('addons', 'v_addons', 'v_rs') + votg('stretch', 'v_stretch', 'v_rs') + tg('hor', 'v_hor') +
      tg('detail', 'v_detail') + votg('ontop', 'v_ontop') + votg('flash', 'v_flash') + '</div>';
  },
  tools: function () {                            // Qo'shimcha: profillar, kalkulyator, tayyor uslublar, demolar
    var pr = '';
    each(profSlots(), function (sl, i) {
      pr += '<div class="rowb"><b class="pn" data-pren="' + i + '">' + esc(sl.n) + ' <span class="mut">✎</span></b><small>' + esc(sl.t ? fmtTime(sl.t) : T('pf_empty')) + '</small>' +
        (sl.t ? '<a class="btn" style="right:116px" data-prload="' + i + '">' + esc(T('pf_load')) + '</a>' : '') + '<a class="btn" data-prsave="' + i + '">' + esc(T('pf_save')) + '</a></div>';
    });
    var games = '';
    each(CALC_G, function (g) { games += '<a class="' + (CALC === g[0] ? 'on' : '') + '" data-calc="' + g[0] + '">' + g[1] + '</a>'; });
    var st = '';
    var lastG = '';
    each(STYLES, function (x) {
      if (x[4] !== lastG) { lastG = x[4]; st += '<div class="stg">' + esc(T('sg_' + lastG)) + '</div>'; }
      st += '<div class="rowb sty"><b>' + esc(T(x[1])) + '</b><small>' + esc(T(x[2])) + '</small><a class="btn" data-style="' + x[0] + '">' + esc(T('st_apply')) + '</a></div>';
    });
    return '<div class="pane l"><div class="ph2">' + esc(T('pf_title')) + '</div>' + pr +
      '<div class="ph2 m">' + esc(T('cc_title')) + '</div>' +
      '<div class="fr"><div class="lb">' + esc(T('cc_game')) + '</div><div class="ct2 seg">' + games + '</div></div>' +
      '<div class="fr"><div class="lb">' + esc(T('cc_in')) + '</div><div class="ct2 code"><input id="calcIn" value="' + esc(CALC_V) + '"><span class="ccres" id="calcOut">' + calcOut() + '</span>' +
      '<a class="btn b2" data-act="calcapply">' + esc(T('x_apply')) + '</a></div></div>' +
      '<div class="ph2 m">' + esc(T('cf_title')) + '</div><div class="mut" style="font-size:12px;margin-bottom:8px">' + esc(T('cf_note')) + '</div>' +
      '<a class="btn" data-act="cfgshare" style="margin:0 8px 0 0">' + esc(T('cf_get')) + '</a><a class="btn" data-act="cfgload" style="margin:0 8px 0 0">' + esc(T('cf_load')) + '</a><a class="btn red" data-act="cfgtop">\u2605 ' + esc(T('ct_title')) + '</a>' +
      '<div id="cfgOut"></div></div>' +
      '<div class="pane r"><div class="ph2">' + esc(T('st_title')) + '</div>' + st + '</div>';
  },
  demo: function () {                            // F10 videolari: sifat, ko'rsatma, "Mening videolarim" (ochish / o'chirish / papka - launcher bajaradi)
    var vq = OPTS && OPTS.vq || 'mid', vqs = '', rows = '', vids = OPTS && OPTS.vids || [];
    var vtg = function (k, on, label, sub) { return '<div class="fr w"><div class="lb">' + esc(T(label)) + '<small>' + esc(T(sub)) + '</small></div><div class="tg' + (on ? ' on' : '') + '" data-vopt="' + k + '"><i></i></div></div>'; };
    var vf = OPTS && OPTS.vf || 'src', vfs = '';   // video formati: yozish tugagach launcher o'zi o'tkazadi
    each([['src', 'vf_src'], ['43', 'vf_43'], ['169', 'vf_169'], ['916', 'vf_916'], ['11', 'vf_11']], function (o) {
      vfs += '<a class="' + (vf === o[0] ? 'on' : '') + '" data-ovf="' + o[0] + '"><i class="vfi vf' + o[0] + '"></i>' + esc(T(o[1])) + '</a>';
    });
    each([['hi', 'vq_hi', 'vq_hi2'], ['mid', 'vq_mid', 'vq_mid2'], ['low', 'vq_low', 'vq_low2']], function (o) {
      vqs += '<a class="' + (vq === o[0] ? 'on' : '') + '" data-ovq="' + o[0] + '">' + esc(T(o[1])) + '<small>' + esc(T(o[2])) + '</small></a>';
    });
    each(vids, function (v) {
      if ((v.sh === 'q' || v.sh === 'c' || /^\d+$/.test(v.sh || '')) && (!v.sht || now() / 1000 - v.sht > 1800 || ((v.mb | 0) >= 60 && !verGE(VERSION, '1.0.94')))) v.sh = '';   // 30 daqiqa siljimagan yuklash - qayta ulashish mumkin
      var m = /^xc_(\d{4})(\d\d)(\d\d)_(\d\d)(\d\d)(\d\d)$/.exec(v.n || ''); if (!m) return;
      var t = new Date(+m[1], m[2] - 1, +m[3], +m[4], +m[5], +m[6]).getTime(), sec = v.sec | 0;
      var info = [(v.mb | 0) + ' MB'];
      if (sec) info.push(Math.floor(sec / 60) + ':' + pad(sec % 60));
      if (v.q) info.push(T('vq_' + v.q));
      /* jonli ko'rinish: launcher yuborgan 8 kadr ketma-ket almashadi (yo'q bo'lsa - qora oyna) */
      var thu = PCID && DB.pck ? 'xc_api.php?a=vth&d=' + encodeURIComponent(PCID) + '&k=' + encodeURIComponent(DB.pck) + '&n=' + encodeURIComponent(v.n) : '';
      rows += '<div class="dmr th"><a class="vth" data-vopen="' + esc(v.n) + '"' + (thu ? ' style="background-image:url(\'' + thu + '\')"' : '') + '></a><b>' + esc(m[4] + ':' + m[5] + ' · ' + m[3] + '.' + m[2] + '.' + m[1]) + '</b><small>' + esc(info.join(' · ')) + '</small>' +
        '<a class="btn vdel" data-vdel="' + esc(v.n) + '" title="' + esc(T('vd_del')) + '">' + ico('trash') + '</a>' +
        (v.sh && /^[a-f0-9]{12}$/.test(v.sh) ? '<a class="btn vsh on" data-vlink="' + esc(v.sh) + '" title="' + esc(T('vs_copy')) + '">' + ico('link') + '</a>' :
          v.sh === 'q' || v.sh === 'c' || /^\d+$/.test(v.sh || '') ? '<span class="btn vsh wait" title="' + esc(T(v.sh === 'c' ? 'vs_comp' : 'vs_wait')) + '">' + (v.sh === 'q' ? '\u2026' : v.sh === 'c' ? '\u27f3' : v.sh + '%') + '</span>' :
          '<a class="btn vsh' + (v.sh === 'x' || v.sh === 'l' ? ' err' : '') + '" data-vshare="' + esc(v.n) + '" data-vmb="' + (v.mb | 0) + '" data-vsh="' + esc(v.sh || '') + '" title="' + esc(T(v.sh === 'l' ? 'vs_long' : v.sh === 'x' ? 'vs_fail' : 'vs_share')) + '">' + ico('share') + '</a>') +
        '<a class="btn vcut" data-vtrim="' + esc(v.n) + '" data-vsec="' + sec + '" title="' + esc(T('vd_trim')) + '">' + ico('cut') + '</a>' +
        '<a class="btn red" data-vopen="' + esc(v.n) + '">' + ico('play') + ' ' + esc(T('vd_open')) + '</a></div>';
    });
    return '<div class="pane l"><div class="f10box big2"><b>' + esc(T('f10_t')) + '</b>' + esc(T('f10_1')) + '<br>' + esc(T('f10_2')) + '<br>' + esc(T('f10_3')) + '<br>' + esc(T('f10_4')) + '</div>' +
      '<div class="ph2 m">' + esc(T('vq_title')) + '</div><div class="big vqb">' + vqs + '</div>' +
      '<div class="ph2 m">' + esc(T('vf_title')) + '</div><div class="vfb">' + vfs + '</div><div class="mut" style="font-size:12px;margin:-2px 0 8px">' + esc(T('vf_note')) + '</div>' +
      vtg('mic', OPTS && OPTS.mic, 'vb_mic', 'vb_mic2') + vtg('gsum', DB.gsum !== 0, 'gs_tg', 'gs_tg2') + '</div>' +
      '<div class="pane r"><div class="ph2">' + esc(T('vd_title')) + ' <a class="btn vfold" data-vfold="1">' + ico('folder') + ' ' + esc(T('vd_folder')) + '</a></div>' +
      '<div class="dml dml2' + (OPTS && OPTS.f11 && OPTS.f11.length ? ' sm' : '') + '">' + (rows || '<div class="empty">' + esc(T(PCID ? 'vd_none' : 'sy_nolaunch')) + '</div>') + '</div>' +
      '<div class="mut" style="font-size:12px;margin-top:8px">' + esc(T('vd_note')) + '</div>' + shotsBox() + '</div>';
  },
  cont: function () {                             // Kontent: spray, skrinshotlar, mavzu, paketlar
    if (PACKS === null) loadPacks();
    var th = '';
    each(THEMES, function (x) { th += '<a class="' + ((DB.theme || 'red') === x[0] ? 'on' : '') + '" data-theme="' + x[0] + '" style="background:hsl(' + x[1] + ',85%,58%)" title="' + esc(T('th_' + x[0])) + '"></a>'; });
    var pk = '';
    each(PACKS || [], function (x) {
      var on = (',' + (OPTS.packs || '') + ',').indexOf(',' + x.id + ',') >= 0;
      pk += '<div class="fr w"><div class="lb">' + esc(x.name) + '<small>' + esc((x.desc ? x.desc + ' · ' : '') + (Math.round(x.size / 104857.6) / 10) + ' MB') + '</small></div><div class="tg' + (on ? ' on' : '') + '" data-pack="' + esc(x.id) + '"><i></i></div></div>';
    });
    var nol = PCID ? '' : '<div class="chk bad">' + esc(T('sy_nolaunch')) + '</div>';
    return '<div class="pane l"><div class="ph2">' + esc(T('sp_title')) + '</div>' + nol +
      // spray hammada bir xil - X CLIENT logotipi (XCLauncher.exe har ochilishda o'zi qo'yadi)
      '<div class="spr"><div class="sprv"><img src="spray_logo.png" alt=""></div><div class="mut">' + esc(T('sp_fixed')) + '</div></div>' +
      '<div class="ph2 m">' + esc(T('sh_title')) + '</div>' +
      '<div class="fr w"><div class="lb">' + esc(T('sh_up')) + '<small>' + esc(T('sh_up2')) + '</small></div><div class="tg' + (OPTS.shots ? ' on' : '') + '" data-otg="shots"><i></i></div></div>' +
      '<a class="btn" style="margin:0" data-act="gallery">' + esc(T('sh_open')) + '</a>' +
      '<div class="ph2 m">' + esc(T('th_title')) + '</div><div class="ths">' + th + '</div></div>' +
      '<div class="pane r"><div class="ph2">' + esc(T('pk_title')) + '</div>' +
      (PACKS && !PACKS.length ? '<div class="empty">' + esc(T('pk_none')) + '</div>' : (PACKS ? pk : '<div class="empty">' + esc(T('loading')) + '</div>')) +
      '<div class="mut" style="font-size:12px;margin-top:10px">' + esc(T('pk_note')) + '</div></div>';
  },
  pro: function () {                              // Kengaytirilgan: grafika, internet, qurol, ekran
    return '<div class="pane l"><div class="ph2">' + esc(T('pr_gfx')) + '</div>' +
      tg('detail', 'pr_detail') + tg('shadows', 'pr_shadows') +
      '<div class="ph2 m">' + esc(T('pr_fps')) + '</div>' +
      '<div class="rowb"><b>' + esc(T('pr_cfg')) + '</b><small>' + esc(T('pr_cfg2')) + '</small><a class="btn red" data-act="procfg">' + esc(T('pr_cfgb')) + '</a></div>' +
      '<div class="rowb"><b>' + esc(T('pr_fps')) + '</b><small>' + esc(T('pr_fps2')) + '</small><a class="btn red" data-act="fpsmode">' + esc(T('pr_fpsb')) + '</a></div>' +
      '<div class="rowb"><b>' + esc(T('pr_ul')) + '</b><small>' + esc(T('pr_ul2')) + '</small>' + (E.ultra ? '<a class="btn" data-act="ultraoff">' + esc(T('pr_uloff')) + '</a>' : '<a class="btn red" data-act="ultramode">' + esc(T('pr_fpsb')) + '</a>') + '</div>' +
      '<div class="rowb"><b>' + esc(T('hw_title')) + ' <span class="gr">' + esc(HW ? T('hw_' + hwClass()) : '') + '</span></b><small>' + esc(hwText()) + '</small>' +
      (HW ? '<a class="btn" data-act="hwauto">' + esc(T('hw_auto')) + '</a>' : '') + '</div>' +
      '<div class="fr w"><div class="lb">' + esc(T('pr_prio')) + '<small>' + esc(T('pr_prio2')) + '</small></div><div class="tg' + (OPTS.prio ? ' on' : '') + '" data-otg="prio"><i></i></div></div>' +
      tunePane() + '</div>' +
      '<div class="pane r"><div class="ph2">' + esc(T('pr_net')) + '</div>' +
      '<div class="rowb"><b>' + esc(T('nt_title')) + '</b><small>' + esc(NETT_RUN ? T('nt_run') : NETT ? T('nt_res').replace('{p}', NETT.best).replace('{j}', NETT.jit).replace('{l}', NETT.loss) + ' \u2192 ' + T('n_' + NETT.rec.net) : T('nt_desc')) + '</small>' +
        (NETT && !NETT_RUN ? '<a class="btn red" style="right:110px" data-act="netapply">' + esc(T('x_apply')) + '</a>' : '') + '<a class="btn" data-act="nettest">' + esc(T('nt_btn')) + '</a></div>' +
      seg('interp', 'pr_interp', [[0.01, '0.01'], [0.05, '0.05'], [0.1, '0.1']]) +
      '<div class="mut" style="margin:-6px 0 8px;font-size:12px">' + esc(T('pr_interp2')) + '</div>' +
      tg('lw', 'pr_lw', 'pr_lw2') + tg('lc', 'pr_lc') +
      '<div class="ph2 m">' + esc(T('pr_wpn')) + '</div>' + seg('bob', 'pr_bob', [[0.01, 'pr_bob1'], [0, 'pr_bob0']]) +
      '<div class="ph2 m">' + esc(T('pr_scr')) + '</div>' + sl('saytm', 'pr_say', 1, 20, 1) +
      seg('ngpos', 'pr_ngpos', [[1, 'pr_ng1'], [2, 'pr_ng2'], [3, 'pr_ng3']]) + '</div>';
  },
  hud: function () {
    var sub = '';
    each([['main', 'hx_main'], ['snip', 'hx_snip'], ['wpn', 'hx_wpn'], ['cam', 'hx_cam'], ['radar', 'hx_radar'], ['misc', 'hx_misc']], function (o) { sub += '<a class="' + (HSUB === o[0] ? 'on' : '') + '" data-hsub="' + o[0] + '">' + esc(T(o[1])) + '</a>'; });
    sub = '<div class="hsub">' + sub + '</div>';
    if (HSUB === 'snip') {
      return sub + '<div class="pane l hp"><div class="ph2">' + esc(T('hx_snip')) + '</div><div id="xPrev" class="big"><canvas id="xScope" width="524" height="220"></canvas></div>' +
        '<div class="hnote">' + esc(T('hx_zoom')) + '</div></div>' +
        '<div class="pane r hp"><div class="ph2">&nbsp;</div>' + sl('zoom', 'mo_zoom', 0.1, 3, 0.05) + sl('sens', 'mo_sens', 0.1, 10, 0.05) + '</div>';
    }
    if (HSUB === 'wpn') {
      return sub + '<div class="pane l hp"><div class="ph2">' + esc(T('hw_pos')) + '</div>' +
        sl('vmx', 'hw_x', -10, 10, 0.5) + sl('vmy', 'hw_y', -10, 10, 0.5) + sl('vmz', 'hw_z', -10, 10, 0.5) + sl('vmfov', 'v_vm', 70, 100, 1) +
        tg('vmshift', 'hw_shift', 'hw_shift2') + '</div>' +
        '<div class="pane r hp"><div class="ph2">' + esc(T('hw_lagt')) + '</div>' +
        seg('lagst', 'hw_lag', [[0, 'hw_lag0'], [1, 'hw_lag1'], [2, 'hw_lag2']]) + sl('lagsc', 'hw_lagsc', 0, 3, 0.1) + sl('lagsp', 'hw_lagsp', 1, 20, 0.5) +
        seg('bob', 'pr_bob', [[0.01, 'pr_bob1'], [0, 'pr_bob0']]) + tg('camint', 'hw_cam', 'hw_cam2') +
        '<div class="hfoot"><span class="mut">' + esc(T('hw_note')) + '</span><a class="btn" data-act="vmdef">' + esc(T('hx_std')) + '</a></div></div>';
    }
    if (HSUB === 'cam') {
      return sub + '<div class="pane l hp"><div class="ph2">' + esc(T('hw_anim')) + '</div>' +
        seg('bobst', 'hw_bob', [[0, 'hw_bob0'], [1, 'hw_bob1'], [2, 'hw_bob2']]) +
        (Number(E.bobst) === 2 ? sl('bobv', 'hc_bobv', 0, 1, 0.01) + sl('bobl', 'hc_bobl', 0, 1, 0.01) + sl('boblow', 'hc_boblow', 0, 20, 0.5) :
          '<div class="mut" style="margin:-4px 0 10px;font-size:12px">' + esc(T('hc_csgo')) + '</div>') +
        tg('bobcam', 'hc_bobcam', 'hc_bobcam2') + '</div>' +
        '<div class="pane r hp"><div class="ph2">' + esc(T('hc_title')) + '</div>' +
        sl('roll', 'hc_roll', 0, 5, 0.5) + sl('rollspd', 'hc_rollspd', 50, 400, 10) + sl('fovlerp', 'hc_fov', 0, 0.5, 0.05) + sl('camsc', 'hc_camsc', 0, 2, 0.1) +
        '<div class="mut" style="font-size:12px;margin-top:4px">' + esc(T('hc_roll2')) + '<br>' + esc(T('hc_fov2')) + '</div>' +
        '<div class="hfoot"><span class="mut">' + esc(T('hw_note')) + '</span><a class="btn" data-act="camdef">' + esc(T('hx_std')) + '</a></div></div>';
    }
    if (HSUB === 'radar' && !radarNC()) {          // bu NextClient versiyasida xaritali radar (hud_radar_*) yo'q - faqat CS 1.6 radari
      var rk = '';
      each(verGE(VERSION, '1.0.102') ? [[3, 'rk3'], [1, 'rk1'], [2, 'rk2'], [4, 'rk4'], [5, 'rk5'], [6, 'rk6'], [0, 'rk0']] : [[1, 'rk1'], [2, 'rk2'], [0, 'rk0']], function (o) { rk += '<a class="rkc' + ((OPTS.rsk == null ? 3 : OPTS.rsk) === o[0] ? ' on' : '') + '" data-orsk="' + o[0] + '"><i style="background-image:url(radar_prev.jpg);background-position:-' + (o[0] * 112) + 'px 0"></i><span>' + esc(T(o[1])) + '</span></a>'; });   // 4-6: launcher 1.0.102+; rasm - radar_prev.jpg (launcher chizadigan uslubning o'zi)
      return sub + '<div class="pane l hp"><div class="ph2">' + esc(T('hx_radar')) + '</div>' +
        '<div class="lb" style="margin-bottom:10px">' + esc(T('rk_title')) + '</div><div class="rkg">' + rk + '</div>' +
        '<div class="mut" style="font-size:12px;margin-top:10px">' + esc(T('rk_note')) + '</div>' +
        '<div class="mut" style="font-size:12px;margin-top:6px">' + esc(T('h_rnone')) + '</div></div>';
    }
    if (HSUB === 'radar') {
      return sub + '<div class="pane l hp"><div class="ph2">' + esc(T('hx_radar')) + '</div>' +
        seg('rmode', 'h_rmode', [[1, 'h_rmode1'], [0, 'h_rmode0']]) +
        sl('rscale', 'h_rscale', 50, 300, 5, null, '%') + sl('rmap', 'h_rmap', 0.25, 3, 0.05) + sl('ropac', 'h_ropac', 0, 100, 5, null, '%') +
        seg('rbg', 'h_rbg', [[0, 'h_rbg0'], [1, 'h_rbg1']]) + tg('rround', 'h_rround') + '</div>' +
        '<div class="pane r hp"><div class="ph2">&nbsp;</div>' +
        tg('rrot', 'h_rrot') + tg('rfull', 'h_rfull') + tg('rtracks', 'h_rtracks') + tg('rallies', 'h_rallies', 'h_rallies2') +
        tg('rnames', 'h_rnames') + sl('rns', 'h_rns', 0.6, 2, 0.1) + tg('rhp', 'h_rhp') + sl('rhs', 'h_rhs', 0.3, 4, 0.1) +
        '<div class="hfoot"><span class="mut">' + esc(T('h_cs2b')) + '</span><a class="btn" data-act="rcs2">' + esc(T('h_cs2')) + '</a></div></div>';
    }
    if (HSUB === 'misc') {
      var hz = '';
      each([[100, '100%'], [150, '150%'], [200, '200%']], function (o) { hz += '<a class="' + ((OPTS.hud || 100) === o[0] ? 'on' : '') + '" data-ohud="' + o[0] + '">' + o[1] + '</a>'; });
      return sub + '<div class="pane l hp"><div class="ph2">' + esc(T('h_size')) + '</div>' +
        '<div class="fr"><div class="lb">' + esc(T('h_size2')) + '</div><div class="ct2 seg">' + hz + '</div></div>' +
        '<div class="mut" style="margin:-6px 0 10px;font-size:12px">' + esc(PCID ? T('h_size3') : T('sy_nolaunch')) + '</div>' +
        '<div class="ph2 m">' + esc(T('hx_kill')) + '</div>' + sl('dmax', 'h_kills', 3, 10, 1) + sl('dtime', 'h_dtime', 2, 15, 1, null, 's') + tg('hs', 'h_hs') + '</div>' +
        '<div class="pane r hp"><div class="ph2">' + esc(T('h_title')) + '</div>' + tg('netg', 'h_net', 'h_net2') + seg('ngpos', 'h_ngpos', [[3, 'h_ng3'], [2, 'h_ng2'], [1, 'h_ng1']]) + tg('cid', 'h_cid') + tg('nover', 'h_draw') + '</div>';
    }
    var pal = ['255 59 59', '50 250 50', '0 230 255', '255 210 60', '255 80 220', '255 255 255'];
    if (pal.indexOf(E.xc) < 0 && /^\d+ \d+ \d+$/.test(E.xc)) pal.push(E.xc);
    var cols = '';
    each(pal, function (c) { cols += '<a class="' + (E.xc === c ? 'on' : '') + '" data-seg="xc" data-v="' + c + '" style="background:rgb(' + c.split(' ').join(',') + ')"></a>'; });
    var si = Math.max(0, SZ.indexOf(E.xs)), xt = Number(E.xt);
    var off = function (key, label, min, max) {
      return XSUP[key] ? sl(key, label, min, max, 1) : '';          // NextClient'da bo'lsagina ko'rsatamiz (hozircha yo'q)
    };
    var ck = function (k, label, on, dis) {
      return '<a class="ck' + (on ? ' on' : '') + (dis ? ' dis' : '') + '"' + (dis ? '' : ' data-xchk="' + k + '"') + '><i>' + (on ? '✓' : '') + '</i>' + esc(T(label)) + '</a>';
    };
    return sub + '<div class="pane l hp"><div class="ph2">' + esc(T('x_title')) + '</div>' +
      '<div id="xPrev" class="big"><canvas id="xCan" width="524" height="220"></canvas></div>' +
      '<div class="fr" style="margin-top:14px"><div class="lb">' + esc(T('hx_style')) + '</div><div class="ct2"><a class="dd wide" data-dd="xpre"><span>' + esc(ddLabel('xpre')) + '</span><i>▾</i></a></div></div>' +
      '<div class="fr"><div class="lb">' + esc(T('x_color')) + '</div><div class="ct2 sw">' + cols + '<a class="btn pick" data-act="xpick">' + esc(T('hx_pick')) + '</a></div></div>' +
      '<div class="fr cw"><div class="lb">' + esc(T('x_code')) + '</div><div class="ct2 code"><input id="xCode" value="' + esc(xcode(E)) + '"><a class="btn" data-act="xcopy">' + esc(T('x_copy')) + '</a><a class="btn b2" data-act="xcode">' + esc(T('x_apply')) + '</a></div></div>' + xGallery() + '</div>' +
      '<div class="pane r hp"><div class="ph2">&nbsp;</div>' +
      '<div class="fr"><div class="lb">' + esc(T('x_size')) + '</div><div class="ct2"><a class="dd xsz" data-dd="xsz"><span>' + esc(ddLabel('xsz')) + '</span><i>▾</i></a>' +
      '<div class="sl sl2"><input type="range" min="0" max="3" step="1" value="' + si + '" data-xsz="1"><div class="vv" id="vv_xsz">x' + (si + 1) + '</div></div></div></div>' +
      off('xthick', 'hx_thick', 1, 5) + off('xgap', 'hx_gap', 0, 10) +
      '<div class="fr"><div class="lb">' + esc(T('hx_opaq')) + '</div><div class="ct2"><div class="sl"><input type="range" min="0" max="1" step="1" value="' + (E.xtr ? 0 : 1) + '" data-xop="1"><div class="vv" id="vv_xop">' + (E.xtr ? '60%' : '100%') + '</div></div></div></div>' +
      off('xout', 'hx_outl', 0, 3) +
      '<div class="cks">' + ck('dot', 'hx_dot', xt === 3) + ck('t', 'hx_t', xt === 1) + ck('circle', 'hx_circ', xt === 2) + '</div>' +
      '<div class="hfoot"><span class="mut">' + (XSUP.xthick && XSUP.xgap && XSUP.xout ? '' : esc(T('hx_na'))) + '</span><a class="btn" data-act="xdef">' + esc(T('hx_std')) + '</a><a class="btn xt" data-act="xtest">' + esc(T('hx_test')) + '</a></div></div>';
  },
  account: function () {
    if (!ME) {
      return '<div class="pane full" style="text-align:center;padding-top:110px"><div class="prof"><div class="bigav">?</div><h2>' + esc(T('a_none')) + '</h2>' +
        '<div class="id" style="margin:10px 0 24px">' + esc(T('a_none2')) + '</div><a class="btn red" style="height:44px;line-height:42px;padding:0 30px" data-act="login">' + esc(T('a_login')) + '</a></div></div>';
    }
    var last = ME.cloudt ? (now() / 1000 - ME.cloudt < 120 ? T('a_now') : fmtTime(ME.cloudt * 1000)) : T('a_never');
    return '<div class="pane l"><div class="ph2">' + esc(T('a_profile')) + '</div><div class="prof"><div class="bigav' + frameCls(ME) + '" style="' + avStyle(ME) + '">' + avInner(ME) + '<a class="avcam" data-act="avpick">' + esc(T('a_photo')) + '</a></div>' +
      '<h2>' + esc(ME.name) + '</h2><div class="id">ID: ' + esc(ME.id) + ' \u00b7 ' + esc(T('lvl').replace('{n}', ME.level)) + '</div>' +
      '<div class="xpw"><i style="width:' + Math.round(ME.lvlxp * 100 / ME.lvlmax) + '%"></i></div><div class="xpt">' + ME.lvlxp + ' / ' + ME.lvlmax + ' XP</div>' +
      '<div class="avcols">' + avColors() + '</div>' +
      '<a class="btn" data-act="rename" style="margin:0 6px 0 0">' + esc(T('a_rename')) + '</a><a class="btn" data-act="avpick" style="margin:0 6px 0 0">' + esc(T('a_photo')) + '</a>' +
      (ME.av ? '<a class="btn out" data-act="avdel" style="margin:0">' + esc(T('a_photodel')) + '</a>' : '') + '</div>' +
      (ME.vip ? '<div class="vipbox"><b>' + esc(T('a_vip')) + '</b><span>' + esc(T('a_vip2')) + '</span></div>' : '') +
      statBox(ME.st) + achBadges(ME.ach) + '<a class="btn" data-act="stats" style="margin:4px 6px 0 0">' + esc(T('ks_more')) + '</a><a class="btn" data-act="ref" style="margin:4px 6px 0 0">\u2709 ' + esc(T('rf_btn')) + '</a><a class="btn" data-frprof="' + esc(ME.login) + '" style="margin:4px 6px 0 0">' + ico('user') + ' ' + esc(T('fp_mine')) + '</a><a class="btn red" data-act="chests" style="margin:4px 0 0">' + esc(T('ch_btn2').replace('{n}', ME.chests || 0)) + '</a></div>' +
      '<div class="pane r"><div class="ph2">' + esc(T('a_sec')) + '</div>' +
      '<div class="rowb"><b>' + esc(T('a_email')) + '</b><small>' + esc(ME.email || '\u2014') + '</small><a class="btn" data-act="email">' + esc(T('a_change')) + '</a></div>' +
      '<div class="rowb"><b>' + esc(T('a_pass')) + '</b><small>' + esc(T('a_pw_ago').replace('{d}', daysAgo(ME.pwchanged))) + '</small><a class="btn" data-act="passwd">' + esc(T('a_change')) + '</a></div>' +
      '<div class="rowb"><b>Telegram</b><small>' + esc(T(ME.tglinked ? 'tg_on' : 'tg_off')) + '</small><a class="btn" data-act="tglink">' + esc(T(ME.tglinked ? 'tg_re' : 'tg_link')) + '</a></div>' +
      '<div class="ph2 m">' + esc(T('a_cloud')) + '</div>' +
      '<div class="fr w"><div class="lb">' + esc(T('a_auto')) + '<small>' + esc(T('a_auto2')) + '</small></div><div class="tg' + (DB.autosave ? ' on' : '') + '" data-dbtg="autosave"><i></i></div></div>' +
      '<div style="margin:6px 0 12px;font-size:14px">' + esc(T('a_last')) + '<span class="gr">' + esc(last) + (ME.cloudt ? ' \u2713' : '') + '</span> \u00b7 ' + esc(T('a_pcs').replace('{n}', ME.devices || 1)) + '</div>' +
      '<a class="btn" style="margin:0 8px 0 0" data-act="cloudsave">' + esc(T('a_savenow')) + '</a><a class="btn" style="margin:0" data-act="cloudget">' + esc(T('a_restore')) + '</a>' +
      '<a class="btn out" style="float:right;margin:0" data-act="logout">' + esc(T('a_logout')) + '</a></div>';
  },
  system: function () {
    var langs = '';
    each(LANGS, function (o) {
      langs += '<a class="' + (CUR_LANG === o[0] ? 'on' : '') + '" data-lang="' + o[0] + '">' + langBox(o) + esc(o[2]) + (CUR_LANG === o[0] ? '<i>\u2713</i>' : '') + '</a>';
    });
    var chk = '';
    if (LAST_CHECK) {
      chk = '<div class="chk ' + (LAST_CHECK.bad.length ? 'bad' : 'ok') + '">' + esc((LAST_CHECK.bad.length ? T('chk_bad') : T('chk_ok')).replace('{n}', LAST_CHECK.bad.length || LAST_CHECK.ok));
      each(LAST_CHECK.bad, function (b) { chk += '<div>' + esc(b) + '</div>'; });
      chk += '</div>';
    }
    var otg = function (k, label, sub) {
      return '<div class="fr w"><div class="lb">' + esc(T(label)) + (sub ? '<small>' + esc(T(sub)) + '</small>' : '') + '</div><div class="tg' + (OPTS[k] ? ' on' : '') + '" data-otg="' + k + '"><i></i></div></div>';
    };
    return '<div class="pane l"><div class="ph2">' + esc(T('sy_lang')) + '</div><div class="lng">' + langs + '</div>' +
      '<div class="ph2 m">' + esc(T('sy_up')) + '</div>' +
      '<div class="rowb"><b>' + esc(T('sy_ver')) + ' <span class="vbold">v' + esc(VERSION || '1.0') + '</span></b><small>' + esc(launcherOld() ? T('up_t').replace('{v}', VERSION).replace('{n}', LVER) : T('sy_new')) + '</small>' + (launcherOld() ? '<a class="btn red" data-act="updl">' + esc(T('up_h')) + '</a>' : '<span class="ok2">\u2713 ' + esc(T('sy_newb')) + '</span>') + '</div>' +
      otg('auto', 'sy_auto', 'sy_auto2') + otg('beta', 'sy_beta') + '</div>' +
      '<div class="pane r"><div class="ph2">' + esc(T('sy_start')) + '</div>' +
      otg('start', 'sy_win') +
      '<div class="fr w"><div class="lb">' + esc(T('sy_fx')) + '<small>' + esc(T('sy_fx2')) + '</small></div><div class="tg' + (DB.fx !== 0 && !FX.off ? ' on' : '') + '" data-dbtg="fx"><i></i></div></div>' +
      '<div class="fr w"><div class="lb">' + esc(T('sy_dnd')) + '<small>' + esc(T('sy_dnd2')) + '</small></div><div class="tg' + (DB.dnd ? ' on' : '') + '" data-dbtg="dnd"><i></i></div></div>' +
      '<div class="ph2 m">' + esc(T('lk_title')) + '</div>' +
      '<div class="lkr"><span>' + esc(T('lk_bg')) + '</span>' + (function () { var x = ''; for (var k in BGS) if (BGS.hasOwnProperty(k)) x += '<a class="bgc' + ((DB.bgs || 'def') === k ? ' on' : '') + '" data-bgs="' + k + '" style="background:' + (BGS[k] ? '-webkit-radial-gradient(center, circle cover, ' + BGS[k] + ')' : '-webkit-radial-gradient(center, circle cover, #3a0d14 0%, #1c0b10 30%, #0f0a0e 60%, #09070a 100%)') + '" title="' + esc(T('bg_' + k)) + '"></a>'; return x; })() + '</div>' +
      '<div class="lkr"><span>' + esc(T('lk_ptc')) + '</span>' + (function () { var x = ''; each(['spark', 'snow', 'none'], function (k) { x += '<a class="sgo' + ((DB.ptc || 'spark') === k ? ' on' : '') + '" data-ptc="' + k + '">' + esc(T('pt_' + k)) + '</a>'; }); return x; })() + '</div>' +
      '<div class="lkr"><span>' + esc(T('lk_fs')) + '</span>' + (function () { var x = ''; each([[1, '100%'], [1.1, '110%'], [1.2, '120%']], function (k) { x += '<a class="sgo' + ((DB.fs || 1) === k[0] ? ' on' : '') + '" data-fs="' + k[0] + '">' + k[1] + '</a>'; }); return x; })() + '</div>' +
      '<div class="fr w"><div class="lb">' + esc(T('lk_hol')) + '<small>' + esc(T('lk_hol2')) + '</small></div><div class="tg' + (DB.hol !== 0 ? ' on' : '') + '" data-dbtg="hol"><i></i></div></div>' +
      '<div class="ph2 m">' + esc(T('sy_srv')) + '</div>' +
      '<div class="rowb"><b>' + esc(T('sy_cache')) + '</b><small>' + esc(T('sy_cache2').replace('{n}', CACHE_MB)) + (OPTS.clean ? ' \u00b7 ' + esc(T('sy_pending')) : '') + '</small><a class="btn" data-act="cache">' + esc(T('sy_cacheb')) + '</a></div>' +
      '<div class="rowb"><b>' + esc(T('sy_files')) + '</b><small>' + esc(T('sy_files2')) + (OPTS.verify ? ' \u00b7 ' + esc(T('sy_pending')) : '') + '</small><a class="btn" data-act="verify">' + esc(T('sy_filesb')) + '</a></div>' +
      rowb('sy_chk', 'sy_chk2', 'check', 'sy_chkb') + chk +
      rowb('sy_rep', 'sy_rep2', 'report', 'sy_repb') + '</div>';
  }
};
function drawXhair() {
  var c = $('xCan'); if (!c || !c.getContext) return;
  var g = c.getContext('2d'), w = c.width, h = c.height, cx = Math.round(w / 2), cy = Math.round(h / 2);
  g.clearRect(0, 0, w, h);
  var p = String(E.xc).split(' ');
  g.fillStyle = 'rgba(' + p[0] + ',' + p[1] + ',' + p[2] + ',' + (E.xtr ? 0.6 : 1) + ')';
  var z = w > 300 ? 2 : 1, len = ({ extra_small: 4, small: 5, medium: 8, large: 11, auto: 11 }[E.xs] || 5) * z, gap = (E.xgap != null ? Number(E.xgap) : 3) * z, t = (Math.max(1, Number(E.xthick) || 1) + 1) * z, type = Number(E.xt);
  if (Number(E.xout) > 0) {                         // kontur: avval qora, har tomondan kattaroq
    var o = Number(E.xout) * z, col = g.fillStyle;
    g.fillStyle = 'rgba(0,0,0,0.85)';
    xShape(g, cx, cy, z, len, gap, t, type, o);
    g.fillStyle = col;
  }
  xShape(g, cx, cy, z, len, gap, t, type, 0);
}
function xShape(g, cx, cy, z, len, gap, t, type, o) {
  var h = Math.floor(t / 2), R = function (x, y, a, b) { g.fillRect(x - o, y - o, a + 2 * o, b + 2 * o); };
  if (type === 3) { R(cx - 2 * z, cy - 2 * z, 4 * z, 4 * z); return; }
  if (type === 2) { g.strokeStyle = g.fillStyle; g.lineWidth = t + 2 * o; g.beginPath(); g.arc(cx, cy, len + 2 * z, 0, Math.PI * 2); g.stroke(); R(cx - z, cy - z, 2 * z, 2 * z); return; }
  R(cx - gap - len, cy - h, len, t); R(cx + gap, cy - h, len, t); R(cx - h, cy + gap, t, len);
  if (type !== 1) R(cx - h, cy - gap - len, t, len);
}
function drawScope() {
  var c = $('xScope'); if (!c || !c.getContext) return;
  var g = c.getContext('2d'), w = c.width, h = c.height, cx = w / 2, cy = h / 2, r = h / 2 - 6;
  g.fillStyle = '#000'; g.fillRect(0, 0, w, h);
  g.save(); g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.clip(); g.clearRect(0, 0, w, h); g.restore();
  g.fillStyle = '#000'; g.fillRect(0, cy, w, 1); g.fillRect(cx, 0, 1, h);
}

/* ============================================================ tugmalar (bind) */
var ACTIONS = [
  ['+forward', 'Oldinga', '\u0412\u043f\u0435\u0440\u0451\u0434', 'w'], ['+back', 'Orqaga', '\u041d\u0430\u0437\u0430\u0434', 's'],
  ['+moveleft', 'Chapga', '\u0412\u043b\u0435\u0432\u043e', 'a'], ['+moveright', "O'ngga", '\u0412\u043f\u0440\u0430\u0432\u043e', 'd'],
  ['+jump', 'Sakrash', '\u041f\u0440\u044b\u0436\u043e\u043a', 'SPACE'], ['+duck', "O'tirish", '\u041f\u0440\u0438\u0441\u0435\u0441\u0442\u044c', 'CTRL'],
  ['+speed', 'Sekin yurish', '\u0418\u0434\u0442\u0438 \u0442\u0438\u0445\u043e', 'SHIFT'], ['+attack', 'Otish', '\u0410\u0442\u0430\u043a\u0430', 'MOUSE1'],
  ['+attack2', 'Ikkinchi hujum / pritsel', '\u0414\u043e\u043f. \u0430\u0442\u0430\u043a\u0430', 'MOUSE2'], ['+reload', "Qayta o'qlash", '\u041f\u0435\u0440\u0435\u0437\u0430\u0440\u044f\u0434\u043a\u0430', 'r'],
  ['+use', 'Ishlatish', '\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c', 'e'], ['drop', 'Qurolni tashlash', '\u0412\u044b\u0431\u0440\u043e\u0441\u0438\u0442\u044c', 'g'],
  ['lastinv', 'Oxirgi qurol', '\u041f\u0440\u0435\u0434. \u043e\u0440\u0443\u0436\u0438\u0435', 'q'], ['slot1', 'Asosiy qurol', '\u041e\u0441\u043d\u043e\u0432\u043d\u043e\u0435', '1'],
  ['slot2', 'Pistolet', '\u041f\u0438\u0441\u0442\u043e\u043b\u0435\u0442', '2'], ['slot3', 'Pichoq', '\u041d\u043e\u0436', '3'],
  ['slot4', 'Granatalar', '\u0413\u0440\u0430\u043d\u0430\u0442\u044b', '4'], ['slot5', 'C4 bomba', 'C4', '5'],
  ['buy', 'Sotib olish menyusi', '\u041c\u0435\u043d\u044e \u0437\u0430\u043a\u0443\u043f\u043a\u0438', 'b'], ['buyammo1', "Asosiy qurol o'qi", '\u041f\u0430\u0442\u0440\u043e\u043d\u044b (\u043e\u0441\u043d.)', ','],
  ['buyammo2', "Pistolet o'qi", '\u041f\u0430\u0442\u0440\u043e\u043d\u044b (\u043f\u0438\u0441\u0442.)', '.'], ['chooseteam', 'Jamoa tanlash', '\u0412\u044b\u0431\u043e\u0440 \u043a\u043e\u043c\u0430\u043d\u0434\u044b', 'm'],
  ['+showscores', 'Hisob jadvali', '\u0422\u0430\u0431\u043b\u0438\u0446\u0430 \u0441\u0447\u0451\u0442\u0430', 'TAB'], ['messagemode', 'Umumiy chat', '\u0427\u0430\u0442', 'y'],
  ['messagemode2', 'Jamoa chati', '\u0427\u0430\u0442 \u043a\u043e\u043c\u0430\u043d\u0434\u044b', 'u'], ['+voicerecord', 'Ovozli chat', '\u0413\u043e\u043b\u043e\u0441', 'k'],
  ['impulse 201', 'Spray', '\u0421\u043f\u0440\u0435\u0439', 't'], ['nightvision', "Tungi ko'rish", '\u041d\u043e\u0447\u043d\u043e\u0435 \u0432\u0438\u0434\u0435\u043d\u0438\u0435', 'n'],
  ['radio1', 'Radio buyruqlar', '\u0420\u0430\u0434\u0438\u043e', 'z'], ['snapshot', 'Skrinshot', '\u0421\u043a\u0440\u0438\u043d\u0448\u043e\u0442', 'F5'],
  // tayyor bindlar (tugmasi bo'sh - o'yinchi o'zi tanlaydi)
  ['+jumpthrow', 'Granatani sakrab otish (jumpthrow)', '\u041f\u0440\u044b\u0436\u043e\u043a + \u0431\u0440\u043e\u0441\u043e\u043a', ''],
  ['xc_qs', 'Tez almashtirish (AWP uchun)', '\u0411\u044b\u0441\u0442\u0440\u0430\u044f \u0441\u043c\u0435\u043d\u0430 (AWP)', ''],
  ['radio2', 'Radio 2', '\u0420\u0430\u0434\u0438\u043e 2', ''], ['radio3', 'Radio 3', '\u0420\u0430\u0434\u0438\u043e 3', ''],
  ['say gl hf', 'Chat: gl hf', '\u0427\u0430\u0442: gl hf', ''], ['say gg wp', 'Chat: gg wp', '\u0427\u0430\u0442: gg wp', ''],
  ['say_team Need backup!', 'Jamoaga: yordam kerak', '\u041a\u043e\u043c\u0430\u043d\u0434\u0435: \u043d\u0443\u0436\u043d\u0430 \u043f\u043e\u043c\u043e\u0449\u044c', ''],
  ['+xc_jd', 'Sakrab o\'tirish (jump + duck)', '\u041f\u0440\u044b\u0436\u043e\u043a \u0441 \u043f\u0440\u0438\u0441\u0435\u0434\u043e\u043c', ''],
  ['xc_he', 'HE granata', '\u0413\u0440\u0430\u043d\u0430\u0442\u0430 HE', ''],
  ['xc_fl', 'Flash granata', '\u0424\u043b\u0435\u0448\u043a\u0430', ''],
  ['xc_sm', 'Tutun granata', '\u0414\u044b\u043c\u043e\u0432\u0430\u044f \u0433\u0440\u0430\u043d\u0430\u0442\u0430', ''],
  ['xc_c4', 'C4 bombani tashlash', '\u0412\u044b\u0431\u0440\u043e\u0441\u0438\u0442\u044c C4', ''],
  ['xc_volup', 'Ovoz +', '\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c +', ''],
  ['xc_voldn', 'Ovoz -', '\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c -', ''],
  ['xc_vt', 'Ovozli chat (yoqish/o\'chirish)', '\u0413\u043e\u043b\u043e\u0441\u043e\u0432\u043e\u0439 \u0447\u0430\u0442 (\u0432\u043a\u043b/\u0432\u044b\u043a\u043b)', ''],
  ['xc_ng', 'net_graph + FPS (yoqish/o\'chirish)', 'net_graph + FPS (\u0432\u043a\u043b/\u0432\u044b\u043a\u043b)', ''],
  ['xc_awp', 'AWP rejimi: sezgirlik + pritsel almashtirish', '\u0420\u0435\u0436\u0438\u043c AWP: \u0447\u0443\u0432\u0441\u0442\u0432\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0441\u0442\u044c + \u043f\u0440\u0438\u0446\u0435\u043b', ''],
  ['xc_dm', 'Demo yozish (boshlash/to\'xtatish)', '\u0417\u0430\u043f\u0438\u0441\u044c \u0434\u0435\u043c\u043e (\u0441\u0442\u0430\u0440\u0442/\u0441\u0442\u043e\u043f)', ''],
  ['xc_b_rifle', 'Xarid: avtomat + o\'q', '\u0417\u0430\u043a\u0443\u043f\u043a\u0430: \u0430\u0432\u0442\u043e\u043c\u0430\u0442 + \u043f\u0430\u0442\u0440\u043e\u043d\u044b', ''],
  ['xc_b_awp', 'Xarid: AWP + o\'q', '\u0417\u0430\u043a\u0443\u043f\u043a\u0430: AWP + \u043f\u0430\u0442\u0440\u043e\u043d\u044b', ''],
  ['xc_b_pist', 'Xarid: Deagle + o\'q', '\u0417\u0430\u043a\u0443\u043f\u043a\u0430: Deagle + \u043f\u0430\u0442\u0440\u043e\u043d\u044b', ''],
  ['xc_b_full', 'Xarid: to\'liq (avtomat, zirh, granatalar)', '\u0417\u0430\u043a\u0443\u043f\u043a\u0430: \u043f\u043e\u043b\u043d\u0430\u044f (\u0430\u0432\u0442\u043e\u043c\u0430\u0442, \u0431\u0440\u043e\u043d\u044f, \u0433\u0440\u0430\u043d\u0430\u0442\u044b)', ''],
  ['coverme', 'Radio: Meni qopla', '\u0420\u0430\u0434\u0438\u043e: \u041f\u0440\u0438\u043a\u0440\u043e\u0439 \u043c\u0435\u043d\u044f', ''],
  ['go', 'Radio: Hujum!', '\u0420\u0430\u0434\u0438\u043e: \u0412\u043f\u0435\u0440\u0451\u0434!', ''],
  ['fallback', 'Radio: Orqaga!', '\u0420\u0430\u0434\u0438\u043e: \u041e\u0442\u0441\u0442\u0443\u043f\u0430\u0435\u043c!', ''],
  ['enemyspot', 'Radio: Dushman ko\'rindi', '\u0420\u0430\u0434\u0438\u043e: \u0412\u0440\u0430\u0433 \u0437\u0430\u043c\u0435\u0447\u0435\u043d', ''],
  ['needbackup', 'Radio: Yordam kerak', '\u0420\u0430\u0434\u0438\u043e: \u041d\u0443\u0436\u043d\u0430 \u043f\u043e\u043c\u043e\u0449\u044c', ''],
  ['sectorclear', 'Radio: Toza', '\u0420\u0430\u0434\u0438\u043e: \u0427\u0438\u0441\u0442\u043e', ''],
  ['roger', 'Radio: Tushunarli', '\u0420\u0430\u0434\u0438\u043e: \u041f\u043e\u043d\u044f\u043b', ''],
  ['say_team Bomb planted!', 'Jamoaga: bomba qo\'yildi', '\u041a\u043e\u043c\u0430\u043d\u0434\u0435: \u0431\u043e\u043c\u0431\u0430 \u0437\u0430\u043b\u043e\u0436\u0435\u043d\u0430', '']
];
var BINDS = {}, BINDS2 = {}, KEYWAIT = '', KEYSLOT = 1;   // BINDS2 - ikkinchi (qo'shimcha) tugma
function loadBinds() {
  BINDS = {};
  each(ACTIONS, function (a) { BINDS[a[0]] = a[3]; });
  if (DB.binds) for (var k in DB.binds) if (DB.binds.hasOwnProperty(k)) BINDS[k] = DB.binds[k];
  BINDS2 = DB.binds2 ? copy(DB.binds2) : {};
}
function binAliases() {                        // tayyor bindlar uchun aliaslar
  cmd('alias +jumpthrow "+jump; -attack"'); cmd('alias -jumpthrow "-jump"');
  cmd('alias xc_qs "slot3; wait; lastinv"');
  cmd('alias +xc_jd "+jump; +duck"'); cmd('alias -xc_jd "-jump; -duck"');
  cmd('alias xc_he "use weapon_hegrenade"'); cmd('alias xc_fl "use weapon_flashbang"'); cmd('alias xc_sm "use weapon_smokegrenade"');
  cmd('alias xc_c4 "use weapon_c4; drop"');
  cmd('alias xc_b_rifle "m4a1; ak47; primammo"'); cmd('alias xc_b_awp "awp; primammo"'); cmd('alias xc_b_pist "deagle; secammo"');
  cmd('alias xc_b_full "m4a1; ak47; primammo; vesthelm; defuser; hegren; flash; flash; sgren"');
  // yoqish/o'chirish (toggle) aliaslari
  cmd('alias xc_vt1 "+voicerecord; alias xc_vt xc_vt0"'); cmd('alias xc_vt0 "-voicerecord; alias xc_vt xc_vt1"'); cmd('alias xc_vt xc_vt1');
  cmd('alias xc_ng1 "net_graph 3; cl_showfps 1; alias xc_ng xc_ng0"'); cmd('alias xc_ng0 "net_graph 0; cl_showfps 0; alias xc_ng xc_ng1"'); cmd('alias xc_ng xc_ng1');
  cmd('alias xc_dm1 "record xc_quick; alias xc_dm xc_dm0"'); cmd('alias xc_dm0 "stop; alias xc_dm xc_dm1"'); cmd('alias xc_dm xc_dm1');
  // ovoz: 0.0 ... 1.0, 0.1 qadam
  for (var i = 0; i <= 10; i++) cmd('alias xc_v' + i + ' "volume ' + (i / 10) + '; alias xc_volup xc_v' + Math.min(10, i + 1) + '; alias xc_voldn xc_v' + Math.max(0, i - 1) + '"');
  var cv = Math.round(((S && S.vol) || 0.8) * 10); cmd('alias xc_volup xc_v' + Math.min(10, cv + 1)); cmd('alias xc_voldn xc_v' + Math.max(0, cv - 1));
  // AWP rejimi: asosiy (sezgirlik, skop, pritsel) <-> AWP (alohida sezgirlik, skop, pritsel)
  if (S) {
    // alias ichida qo'shtirnoq bo'lmaydi - pritsel rangi (3 so'z) almashtirilmaydi, faqat sezgirlik, skop va pritsel o'lchami
    var A = 'sensitivity ' + S.sens + '; zoom_sensitivity_ratio ' + S.zoom + '; cl_crosshair_size ' + S.xs;
    var W = 'sensitivity ' + (S.awps || S.sens) + '; zoom_sensitivity_ratio ' + S.awpz + '; cl_crosshair_size ' + S.awpxs;
    cmd('alias xc_awp1 "' + W + '; alias xc_awp xc_awp0"'); cmd('alias xc_awp0 "' + A + '; alias xc_awp xc_awp1"'); cmd('alias xc_awp xc_awp1');
  }
}
function applyBinds() {
  binAliases();
  for (var a in BINDS) if (BINDS.hasOwnProperty(a) && BINDS[a]) cmd('bind ' + q(BINDS[a]) + ' ' + q(a));
  for (var b in BINDS2) if (BINDS2.hasOwnProperty(b) && BINDS2[b]) cmd('bind ' + q(BINDS2[b]) + ' ' + q(b));
}
var KEYNAMES = { 8: 'BACKSPACE', 9: 'TAB', 13: 'ENTER', 16: 'SHIFT', 17: 'CTRL', 18: 'ALT', 19: 'PAUSE', 20: 'CAPSLOCK', 32: 'SPACE',
  33: 'PGUP', 34: 'PGDN', 35: 'END', 36: 'HOME', 37: 'LEFTARROW', 38: 'UPARROW', 39: 'RIGHTARROW', 40: 'DOWNARROW', 45: 'INS', 46: 'DEL',
  96: 'KP_INS', 97: 'KP_END', 98: 'KP_DOWNARROW', 99: 'KP_PGDN', 100: 'KP_LEFTARROW', 101: 'KP_5', 102: 'KP_RIGHTARROW', 103: 'KP_HOME',
  104: 'KP_UPARROW', 105: 'KP_PGUP', 106: '*', 107: 'KP_PLUS', 109: 'KP_MINUS', 110: 'KP_DEL', 111: 'KP_SLASH',
  186: 'SEMICOLON', 187: '=', 188: ',', 189: '-', 190: '.', 191: '/', 192: '`', 219: '[', 220: '\\', 221: ']', 222: "'" };
/* O'yin ichidagi brauzer (CEF1) tugmani turlicha beradi: ba'zan keyCode o'rniga harf kodi (e=101 - KP_5 bilan bir xil!),
 * rus/o'zbek kirill klaviaturasida - kirill harf. Avval keyIdentifier ("U+0045", "Shift"), keyin keyCode,
 * harflar esa qaysi tilda bo'lmasin - klaviaturadagi joyi bo'yicha lotinga aylantiriladi (Е -> t emas, aynan tugma) */
var KEYID = { Shift: 'SHIFT', Control: 'CTRL', Alt: 'ALT', Enter: 'ENTER', Tab: 'TAB', Up: 'UPARROW', Down: 'DOWNARROW', Left: 'LEFTARROW', Right: 'RIGHTARROW',
  PageUp: 'PGUP', PageDown: 'PGDN', Home: 'HOME', End: 'END', Insert: 'INS', Pause: 'PAUSE', CapsLock: 'CAPSLOCK' };
var CYR = { '\u0439': 'q', '\u0446': 'w', '\u0443': 'e', '\u043a': 'r', '\u0435': 't', '\u043d': 'y', '\u0433': 'u', '\u0448': 'i', '\u0449': 'o', '\u0437': 'p', '\u0445': '[', '\u044a': ']',
  '\u0444': 'a', '\u044b': 's', '\u0432': 'd', '\u0430': 'f', '\u043f': 'g', '\u0440': 'h', '\u043e': 'j', '\u043b': 'k', '\u0434': 'l', '\u0436': 'SEMICOLON', '\u044d': "'",
  '\u044f': 'z', '\u0447': 'x', '\u0441': 'c', '\u043c': 'v', '\u0438': 'b', '\u0442': 'n', '\u044c': 'm', '\u0431': ',', '\u044e': '.', '\u0451': '`',
  '\u045e': 'o', '\u049b': 'p', '\u0493': '[', '\u04b3': ']' };   // o'zbek kirill: ў қ ғ ҳ
function charKey(ch) {
  ch = String(ch || '').toLowerCase();
  if (!ch) return '';
  if (/^[a-z0-9]$/.test(ch)) return ch;
  if (CYR[ch]) return CYR[ch];
  var P = { ' ': 'SPACE', ';': 'SEMICOLON', '=': '=', ',': ',', '-': '-', '.': '.', '/': '/', '`': '`', '[': '[', '\\': '\\', ']': ']', "'": "'", '*': '*' };
  return P[ch] || '';
}
function keyName(e) {
  var id = e.keyIdentifier || e.key || '';
  if (KEYID[id]) return KEYID[id];
  if (/^F([1-9]|1[0-2])$/.test(id)) return id;
  var m = /^U\+([0-9A-Fa-f]{4})$/.exec(id), c = e.keyCode, num = (e.keyLocation || e.location) === 3;
  if (m) {
    var u = parseInt(m[1], 16);
    if (u === 8) return 'BACKSPACE'; if (u === 9) return 'TAB'; if (u === 27) return ''; if (u === 32) return 'SPACE'; if (u === 127) return 'DEL';
    if (!num) { var ck = charKey(String.fromCharCode(u)); if (ck) return ck; }
  }
  if (num && KEYNAMES[c] && c >= 96) return KEYNAMES[c];
  if (c >= 16 && c <= 18) return KEYNAMES[c];
  if ((c >= 48 && c <= 57) || (c >= 65 && c <= 90)) return String.fromCharCode(c).toLowerCase();
  if (c >= 97 && c <= 122 && !num && e.charCode === c) return String.fromCharCode(c);   // harf kodi kelgan (keyCode emas)
  if (KEYNAMES[c] && !(c >= 96 && c <= 111 && !num && (e.which === c && e.charCode))) return KEYNAMES[c];
  if (c >= 112 && c <= 123) return 'F' + (c - 111);
  if (c > 127) return charKey(String.fromCharCode(c));   // kirill harf kodi
  return '';
}
function keyLabel(k) { return /^[a-z]$/.test(k) ? k.toUpperCase() : k; }
function setBind(action, key, slot) {
  var M = slot === 2 ? BINDS2 : BINDS, old = M[action];
  // bitta tugma faqat bitta vazifada: boshqa joyda (1- yoki 2-ustunda) bo'lsa - o'sha yerdan olib tashlanadi
  for (var a in BINDS) if (BINDS.hasOwnProperty(a) && BINDS[a] === key && !(M === BINDS && a === action)) BINDS[a] = '';
  for (var b in BINDS2) if (BINDS2.hasOwnProperty(b) && BINDS2[b] === key && !(M === BINDS2 && b === action)) BINDS2[b] = '';
  M[action] = key;
  binAliases();
  if (old && old !== key) cmd('unbind ' + q(old));
  if (key) cmd('bind ' + q(key) + ' ' + q(action));
  DB.binds = BINDS; DB.binds2 = BINDS2; persist(); cloudSave();
}
function finishWait(key) {
  var a = KEYWAIT; KEYWAIT = '';
  if (key === 'BACKSPACE' && KEYSLOT === 2) { setBind(a, '', 2); }   // 2-tugmani tozalash
  else if (key) { setBind(a, key, KEYSLOT); toast(keyLabel(key) + ' \u2192 ' + a); }
  showSetTab('keys');
}

/* ============================================================ oynalar */
var curModal = '';
function openModal(id) {
  SFX_QUIET = true; closeModal(); SFX_QUIET = false;
  curModal = id; $(id).className = 'modal on';
  mdClass(true);
  sfx('open');
}
/* Birinchi o'yindan keyin bitta savol (o'rnatganlarning 70% i qaytmayapti - sababini bilish uchun). Javob admin > Fikrlar ga */
function firstAskLater(n) {
  if (CONNECTED || DEMO_PLAY || n > 30) return;
  if (curModal) return setTimeout(function () { firstAskLater(n + 1); }, 2000);   // o'yin xulosasi / ro'yxat taklifi yopilgach
  setTimeout(function () { if (CONNECTED || curModal) return firstAskLater(n + 1);
    var b = ''; each(['good', 'lag', 'crash', 'nosrv', 'hard'], function (k) { b += '<a class="btn fqb" data-fq="' + k + '">' + esc(T('fq_' + k)) + '</a>'; });
    openSide('fq', T('fq_t'), '<div class="fqw"><div class="mut" style="margin-bottom:12px">' + esc(T('fq_s')) + '</div>' + b + '</div>'); }, n ? 300 : 3000);
}
/* ---- O'yin paytidagi ping (lag sababi): har 45 s serverga so'rov - javob vaqti ~ ping. Yakunda saytga (perf) ---- */
var GP = null, GP_TM = 0, LASTPERF = null;
function gpStart(ip) {
  clearInterval(GP_TM); GP = { ip: ip, t: now(), p: [], lost: 0 };
  if (!hasMM()) return;
  GP_TM = setInterval(function () {
    if (!GP || CONNECTED !== GP.ip) return;
    var t0 = now(), done = false, pf = GP;
    var tm = setTimeout(function () { if (!done) { done = true; pf.lost++; } }, 3000);
    try { NC.matchmaking.getServerInfo(pf.ip).then(function () { if (done) return; done = true; clearTimeout(tm); pf.p.push(now() - t0); }, function () { if (!done) { done = true; clearTimeout(tm); pf.lost++; } }); } catch (e) {}
  }, 45000);
}
function gpEnd() {
  clearInterval(GP_TM); var pf = GP; GP = null;
  if (!pf) return;
  var dur = Math.round((now() - pf.t) / 1000), n = pf.p.length + pf.lost;
  if (dur < 90 || n < 2) return;
  var a = pf.p.slice().sort(function (x, y) { return x - y; }), pm = a.length ? a[Math.floor(a.length / 2)] : 0, px = a.length ? a[a.length - 1] : 0;
  LASTPERF = { pm: pm, l: Math.round(pf.lost * 100 / n) };
  api('gperf', { d: PCID || '', ip: pf.ip, pm: pm, px: px, l: LASTPERF.l, n: n, dur: dur, fps: S && S.fps || 0, lg: S && S.lowgfx ? 1 : 0, w: pcWeak() ? 1 : 0 }, function () {});
  if ((pm >= 120 || LASTPERF.l >= 10) && !DB.dnd) setTimeout(function () { if (!CONNECTED) toast(T(LASTPERF.l >= 10 ? 'pf_loss' : 'pf_ping').replace('{p}', pm).replace('{l}', LASTPERF.l), 9000); }, 12000);
}
/* launcher: oxirgi o'yinda CS kompyuter kuchiga tiralgan (bitta yadro 90%+) - yengillashtirishni bir marta taklif qilamiz */
function cpuHiOffer(ch, n) {
  if (n > 20 || DB.cpuhi === ch) return;
  if (CONNECTED || curModal) return setTimeout(function () { cpuHiOffer(ch, n + 1); }, 5000);
  DB.cpuhi = ch; persist(); lagFixPane(T('pf_cpu'), true);
}
/* "Lag / qotdi" javobi: bir bosishda tuzatish - tarmoq serverga moslanadi, FPS chegarasi va vsync, kuchsiz kompyuterda yengil grafika va menyu */
function lagFixPane(why, strong) {
  openSide('lagfix', T('lf_t'), '<div class="fqw">' + (why ? '<div class="chk bad" style="margin-bottom:10px">' + esc(why) + '</div>' : '') + '<div class="mut" style="margin-bottom:10px">' + esc(T('lf_s')) + '</div><ul class="lfl"><li>' + esc(T('lf_1')) + '</li><li>' + esc(T('lf_2')) + '</li><li>' + esc(T(pcWeak() ? 'lf_3w' : 'lf_3')) + '</li><li>' + esc(T('lf_4')) + '</li></ul>' +
    (strong ? '<div class="mut" style="margin:-6px 0 12px;color:#f5c518">' + esc(T('lf_5')) + '</div>' : '') +
    '<a class="btn red big" data-act="' + (strong ? 'lagfix2' : 'lagfix') + '">' + esc(T('lf_go')) + '</a></div>');
}
function lagFix(strong) {
  var w = pcWeak() || (HW && hwClass() === 'weak'), resTo = '';
  S.aimnet = 1; S.vsync = 0; S.dyn = 0; S.netg = 1;   // FPS va ping burchakda - o'yinchi lag nimadan ekanini ko'radi
  S.fps = Math.max(100, Math.min(Number(S.fps) || 100, 200));
  if (w) { S.lowgfx = 1; S.decals = 300; DB.fx = 0; sparks(); }
  /* launcher o'lchadi: o'yin protsessorni to'la band qilgan (FPS kompyuterga tiralgan) - chuqur yengillashtirish: effektlarsiz rejim,
   * detal teksturalar, soyalar, HD modellar o'chadi; katta ekranda o'lcham 1280x720 (16:9) yoki 1024x768 - ichki videokartada FPS ancha oshadi */
  if (strong) {
    S.ultra = 1; S.detail = 0; S.shadows = 0; S.hdm = 0; S.hdmx = 1; S.lowgfx = 1; S.fps = 100;
    var m = /^(\d+)x(\d+)$/.exec(OPTS.res || OPTS.scr || '');
    if (m && +m[1] > 1280) { resTo = +m[1] / +m[2] > 1.5 ? '1280x720' : '1024x768'; OPTS.res = resTo; DB.lagres = resTo; }
  }
  DB.set = S; persist(); applySettings(S); cloudSave();
  if (PCID) { OPTS.tune = 1; OPTS.bgp = 1; OPTS.macc = 1; api('opts_set', { d: PCID, o: JSON.stringify(OPTS) }, function () {}); }
  api('feedback', { text: 'Lag: bir bosishda tuzatildi' + (w ? ' (kuchsiz PC)' : ''), kind: 'first', nick: MYNAME || '', ver: VERSION }, function () {});
  closeModal(); toast(resTo ? T('lf_ok_s').replace('{r}', resTo) : T(w ? 'lf_ok_w' : 'lf_ok'), 9000);
}
/* Botlar bilan mashq (oflayn): o'z kompyuterida server - CS 1.6 ning ichki botlari (ZBot). Internet kerak emas */
var BOT_MODES = ['std', 'aimt', 'aim', 'noshoot', 'pistol', 'awp', 'knife', 'nade'];
/* mashq turi: CS 1.6 ning ichki bot sozlamalari (plaginsiz). Har safar hammasi yuboriladi - oldingi tur qolib ketmasin */
function botCvars(b) {
  var m = b.m || 'std', train = m === 'aim' || m === 'aimt' || m === 'noshoot';
  /* granata mashqi: botsiz, o'z serverida sv_cheats 1 - F3 granatalar beradi, F4 uchib yurish (noclip) */
  if (m === 'nade') return ['sv_cheats 1', 'bot_stop 1', 'mp_startmoney 16000', 'mp_buytime 9', 'mp_roundtime 9', 'mp_freezetime 0', 'mp_c4timer 60',
    'alias xcnade "give weapon_hegrenade;give weapon_flashbang;give weapon_smokegrenade"', 'bind F3 xcnade', 'bind F4 noclip'];
  return ['sv_cheats 0', 'bot_stop ' + (m === 'aim' || m === 'aimt' ? 1 : 0), 'bot_dont_shoot ' + (m === 'noshoot' || m === 'aimt' ? 1 : 0), 'bot_pistols_only ' + (m === 'pistol' ? 1 : 0),
    'bot_snipers_only ' + (m === 'awp' ? 1 : 0), 'bot_knives_only ' + (m === 'knife' ? 1 : 0),
    'mp_startmoney ' + (train || m === 'awp' ? 16000 : 800), 'mp_buytime ' + (train ? 9 : 0.5), 'mp_roundtime ' + (train ? 9 : 2.5), 'mp_freezetime ' + (train ? 0 : 2)];
}
var BOT_MAPS = ['de_dust2', 'de_inferno', 'de_nuke', 'de_train', 'de_aztec', 'de_dust', 'cs_assault', 'cs_italy'];
/* granata mashqi: xaritadagi mashhur tutun/flesh joylari (qayerda turib, qayerga qarab otish) */
/* ---- Aim test: 60 soniya, joyida turgan botlar. Birinchi kill bilan vaqt boshlanadi; kill/headshot o'yin konsolidan sanaladi.
 * Natija o'yin chatida (say - faqat o'z serverida), eng yaxshisi saqlanadi va haftalik TOP-10 ga yuboriladi ---- */
var AIMT = null, AIM_TOP = null;
function aimtPane() {
  var best = DB.aimBest, h = '<div class="mut" style="font-size:12px;margin:2px 0 8px">' + esc(T('at_how')) + '</div>';
  if (best) h += '<div class="kv"><span>' + esc(T('at_best')) + '</span><b>' + best.k + ' kill · ' + (best.k ? Math.round(best.h * 100 / best.k) : 0) + '% HS</b></div>';
  h += '<div class="ph2 m">' + esc(T('at_top')) + '</div><div class="attop" id="atTop">' + aimTopHtml() + '</div>';
  if (!AIM_TOP) api('aim_top', {}, function (r) { if (!r.ok) return; AIM_TOP = r.top || []; var e = $('atTop'); if (e) e.innerHTML = aimTopHtml(); });
  return h;
}
function aimTopHtml() {
  if (!AIM_TOP) return '<div class="mut">' + esc(T('loading')) + '</div>';
  if (!AIM_TOP.length) return '<div class="mut">' + esc(T('at_none')) + '</div>';
  var h = ''; each(AIM_TOP, function (x, i) { h += '<div class="kv"><span>' + (i + 1) + '. ' + esc(x.n) + '</span><b>' + x.k + ' kill · ' + (x.k ? Math.round(x.h * 100 / x.k) : 0) + '% HS</b></div>'; });
  return h;
}
function aimtKill(hs) {
  if (!AIMT) return;
  if (!AIMT.t0) { AIMT.t0 = now(); AIMT.k = 0; AIMT.h = 0; cmd('say "' + T('at_go') + '"'); clearTimeout(AIMT.tm); AIMT.tm = setTimeout(aimtEnd, 60000); }
  AIMT.k++; if (hs) AIMT.h++;
}
function aimtEnd() {
  if (!AIMT || !AIMT.t0) return;
  var k = AIMT.k, h = AIMT.h, hp = k ? Math.round(h * 100 / k) : 0, best = DB.aimBest, rec = !best || k > best.k || (k === best.k && h > best.h);
  AIMT.t0 = 0;                                     // keyingi kill - yangi urinish
  if (rec) { DB.aimBest = { k: k, h: h, t: now() }; persist(); }
  cmd('say "' + T('at_res').replace('{k}', k).replace('{h}', hp) + (rec ? ' ' + T('at_rec') : '') + '"');
  if (ME) api('aim_set', { k: k, h: h }, function (r) { if (r.ok) AIM_TOP = r.top || AIM_TOP; });
}
/* QR kodni HTML bilan chizish: o'yin brauzeri data: rasmlarni ko'rsatmaydi (QR "x" bo'lib chiqardi).
 * Har qator - bir xil rangdagi bo'laklar ketma-ketligi (kam element, eski CEF da ham tez) */
function qrHtml(q, px) {
  var n = q.getModuleCount(), c = Math.max(2, Math.floor(px / (n + 4))), h = '<div class="tgqr" style="padding:' + (c * 2) + 'px;width:' + (n * c) + 'px">';
  for (var r = 0; r < n; r++) {
    h += '<div class="qrr" style="height:' + c + 'px">';
    for (var x = 0; x < n; ) { var d = q.isDark(r, x), k = x; while (k < n && q.isDark(r, k) === d) k++; h += '<span style="width:' + ((k - x) * c) + 'px' + (d ? ';background:#000' : '') + '"></span>'; x = k; }
    h += '</div>';
  }
  return h + '</div>';
}
/* telefon ilovasi (Android, Xash3D asosida): havola mobile.json dan (yangi build chiqsa o'zi yangilanadi), telefon kamerasi bilan QR */
function mobApp() {
  CLK.mobapp = (CLK.mobapp || 0) + 1; CLK_N++;
  var site = 'https://cssborka.uz/xclient/';
  var show = function (apk) {
    openSide('mobapp', T('mb_t'), '<div class="qrw"><p class="qri">' + esc(T('mb_intro')) + '</p><div class="qrcards">' +
      qrCard('apk', T('mb_c1'), apk, T('mb_c1s'), T('mb_b1'), 'data-act="uapk"') +
      qrCard('site', T('mb_c2'), site, 'cssborka.uz/xclient', T('mb_b2'), 'data-act="usite"') + '</div>' +
      '<ol class="qrsteps"><li>' + esc(T('mb_s1')) + '</li><li>' + esc(T('mb_s2')) + '</li><li>' + esc(T('mb_s3')) + '</li></ol>' +
      '<p class="qrnote">' + esc(T('mb_note')) + '</p>' +
      (ME ? '<div class="mcode" id="mcBox"><b>' + esc(T('mc_t')) + '</b><small>' + esc(T('mc_s')) + '</small><a class="btn red" data-act="mcode">' + esc(T('mc_b')) + '</a></div>' : '') + '</div>');
    chime();
  };
  var x = new XMLHttpRequest(), done = false, fb = 'https://github.com/jamic2922220-alt/cssborka.uz-mobile/releases/latest/download/CS16-boosttop.apk';
  var tm = setTimeout(function () { if (!done) { done = true; show(fb); } }, 4000);
  x.onreadystatechange = function () { if (x.readyState !== 4 || done) return; done = true; clearTimeout(tm); var u = fb; try { var j = JSON.parse(x.responseText); if (/^https:\/\//.test(j.apk_url || '')) u = j.apk_url; } catch (e) {} show(u); };
  try { x.open('GET', 'mobile.json?t=' + now(), true); x.send(null); } catch (e) { done = true; clearTimeout(tm); show(fb); }
}
/* QR karta: sarlavha, QR (telefon kamerasi bilan), katta tugma va pastda bosiladigan havola - ikkalasi ham saytni o'yinchining brauzerida ochadi */
function qrCard(id, title, url, label, btn, attr) {
  var qr = ''; try { var q = QRGEN(0, 'M'); q.addData(url); q.make(); qr = qrHtml(q, id === 'tg' ? 160 : 190); } catch (e) {}
  return '<div class="qrc qrc-' + id + '"><div class="qrt">' + esc(title) + '</div><div class="qrbox">' + qr + '</div><small class="qrs">' + esc(T('tg_scan')) + '</small>' +
    '<a class="btn red qrb" ' + attr + '>' + esc(btn) + ' &#8599;</a><a class="qrl" ' + attr + '>' + esc(label) + '</a></div>';
}
/* havolani o'yinchining brauzerida ochish: launcher (faqat o'zida yozilgan manzillar). Launchersiz - manzilni ko'rsatamiz */
function openLink(kind, code) {
  CLK['ln_' + kind] = (CLK['ln_' + kind] || 0) + 1; CLK_N++;
  var shown = { usite: 'cssborka.uz/xclient', uapk: 'cssborka.uz/xclient', utg: 'Telegram' }[kind] || '';
  if (!PCID) return toast(T('ln_nol').replace('{u}', shown), 7000);
  vidCmd(kind, code || '', null, true); toast(T('ln_open'), 5000);
}
/* yoqimli "ding" (o'yin ovozi orqali): QR oynalari ochilganda */
function chime() { if (S && S.uisnd !== 0 && hasApi()) cmd('play xclient/chime.wav'); }
function nadeTips(mp) {
  var t = T('nd_' + mp), h = '<div class="ph2 m">' + esc(T('nd_keys')) + '</div><div class="ndk"><b>F3</b> ' + esc(T('nd_f3')) + ' &nbsp; <b>F4</b> ' + esc(T('nd_f4')) + '</div>';
  if (t && t !== 'nd_' + mp) { h += '<div class="ph2 m">' + esc(T('nd_spots')) + '</div><ol class="ndl">'; each(t.split('|'), function (x) { h += '<li>' + esc(x) + '</li>'; }); h += '</ol>'; }
  return h;
}
function botsPane() {
  var b = DB.bots || {}, mp = b.map || 'de_dust2', n = b.n || (pcWeak() ? 5 : 9), d = b.d != null ? b.d : 1, m = '', c = '', l = '';
  each(BOT_MAPS, function (x) { m += '<a class="' + (x === mp ? 'on' : '') + '" data-bmap="' + x + '">' + esc(x) + '</a>'; });
  each([3, 5, 9, 13], function (x) { c += '<a class="' + (x === n ? 'on' : '') + '" data-bn="' + x + '">' + (x + 1) + ' ' + esc(T('bt_pl')) + '</a>'; });
  each([0, 1, 2, 3], function (x) { l += '<a class="' + (x === d ? 'on' : '') + '" data-bd="' + x + '">' + esc(T('bt_d' + x)) + '</a>'; });
  var md = b.m || 'std', ms = '';
  each(BOT_MODES, function (x) { ms += '<a class="' + (x === md ? 'on' : '') + '" data-bm="' + x + '" title="' + esc(T('bm_' + x + '2')) + '">' + esc(T('bm_' + x)) + '</a>'; });
  openSide('bots', T('m_bots'), '<div class="bts"><div class="mut" style="margin-bottom:10px">' + esc(T('bt_s')) + '</div>' +
    '<div class="ph2 m">' + esc(T('bt_mode')) + '</div><div class="seg2">' + ms + '</div><div class="mut" style="font-size:12px;margin:-2px 0 6px">' + esc(T('bm_' + md + '2')) + '</div>' +
    '<div class="ph2 m">' + esc(T('bt_map')) + '</div><div class="seg2">' + m + '</div>' +
    (md === 'aimt' ? aimtPane() : md === 'nade' ? nadeTips(mp) :
    '<div class="ph2 m">' + esc(T('bt_n')) + '</div><div class="seg2">' + c + '</div>' +
    '<div class="ph2 m">' + esc(T('bt_dif')) + '</div><div class="seg2">' + l + '</div>') +
    '<div class="fr w" style="margin-top:10px"><div class="lb">' + esc(T('bt_lan')) + '<small>' + esc(T('bt_lan2')) + '</small></div><div class="tg' + (b.lan !== 0 ? ' on' : '') + '" data-blan="1"><i></i></div></div>' +
    (b.lan !== 0 ? '<div class="lansv"><input class="tx" id="lanHn" maxlength="40" placeholder="' + esc(T('ls_name')) + '" value="' + esc(b.hn || '') + '"><input class="tx" id="lanPw" maxlength="30" placeholder="' + esc(T('ls_pw')) + '" value="' + esc(b.pw || '') + '"></div>' : '') +
    '<a class="btn red big" data-act="botgo" style="margin-top:14px">' + ico('play') + ' ' + esc(T('bt_go')) + '</a>' +
    '<div class="mut" style="font-size:12px;margin-top:10px">' + esc(T('bt_note')) + '</div></div>');
}
function botsGo() {
  var b = DB.bots || {}, mp = b.map || 'de_dust2', n = b.n || (pcWeak() ? 5 : 9), d = b.d != null ? b.d : 1;
  var ihn = $('lanHn'), ipw = $('lanPw');           // LAN server nomi va paroli (ixtiyoriy) - eslab qolinadi
  if (ihn || ipw) { DB.bots = b; b.hn = ihn ? String(ihn.value || '').replace(/^\s+|\s+$/g, '') : b.hn; b.pw = ipw ? String(ipw.value || '').replace(/\s+/g, '') : b.pw; persist(); }
  if (b.m === 'nade') n = 0;                     // granata mashqi - botsiz (LAN yoqilgan bo'lsa do'stlar kira oladi)
  if (b.m === 'aimt') { n = pcWeak() ? 9 : 13; d = 0; AIMT = { on: 1, t0: 0, k: 0, h: 0 }; } else AIMT = null;   // aim test: ko'proq nishon
  closeModal();
  if (pcWeak() && n > 5 && !DB.botWarn) { DB.botWarn = 1; persist(); toast(T('bt_weak'), 9000); }
  if (CONNECTED) cmd('disconnect');
  /* o'yin DLL'i (mp.dll) o'yin ochilganda yuklanadi - bot_* sozlamalari xarita ochilishidan oldin ham bor */
  /* LAN: do'stlar ham kira olsin - joy ko'proq, botlar "fill" rejimida (odam kirsa bot chiqadi, jami son saqlanadi).
   * Server sozlamalari LAN uchun: tez yangilanish, tezlik cheklovi yo'q - lag bo'lmasin */
  var lan = b.lan !== 0, total = n + 1, qmode = lan && n ? 'fill' : 'normal', quota = lan && n ? total : n;
  var hn = String(b.hn || ((S && S.name) || MYNAME || 'Player') + ' - LAN').replace(/["\\;]/g, '').slice(0, 40), spw = lan && b.pw ? String(b.pw).replace(/["\\;\s]/g, '').slice(0, 30) : '';
  if (lan && PCID) vidCmd('fw', '', null, true);   // launcher: Windows firewall ruxsati (bir marta, "Да" so'raydi)
  var hc = ['sv_lan 1', 'hostname "' + hn + '"', 'sv_password "' + spw + '"', 'pausable 0', 'sv_maxrate 100000', 'sv_minrate 25000', 'sv_maxupdaterate 101', 'sv_minupdaterate 60'];   // server.cfg qayta yozsa - botsApply yana yuboradi
  each(['maxplayers ' + (lan ? Math.max(total, 12) : total)].concat(hc).concat([
        'mp_autoteambalance 1', 'mp_limitteams 2', 'mp_timelimit 0']).concat(botCvars(b)).concat([
        'bot_difficulty ' + d, 'bot_join_after_player 0', 'bot_auto_vacate 1', 'bot_quota_mode ' + qmode, 'bot_quota ' + quota, 'bot_chatter minimal', 'map ' + mp]), function (c) { cmd(c); });
  toast(T(b.m === 'aimt' ? 'at_wait' : b.m === 'nade' ? 'nd_wait' : lan ? 'bt_wait_lan' : 'bt_wait'), b.m === 'nade' ? 12000 : lan ? 9000 : 6000);
  /* xarita ochilganda o'yin server.cfg / listenserver.cfg ni bajaradi va bot_quota 0 ga tushadi - shuning uchun yuklangandan keyin
   * yana bir necha marta yuboramiz (sekin kompyuterda yuklanish 30-60 s). Ortiqcha yuborish zararsiz - son o'zgarmaydi */
  BOT_PEND = { hc: hc, n: quota, qm: qmode, d: d, t: now(), b: b, rs: 0 }; BOT_SESS = { t: now(), m: b.m || 'std' }; fxClass(); sparks();
  each([5, 10, 16, 24, 35, 50, 70, 95], function (sec) { setTimeout(botsApply, sec * 1000); });
}
var BOT_PEND = null, BOT_SESS = null, LOCAL_ON = false;
/* o'z kompyuteridagi server (botlar bilan mashq): ulanish manzili loopback/localhost/127.x bo'ladi. Bu haqiqiy server emas -
 * tarix, statistika, tarmoq sozlash, ping o'lchovi kerak emas; lekin menyu o'yin davom etayotganini bilishi shart */
function isLocalAddr(a) { return /^(local|loopback|localhost|127\.\d+\.\d+\.\d+|0\.0\.0\.0)(:\d+)?$/i.test(String(a || '').replace(/\s+/g, '')); }   // NextClient o'z serverini 'local:27015' deb beradi
function localGame() { return LOCAL_ON || !!(BOT_SESS && now() - BOT_SESS.t < 6 * 3600000); }
/* mashq natijasi: ESC bosilganda o'z serveridan o'yinchilar ro'yxati (kill = ochko) */
function botsScore() {
  if (!BOT_SESS || BOT_SESS.m === 'nade' || BOT_SESS.sq > 2 || now() - BOT_SESS.t > 4 * 3600000 || !NC || !NC.matchmaking || !NC.matchmaking.getPlayersInfo) return;
  BOT_SESS.sq = (BOT_SESS.sq || 0) + 1;   // ko'pi bilan 3 marta: o'z serveriga so'rov ba'zi versiyalarda xato beradi
  var me = (MYNAME || (S && S.name) || '').toLowerCase();
  try {
    NC.matchmaking.getPlayersInfo('127.0.0.1:27015').then(function (list) {
      if (!list || !list.length) return;
      var mine = null, best = 0, place = 1;
      each(list, function (x) { if (me && String(x.name || '').toLowerCase() === me) mine = x; best = Math.max(best, x.score | 0); });
      if (!mine) return;
      each(list, function (x) { if ((x.score | 0) > (mine.score | 0)) place++; });
      toast(T('bt_score').replace('{k}', mine.score | 0).replace('{p}', place).replace('{n}', list.length).replace('{m}', T('bm_' + BOT_SESS.m)), 7000);
    }, function () {});
  } catch (e) {}
}
function botsApply() {
  if (!BOT_PEND || now() - BOT_PEND.t > 120000) { BOT_PEND = null; return; }
  each(['bot_difficulty ' + BOT_PEND.d, 'bot_join_after_player 0', 'bot_quota_mode ' + (BOT_PEND.qm || 'normal'), 'bot_quota ' + BOT_PEND.n].concat(botCvars(BOT_PEND.b)).concat(BOT_PEND.hc || []), function (c) { cmd(c); });
}
/* Telegram ulash - oson: QR kodni telefon bilan skanerlash (t.me/bot?start=KOD) -> Telegram'da "Start" -> ulandi.
 * Menyu 4 s da bir so'raydi va ulanganini darhol ko'rsatadi. Birinchi ulashda sovg'a - sandiq */
function tgOpen(intro) {
  api('tg_code', {}, function (r) {
    if (!r.ok) return toast(r.msg || 'Xato', 5000);
    var h = '<div class="qrw">' + (intro ? '<p class="qri">' + esc(T('tg_intro')) + '</p>' : '') +
      (r.gift ? '<div class="qrgift">' + ico('gift') + ' ' + esc(T('tg_gift')) + '</div>' : '') +
      '<div class="qrcards one">' + (r.link ? qrCard('tg', T('tg_card'), r.link, 't.me/' + (r.bot || ''), T('tg_btn'), 'data-utg="' + esc(r.code) + '"') : '') + '</div>' +
      '<ol class="qrsteps"><li>' + esc(T('tg_s1')) + '</li><li>' + esc(T('tg_s2')) + '</li><li>' + esc(T('tg_s3')) + '</li></ol>' +
      '<div class="qrcode2"><span>' + esc(T('tg_or').replace('{b}', r.bot ? '@' + r.bot : 'bot')) + '</span><b>' + esc(r.code) + '</b></div>' +
      '<div class="tgst' + (r.linked ? ' ok' : '') + '" id="tgSt">' + esc(T(r.linked ? 'tg_on' : 'tg_wait')) + '</div>' +
      '<p class="qrnote">' + esc(T('tg_ben')) + '</p>' +
      (r.linked ? '<a class="btn" data-act="tgunlink">' + esc(T('tg_unlink')) + '</a>' : '') + '</div>';
    openSide('tg', 'Telegram', h); chime();
    if (!r.linked) tgPoll(0);
  });
}
function tgPoll(n) {
  if (n > 75) return;                              // 5 daqiqa
  setTimeout(function () {
    if (curModal !== 'mdSide' || sideMode !== 'tg') return;
    api('tg_st', {}, function (r) {
      if (!r || !r.ok) return tgPoll(n + 1);
      if (!r.linked) return tgPoll(n + 1);
      if (ME) { ME.tglinked = 1; if (r.chests != null) ME.chests = r.chests; renderBar(); }
      var e = $('tgSt'); if (e) { e.className = 'tgst ok'; e.innerHTML = esc(T('tg_done')); }
      sfx('save'); toast(T('tg_done'), 7000);
    });
  }, 4000);
}
/* kirgandan keyin bir marta (3 kunda bir, ko'pi bilan 3 marta) Telegram ulashni taklif qilamiz */
function tgAsk(n) {
  if (!ME || ME.tglinked || LITE || n > 30) return;
  if (DB.tgAsk && now() - DB.tgAsk < 3 * 86400000) return;
  if ((DB.tgAskN || 0) >= 3) return;
  if (DB.dnd || curModal || CONNECTED) return setTimeout(function () { tgAsk(n + 1); }, 20000);
  DB.tgAsk = now(); DB.tgAskN = (DB.tgAskN || 0) + 1; persist();
  tgOpen(true);
}
/* oyna ochiq: orqa fondagi cheksiz CSS animatsiyalar (avatar ramkalari, yangiliklar) to'xtaydi - eski o'yin brauzeri ularni ham qayta chizardi */
function mdClass(on) { var h = document.documentElement, c = (h.className || '').replace(/(^|\s)mdon(?=\s|$)/g, ''); h.className = on ? c + ' mdon' : c; }
function closeModal() {
  if (DD) ddClose();
  if (!curModal) return;
  mdClass(false);
  if (curModal === 'mdSettings' && XLIVE && S) { XLIVE = false; each(xhairCmds(S), function (x) { cmd(x); }); }   // saqlanmagan pritselni qaytarish
  KEYWAIT = '';
  $(curModal).className = 'modal'; curModal = '';
  if (!SFX_QUIET) sfx('close');
}
var askCb = null;
function ask(title, cb, two, pw, noin, pw2) {
  askCb = cb; $('askT').innerHTML = esc(title); $('askI').value = ''; $('askI2').value = '';
  $('askI').style.display = noin ? 'none' : '';
  $('askI').type = pw ? 'password' : 'text';
  $('askI2').style.display = two ? '' : 'none';
  $('askI2').type = pw2 ? 'password' : 'text';      // ikkinchi maydon faqat parol bo'lganda yashirin (klan tegi, setinfo nomi ko'rinib yozilsin)
  $('mdAsk').className = 'modal on';
  setTimeout(function () { try { $('askI').focus(); } catch (e) {} }, 50);
}
function askDone(ok) {
  $('mdAsk').className = 'modal';
  var cb = askCb; askCb = null;
  if (ok && cb) cb($('askI').value, $('askI2').value);
}

/* ============================================================ profil rasmi */
var AVC = ['#ff3b3b', '#ff8a2a', '#f5c518', '#3ccf4e', '#1fb5d6', '#3b6cff', '#9b4dff', '#ff4fb4', '#6b6470'];
function avColors() {
  var h = '';
  each(AVC, function (c) { h += '<a class="' + (ME && ME.avc === c ? 'on' : '') + '" data-avc="' + c + '" style="background:' + c + '"></a>'; });
  return h;
}
function avUpload(file) {
  if (!file) return;
  if (!/^image\//.test(file.type || '')) return toast(T('a_photo_bad'));
  if (!window.FileReader) return toast(T('a_photo_na'));
  var rd = new FileReader();
  rd.onload = function () {
    var im = new Image();
    im.onload = function () {
      // markazdan kvadrat qirqib 128x128 JPEG qilamiz (~10 KB)
      var c = document.createElement('canvas'); c.width = 128; c.height = 128;
      var g = c.getContext('2d'), s = Math.min(im.width, im.height);
      g.fillStyle = '#000'; g.fillRect(0, 0, 128, 128);
      g.drawImage(im, Math.round((im.width - s) / 2), Math.round((im.height - s) / 2), s, s, 0, 0, 128, 128);
      var data = '';
      try { data = c.toDataURL('image/jpeg', 0.85); } catch (e) {}
      if (data.indexOf('data:image/jpeg') !== 0) { try { data = c.toDataURL('image/png'); } catch (e2) {} }
      if (!data) return toast(T('a_photo_bad'));
      toast(T('lg_wait'));
      api('avatar', { img: data }, function (r) { if (!r.ok) return toast(r.msg || 'Xato'); setMe(r.me); toast(T('saved')); if (curModal === 'mdSettings') showSetTab('account'); });
    };
    im.onerror = function () { toast(T('a_photo_bad')); };
    im.src = rd.result;
  };
  rd.readAsDataURL(file);
}

/* ============================================================ amallar */
var ACT_EL = null;   // bosilgan element (data-* qo'shimchalarini o'qish uchun)
function act(a) {
  if (LITE && /^(friends|profile|missions|login|weekall|promo|stats|clan|ref)$/.test(a)) return openPromo();
  if (a === 'quick' || a === 'play') { closeModal(); return quick(); }
  if (a === 'bots') return botsPane();
  if (a === 'lanhost') { DB.bots = DB.bots || {}; DB.bots.lan = 1; persist(); return botsPane(); }
  if (a === 'botgo') return botsGo();
  if (a === 'lagfix') return lagFix();
  if (a === 'lagfix2') return lagFix(true);
  if (a === 'resauto') { OPTS.res = ''; saveOpts(T('v_rs2')); return showSetTab('video'); }   // o'yin monitor o'lchamida (tiniq)
  if (a === 'servers') return openServers('internet');
  if (a === 'friends') return openFriends();
  if (a === 'missions') return openMissions();
  if (a === 'nettest') return netTest();
  if (a === 'netapply') { if (!NETT) return; E.net = NETT.rec.net; E.interp = NETT.rec.interp; showSetTab('pro'); return toast(T('nt_applied'), 4000); }
  if (a === 'weekall') return openServers('history');
  if (a === 'profile') return ME ? openSettings('account') : openLogin();
  if (a === 'login') return openLogin();
  if (a === 'regoffer') { lgReg = true; return openLogin(); }
  if (a === 'trnext') { if (TOUR_I < TOUR.length - 1) { TOUR_I++; tourDraw(); } else tourEnd(); return; }
  if (a === 'trskip') return tourEnd();
  if (a === 'trreg') { tourEnd(); lgReg = true; return openLogin(); }
  if (a === 'acctx') { DB.acn = (DB.acn || 0) + 1; DB.acx = now(); persist(); statePush(); renderAll(); return toast(T(DB.acn >= 3 ? 'ac_x' : 'ac_x2'), 5000); }   // yopilsa 5 kundan keyin yana (ko'pi bilan 3 marta)
  if (a === 'rejq') { closeModal(); if (REJ_IP) startQueue(REJ_IP); return; }
  if (a === 'spwgo') { if (!srvSel) return; return DB.spw && DB.spw[srvSel] ? doConnect(srvSel, true) : spwAsk(srvSel, false); }
  if (a === 'spwdel') { if (DB.spw && srvSel) { delete DB.spw[srvSel]; persist(); } toast(T('pw_del'), 4000); return renderInfo(); }
  if (a === 'usite' || a === 'uapk') return openLink(a);
  if (a === 'coach_aim' || a === 'coach_nade') { DB.bots = DB.bots || {}; DB.bots.m = a === 'coach_aim' ? 'aimt' : 'nade'; var cm = ACT_EL && ACT_EL.getAttribute('data-cmap'); if (cm && BOT_MAPS.indexOf(cm) >= 0) DB.bots.map = cm; persist(); closeModal(); return botsPane(); }
  if (a === 'coach_lag') { closeModal(); return lagFixPane(T('cc_blag'), false); }
  if (a === 'mobx') { DB.mobx = now(); persist(); renderAll(); return; }
  if (a === 'mobapp') return mobApp();
  if (a === 'mcode') { CLK.mcode = (CLK.mcode || 0) + 1; CLK_N++; return api('mcode', {}, function (r) { var bx = $('mcBox'); if (!bx) return;
    if (!r.ok) return toast(r.msg || 'Xato', 5000);
    bx.innerHTML = '<b>' + esc(T('mc_t')) + '</b><div class="mcnum">' + esc(r.code.slice(0, 3) + ' ' + r.code.slice(3)) + '</div><small>' + esc(T('mc_s2')) + '</small>'; }); }
  if (a === 'updl') return updPane();
  if (a === 'updx') { DB.updx = now(); persist(); updCard(); return; }
  if (a === 'updauto') { OPTS.auto = 1; api('opts_set', { d: PCID, o: JSON.stringify(OPTS) }, function (r) { toast(r.ok ? T('up_onok') : (r.msg || 'Xato'), 7000); if (r.ok) updPane(); }); return; }
  if (a === 'promox') { DB.pxx = now(); persist(); statePush(); renderAll(); return; }
  if (a === 'feedback') return openFeedback();
  if (a === 'fbsend') return sendFeedback();
  if (a === 'settings') return openSettings();
  if (a === 'quit') { if (GMUTE) { cmd('volume ' + gameVol()); GMUTE = false; } return cmd('quit'); }   // jim holat config.cfg ga saqlanib qolmasin
  if (a === 'resume') { closeModal(); return cmd('cancelselect'); }   // NextClient'ning o'z "ResumeGame" tugmasi ham shu buyruqni yuboradi
  if (a === 'dconn') { closeModal(); return cmd('disconnect'); }
  if (a === 'plist') { if (!CONNECTED) return; openServers('history'); srvSel = CONNECTED; loadPlayers(CONNECTED); query(CONNECTED, true); return renderServers(); }
  if (a === 'close') return closeModal();
  if (a === 'guest') { DB.guest = 1; persist(); return closeModal(); }
  if (a === 'dologin') return doLogin();
  if (a === 'pweye') { var pe = $('lgPass'), on = pe.type === 'password'; try { pe.type = on ? 'text' : 'password'; } catch (e2) {} $('lgEye').className = 'peye' + (on ? ' on' : ''); return; }
  if (a === 'lgswitch') { lgReg = !lgReg; return renderLoginForm(); }
  if (a === 'forgot') return forgot();
  if (a === 'refresh') { each(tabIps(), function (ip) { query(ip, true); }); if (srvSel) loadPlayers(srvSel); if (srvTab === 'friends') loadFriends(); return; }
  if (a === 'join') { if (srvSel) { closeModal(); connect(srvSel); } return; }
  if (a === 'togglefav') return toggleFav(srvSel);
  if (a === 'clearhist') { DB.hist = []; CUR = null; persist(); return renderAll(); }
  if (a === 'clearall') { DB.hist = []; DB.fav = []; CUR = null; persist(); cloudSave(); toast(T('sy_ok')); return renderAll(); }
  if (a === 'addip') return ask(T('ask_ip'), function (v) { var ip = normIp(v); if (!ip) return toast(T('bad_ip')); if (!isFavIp(ip)) toggleFav(ip); srvSel = ip; query(ip, true); if (srvTab !== 'favs' && srvTab !== 'lan') setSrvTab('favs'); else renderServers(); });
  if (a === 'console') { closeModal(); return cmd('toggleconsole'); }
  if (a === 'fradd') {
    var v = ($('frIn').value || '').replace(/\s+/g, '');
    if (!v) return;
    if (FR_SUG && FR_SUG.length === 1 && !FR_SUG[0].st) v = FR_SUG[0].login;   // bitta variant bo'lsa - o'sha
    return frAdd(v);
  }
  if (a === 'avdel' && curModal !== 'mdSettings') return api('avatar', { img: 'none' }, function (r) { if (r.ok) { setMe(r.me); toast(T('saved')); openAvatars(); } });
  if (a === 'frback') { CHAT = null; return openFriends(); }
  if (a === 'chatsend') return chatSend();
  if (a === 'cfgtop') return openCfgTop();
  if (a === 'chests') return openChests();
  if (a === 'chestopen') return chestOpen();
  if (a === 'tglink') return tgOpen();
  if (a === 'tgunlink') return api('tg_unlink', {}, function () { if (ME) ME.tglinked = 0; closeModal(); toast(T('tg_unl_ok')); });
  if (a === 'cfgshare') return ask(T('cf_name'), function (title) {
    var cs = copy(E); delete cs.name; delete cs.tag;
    title = clean(title).slice(0, 40);
    api('cfg_share', { cfg: JSON.stringify({ s: cs, b: BINDS, b2: BINDS2 }), title: title, pub: title ? '1' : '0' }, function (r) {
      if (!r.ok) return toast(r.msg || 'Xato');
      var o = $('cfgOut'); if (o) o.innerHTML = '<div class="avurl" style="margin-top:10px"><input class="ipin" readonly value="' + esc(r.code) + '"><a class="cpy" data-copyip="' + esc(r.code) + '">' + esc(T('ip_copy')) + '</a></div>';
      toast(T('cf_ok').replace('{c}', r.code), 6000);
    });
  });
  if (a === 'cfgload') return ask(T('cf_ask'), function (c) { cfgUse(c); });
  if (a === 'cfgload_old') return ask(T('cf_ask'), function (c) {
    api('cfg_get', { code: c }, function (r) {
      if (!r.ok || !r.cfg) return toast(r.msg || T('cf_bad'));
      var c2 = r.cfg; for (var k in c2.s || {}) if (c2.s.hasOwnProperty(k) && DEF.hasOwnProperty(k) && k !== 'name' && k !== 'tag') E[k] = c2.s[k];
      if (c2.b) { DB.binds = c2.b; DB.binds2 = c2.b2 || {}; loadBinds(); applyBinds(); persist(); }
      E.xp = presetOf(E); toast(T('cf_loaded'), 5000); showSetTab('tools');
    });
  });
  if (a === 'keysfactory') return ask(T('k_factory_ask'), function () {
    // CS 1.6 zavod tugmalari: hammasi o'chiriladi (unbindall), so'ng asl tugmalar qo'yiladi; X CLIENT qo'shimchalari bo'sh qoladi
    var F = {"`": "toggleconsole", "ESCAPE": "cancelselect", "w": "+forward", "s": "+back", "a": "+moveleft", "d": "+moveright", "SPACE": "+jump", "CTRL": "+duck", "SHIFT": "+speed", "MOUSE1": "+attack", "MOUSE2": "+attack2", "r": "+reload", "e": "+use", "g": "drop", "q": "lastinv", "1": "slot1", "2": "slot2", "3": "slot3", "4": "slot4", "5": "slot5", "6": "slot6", "7": "slot7", "8": "slot8", "9": "slot9", "0": "slot10", "b": "buy", "o": "buyequip", "m": "chooseteam", ",": "buyammo1", ".": "buyammo2", "TAB": "+showscores", "y": "messagemode", "u": "messagemode2", "k": "+voicerecord", "t": "impulse 201", "n": "nightvision", "f": "impulse 100", "z": "radio1", "x": "radio2", "c": "radio3", "F1": "autobuy", "F2": "rebuy", "F5": "snapshot", "MWHEELUP": "invprev", "MWHEELDOWN": "invnext", "PAUSE": "pause"};
    cmd('unbindall'); for (var fk in F) if (F.hasOwnProperty(fk)) cmd('bind ' + q(fk) + ' ' + q(F[fk]));
    DB.binds = {}; each(ACTIONS, function (x) { DB.binds[x[0]] = ''; }); for (var fk2 in F) if (F.hasOwnProperty(fk2) && DB.binds.hasOwnProperty(F[fk2])) DB.binds[F[fk2]] = fk2;
    DB.binds2 = {}; loadBinds(); persist(); cloudSave(); toast(T('k_factory_ok'), 5000); showSetTab('keys');
  }, false, false, true);
  if (a === 'keysdef') { each(ACTIONS, function (x) { if (BINDS2[x[0]]) cmd('unbind ' + q(BINDS2[x[0]])); }); DB.binds = null; DB.binds2 = null; loadBinds(); applyBinds(); persist(); cloudSave(); toast(T('sy_ok')); return showSetTab('keys'); }
  if (a === 'cache') { OPTS.clean = 1; saveOpts(); return showSetTab('system'); }
  if (a === 'verify') { OPTS.verify = 1; saveOpts(); return showSetTab('system'); }
  if (a === 'check') { if (!canRead()) return toast(T('chk_na')); return verifySettings(S); }
  if (a === 'report') return api('report', { log: diagText() + '\n\n===== KONSOL =====\n' + CONLOG.join('\n'), who: ME ? ME.login : 'guest', ver: VERSION }, function (r) { toast(r.ok ? T('sy_repok') : (r.msg || 'Xato'), 5000); });
  if (a === 'xcopy') {
    var inp = $('xCode'); inp.value = xcode(E); inp.focus(); inp.select();
    var ok = false; try { ok = document.execCommand('copy'); } catch (e) {}
    return toast(ok ? T('x_copied') : T('x_copy2'));
  }
  if (a === 'xtest') {                         // 3 soniya qizil katta pritsel: menyu buyrug'i o'yinga yetib boradimi
    cmd('cl_crosshair_color "255 0 0"'); cmd('cl_crosshair_size large');
    setTimeout(function () {
      var v = readCvar('cl_crosshair_color');
      toast(T('hx_test2').replace('{v}', v == null ? '?' : v), 5000);
      each(xhairCmds(E || S), function (x) { cmd(x); });
    }, 3000);
    return toast(T('hx_test1'), 3000);
  }
  if (a === 'calcapply') { var cv = calcVal(); if (!cv) return toast(T('cc_bad')); E.sens = Math.max(0.1, Math.min(20, cv)); return toast(T('cc_ok').replace('{v}', E.sens), 4000); }
  if (a === 'hwauto') return hwAuto();
  if (a === 'dvroff') { OPTS.dvroff = 1; saveOpts(T('dvr_ok')); return showSetTab('pro'); }
  if (a === 'spfile') { var sf = $('sprayFile'); if (!sf) return; sf.value = ''; try { sf.click(); } catch (e) { toast(T('a_photo_na')); } return; }
  if (a === 'spav') return ME && ME.av ? sprayFrom(ME.av) : null;
  if (a === 'splogo') {                         // standart tiniq X CLIENT spray (saytda tayyorlangan)
    if (!PCID) return toast(T('sy_nolaunch'), 5000);
    return api('spray_reset', { d: PCID }, function (r) {
      if (!r.ok) return toast(r.msg || 'Xato', 5000);
      DB.sprayPrev = 'spray_logo.png'; DB.sprayT = now(); persist(); toast(T('sp_ok'), 6000);
      if (curModal === 'mdSettings' && setTab === 'cont') showSetTab('cont');
    });
  }
  if (a === 'gallery') return api('shots', { d: PCID }, function (r) {
    var h = '';
    if (!r.ok) h = '<div class="empty">' + esc(r.msg || T('sy_nolaunch')) + '</div>';
    else if (!r.list.length) h = '<div class="empty">' + esc(T('sh_none')) + '</div>';
    else each(r.list, function (x) {
      var u = 'xc_api.php?a=shot&d=' + encodeURIComponent(r.d) + '&k=' + encodeURIComponent(DB.pck || '') + '&f=' + encodeURIComponent(x.f);
      h += '<div class="shot"><img src="' + u + '" alt=""><small>' + esc(fmtTime(x.t * 1000)) + '</small><a class="x2" data-shdel="' + esc(x.f) + '">✕</a></div>';
    });
    openSide('shots', T('sh_title2'), '<div class="shots">' + h + '</div>');
  });
  if (a === 'procfg') {                        // Pro CFG: lag'siz internet, aniq sichqoncha, toza ovoz
    /* Grafika va FPS ga tegmaymiz: FPS ni 100 ga qotirish (144 Hz monitorda) va soya/yorug'likni o'chirish o'yinchilarga
     * "qotish" va xunuk grafika bo'lib tuyuldi. FPS faqat 100 dan past bo'lsa - 100 */
    E.net = 'fast'; E.vsync = 0; if (!(E.fps >= 100)) E.fps = 100;
    E.raw = 1; E.filter = 0; E.fastsw = 1; E.bob = 0; E.interp = 0.01; E.lw = 1; E.lc = 1;
    E.hisnd = 1; E.mixa = 0.1; E.pro = 1; E.xmig = 1; E.pmig = 1;   // pritsel kengayishiga (xdyn) tegmaymiz
    toast(T('pr_cfgok'), 5000); a = 'save';     // darhol saqlab qo'llaymiz - "Saqlash" ni bosish esdan chiqib, CFG ishlamay qolardi
  }
  if (a === 'fpsmode') {                       // kuchsiz kompyuter: grafikani pasaytiramiz
    E.detail = 0; E.shadows = 0; E.dyn = 0; E.vsync = 0; if (E.fps < 200) E.fps = 200;
    showSetTab('pro'); return toast(T('pr_fpsok'), 5000);
  }
  if (a === 'ultraoff') { ULTRA_WAS = true; E.ultra = 0; E.decals = 1000; E.hisnd = 1; E.mixa = 0.1; toast(T('pr_uloffok'), 5000); a = 'save'; }
  if (a === 'ultramode') {                     // juda eski kompyuter: teksturalar 2 barobar kichik, effektlar minimal - FPS 1.5-2 barobar
    E.ultra = 1; E.detail = 0; E.shadows = 0; E.dyn = 0; E.vsync = 0; E.decals = 300; E.hisnd = 0; E.mixa = 0.15; E.bob = 0;
    if (!(E.fps >= 100)) E.fps = 100;
    toast(T('pr_ulok'), 7000); a = 'save';    // darhol saqlab qo'llaymiz
  }
  if (a === 'vmdef') { each(['vmx', 'vmy', 'vmz', 'vmshift', 'lagst', 'lagsc', 'lagsp', 'camint', 'vmfov', 'bob'], function (k) { E[k] = DEF[k]; }); return showSetTab('hud'); }
  if (a === 'gsshare') {                         // xulosa kartasi: saytdagi o'yin yozuvidan chiziladi, Telegram kanalga ham tushadi
    var gl = GS_LAST, gb = document.querySelector('[data-act="gsshare"]'); if (!gl || !ME) return;
    if (gb) gb.style.visibility = 'hidden';
    return api('gsshare', { sid: gl.t, ip: gl.ip, map: gl.map || '', h: gl.h || 0, bs: gl.bs || 0, as: gl.a || 0 }, function (r) {
      if (gb) gb.style.visibility = '';
      if (!r.ok) return toast(r.msg || T('lg_neterr'), 5000);
      copyIp(r.url, null); toast(T('gs_shared'), 6000);
    });
  }
  if (a === 'gsoff') { DB.gsum = 0; persist(); closeModal(); return toast(T('gs_offok'), 5000); }
  if (a === 'gsvids') { closeModal(); return openSettings('demo'); }
  if (a === 'rcs2') {                          // CS2 radari kabi: katta, aylanadigan, uzoqroq xarita, Tab da butun xarita
    var r2 = { rmode: 1, rscale: 135, rmap: 0.6, ropac: 90, rbg: 0, rround: 0, rrot: 1, rfull: 1, rtracks: 0, rallies: 1, rnames: 0, rhp: 0 };
    for (var rk in r2) if (r2.hasOwnProperty(rk)) E[rk] = r2[rk];
    toast(T('h_cs2ok'), 5000); a = 'save';
  }
  if (a === 'camdef') { each(['bobst', 'bobv', 'bobl', 'boblow', 'bobcam', 'roll', 'rollspd', 'fovlerp', 'camsc'], function (k) { E[k] = DEF[k]; }); return showSetTab('hud'); }
  if (a === 'xdef') { each(['xp', 'xt', 'xs', 'xc', 'xtr', 'xdyn', 'xthick', 'xgap', 'xout'], function (k) { E[k] = DEF[k]; }); return showSetTab('hud'); }
  if (a === 'xpick') return ask(T('hx_colask'), function (v) {
    v = String(v || '').replace(/^\s+|\s+$/g, '');
    var m = /^#?([0-9a-f]{6})$/i.exec(v), r = /^(\d{1,3})[ ,]+(\d{1,3})[ ,]+(\d{1,3})$/.exec(v);
    if (m) E.xc = parseInt(m[1].slice(0, 2), 16) + ' ' + parseInt(m[1].slice(2, 4), 16) + ' ' + parseInt(m[1].slice(4, 6), 16);
    else if (r && r[1] < 256 && r[2] < 256 && r[3] < 256) E.xc = Number(r[1]) + ' ' + Number(r[2]) + ' ' + Number(r[3]);
    else return toast(T('x_badcode'));
    showSetTab('hud');
  });
  if (a === 'xcode') { if (applyCode($('xCode').value)) showSetTab('hud'); return; }
  if (a === 'rename') return ask(T('a_newname'), function (v) { api('profile', { name: v }, function (r) { if (!r.ok) return toast(r.msg); setMe(r.me); showSetTab('account'); }); });
  if (a === 'email') return ask(T('a_newmail'), function (v) { api('profile', { email: v }, function (r) { if (!r.ok) return toast(r.msg); setMe(r.me); showSetTab('account'); }); });
  if (a === 'passwd') return ask(T('a_oldnew'), function (o, n) { api('profile', { oldpass: o, newpass: n }, function (r) { if (!r.ok) return toast(r.msg); setMe(r.me); toast(T('saved')); showSetTab('account'); }); }, true, true, false, true);
  if (a === 'avpick') return openAvatars();   // o'yin to'liq ekranda bo'lganda Windows fayl oynasi o'yin ortida ochilib, o'yin "qotib" qolardi
  if (a === 'avdel') return api('avatar', { img: 'none' }, function (r) { if (!r.ok) return toast(r.msg); setMe(r.me); showSetTab('account'); });
  if (a === 'cloudsave') return cloudSave(true);
  if (a === 'stats') return ME ? openStats() : openLogin();
  if (a === 'langmenu') return langMenu();
  if (a === 'qstop') { stopQueue(); return toast(T('q_stopped')); }
  if (a === 'ref') return openRef();
  if (a === 'refset') return ask(T('rf_ask'), function (c) { api('ref_set', { code: c }, function (r) { if (!r.ok) return toast(r.msg || 'Xato'); ME = r.me; toast(T('rf_ok'), 5000); openRef(); renderBar(); }); });
  if (a === 'srvpw') { if (srvSel) openPw(srvSel); return; }
  if (a === 'pwsave' || a === 'pwdel') { if (PW_IP) pwSave(PW_IP, a === 'pwdel'); return; }
  if (a === 'clan') return openClan();
  if (a === 'clancreate') return ask(T('cl_ask'), function (n, t) { clanCall('clan_create', { name: n, tag: t }); }, true);
  if (a === 'clanjoin') return ask(T('cl_askcode'), function (c) { clanCall('clan_join', { code: c }); });
  if (a === 'clanleave') return ask(T('cl_askleave'), function () { clanCall('clan_leave'); }, false, false, true);
  if (a === 'cloudget') return api('me', {}, function (r) { if (!r.ok) return; ME = r.me; restoreCloud(r.me.cloud); if (curModal === 'mdSettings') { seedFromGame(); E = copy(S); showSetTab('account'); } });
  if (a === 'logout') { api('logout', {}); DB.token = ''; ME = null; FRIENDS = []; persist(); closeModal(); return renderAll(); }
  if (a === 'defaults') { var keep = E.name, tag = E.tag; E = copy(DEF); E.name = keep; E.tag = tag; return showSetTab(setTab); }
  if (a === 'save') {
    var nm = $('fName'); if (nm) E.name = nm.value.replace(/["\\;]/g, '').slice(0, 28);
    S = copy(E); DB.set = S; persist(); applySettings(S); closeModal(); renderBar(); cloudSave(); setTimeout(musicSync, 300);
    setTimeout(function () { verifySettings(S); }, 700);
  }
}

/* ============================================================ hodisalar */
/* ---- menyu musiqasi: CS ning o'z menyu kuyi (media/gamestartup.mp3), faqat serverda bo'lmaganda ---- */
var MUSIC_ON = null;                             // null - noma'lum: oldingi sahifa (menyu yangilangan) qoldirgan musiqa ham o'chirilsin
/* Menyu musiqasi: bosh menyuda va o'yin ichida ESC bosilganda ham chaladi. ESC menyusi ochiq turganda o'yin ovozi
 * (otishmalar) o'chiriladi, o'yinga qaytilganda ('hide') musiqa to'xtaydi va o'yin ovozi qaytadi.
 * Menyu musiqasining balandligi alohida (MVOL) - serverlar chaladigan mp3 balandligi (S.mus) o'zgarmaydi */
/* o'yin vaqti eslatmasi (Sozlamalar > O'yin, standart o'chiq): o'yin jarayoni boshlangandan (sessionStorage - menyu qayta
 * yuklansa ham saqlanadi) 2 soat o'tib, keyin har soatda - ESC bosilganda yoki ulanganda qisqa yozuv */
function restCheck() {
  if (!S || !S.rest || !CONNECTED) return;
  var t0 = 0, nx = 2;
  try { t0 = +sessionStorage.getItem('xcpt') || 0; nx = +sessionStorage.getItem('xcpn') || 2; if (!t0) { t0 = now(); sessionStorage.setItem('xcpt', String(t0)); } } catch (e) { return; }
  var hrs = (now() - t0) / 36e5;
  if (hrs < nx) return;
  try { sessionStorage.setItem('xcpn', String(Math.floor(hrs) + 1)); } catch (e) {}
  toast(T('rest_msg').replace('{h}', Math.floor(hrs)), 10000);
}
var MVOL = 0.85, GMUTE = false, ESC_OPEN = false;   // ESC_OPEN - serverda 'show' hodisasi kelgan (o'yin ustida menyu ochiq)
/* ehtiyot: 'hide' hodisasi kelmay qolsa ham o'yin ovozi jim qolib ketmasin (3 soniyada bir, faqat holat tekshiriladi) */

function gameVol() { return S && S.vol != null ? S.vol : 0.8; }
function musicSync() {
  /* menyu musiqasi va ESC da o'yin ovozini o'chirish olib tashlandi (egasining so'rovi): faqat oldingi versiyadan qolgan holatni tozalaymiz */
  if (MUSIC_ON !== false) { cmd('mp3 stop'); cmd('mp3volume ' + (S && S.mp3off ? 0 : (S ? S.mus : 0.4))); MUSIC_ON = false; }
  if (GMUTE) { cmd('volume ' + gameVol()); GMUTE = false; }
}

/* ---- internet tekshiruvi: bir nechta serverga 3 martadan so'rov - ping, tebranish, yo'qotish -> mos rate ---- */
var NETT = null, NETT_RUN = false;
function netTest() {
  if (NETT_RUN) return;
  if (CONNECTED) return toast(T('nt_ingame'), 4500);
  if (!hasMM()) return toast(T('nt_na'), 4000);
  var ips = [], i, j, res = [], jobs = [];
  each(PINNED.concat(TOP), function (ip) { if (ips.length < 5 && ips.indexOf(ip) < 0) ips.push(ip); });
  for (j = 0; j < 3; j++) for (i = 0; i < ips.length; i++) jobs.push(ips[i]);
  NETT_RUN = true; NETT = null; showSetTab('pro'); toast(T('nt_run'), 5000);
  function next() {
    if (!jobs.length) return finish();
    var ip = jobs.shift(), t0 = now(), done = false;
    var tm = setTimeout(function () { if (done) return; done = true; res.push(-1); setTimeout(next, 120); }, 2500);
    try {
      NC.matchmaking.getServerInfo(ip).then(function () { if (done) return; done = true; clearTimeout(tm); res.push(now() - t0); setTimeout(next, 120); },
        function () { if (done) return; done = true; clearTimeout(tm); res.push(-1); setTimeout(next, 120); });
    } catch (e) { done = true; clearTimeout(tm); res.push(-1); setTimeout(next, 120); }
  }
  function finish() {
    var ok = [], sum = 0, jit = 0, k;
    for (k = 0; k < res.length; k++) if (res[k] >= 0) { ok.push(res[k]); sum += res[k]; }
    var loss = res.length ? Math.round((res.length - ok.length) * 100 / res.length) : 100;
    var avg = ok.length ? Math.round(sum / ok.length) : 0, best = ok.length ? Math.min.apply(null, ok) : 0;
    for (k = 0; k < ok.length; k++) jit += Math.abs(ok[k] - avg);
    jit = ok.length ? Math.round(jit / ok.length) : 0;
    var rec = (!ok.length || loss > 10 || best > 150) ? { net: 'slow', interp: 0.1 } : (loss > 2 || jit > 30 || best > 80) ? { net: 'mid', interp: 0.05 } : { net: 'fast', interp: 0.01 };
    NETT = { best: best, avg: avg, jit: jit, loss: loss, rec: rec }; NETT_RUN = false;
    if (curModal === 'mdSettings' && setTab === 'pro') showSetTab('pro');
    toast(T('nt_done').replace('{p}', best).replace('{l}', loss), 5000);
  }
  next();
}

/* ---- "Nima yangi": admin panelda yozilgan yangiliklar - har yangisini bir marta ko'rsatamiz ---- */
function loadWhatsNew() {
  api('whatsnew', {}, function (r) {
    if (!r.ok || !r.w || !r.w.id || DB.wnSeen === r.w.id || !r.w.items || !r.w.items.length) return;
    if (DB.dnd) { DB.wnSeen = r.w.id; persist(); return; }               // "Bezovta qilmaslik"
    if (curModal) return setTimeout(loadWhatsNew, 30000);              // boshqa oyna ochiq - keyinroq
    var h = '<div class="wn">' + (r.w.ver ? '<div class="mut">' + esc(r.w.ver) + '</div>' : '') + '<ul>';
    each(r.w.items, function (x) { h += '<li>' + esc(x) + '</li>'; });
    openSide('whatsnew', r.w.title || T('wn_title'), h + '</ul></div>');
    DB.wnSeen = r.w.id; persist();
  });
}

/* ---- kunlik vazifalar: ro'yxat serverdan, bajarilishi o'yin tarixidan ---- */
var MIS = null;
function misProgress(m) {
  // sayt hisoblagani (u mukofotni ham shunga qarab beradi); eski sayt javobida yo'q bo'lsa - o'yin tarixidan
  if (MIS && MIS.prog && MIS.prog[m.id] != null) return Math.min(m.goal, MIS.prog[m.id] | 0);
  var today = new Date().toDateString(), v = 0, set = {}, k = 0, x = 0;
  each(DB.hist || [], function (h) {
    if (new Date(h.t).toDateString() !== today) return;
    var d = h.d || 0;
    if (m.id === 'min') v += d / 60;
    else if (m.id === 'kills') v += h.k || 0;
    else if (m.id === 'servers') set[h.ip] = 1;
    else if (m.id === 'maps') { if (h.map) set[h.map] = 1; }
    else if (m.id === 'xsrv') { if (PINNED.indexOf(h.ip) >= 0 || /x\s*client/i.test(h.name || '')) v += d / 60; }
    else if (m.id === 'kd') { k += h.k || 0; x += h.x || 0; }
  });
  if (m.id === 'servers' || m.id === 'maps') { for (var s2 in set) if (set.hasOwnProperty(s2)) v++; }
  if (m.id === 'kd') v = (x === 0 || k / x >= 1) ? k : 0;           // K/D 1 dan yuqori bo'lgandagina hisoblanadi
  return Math.min(m.goal, Math.floor(v));
}
/* bajarilgan, lekin hali olinmagan vazifalar soni - chap menyuda belgi (o'yinchi "Vazifalar" ni ochishni unutmasin) */
function misBadge(r) {
  var n = 0;
  if (r && r.list) each(r.list, function (m) { MIS = r; if (r.done.indexOf(m.id) < 0 && misProgress(m) >= m.goal) n++; });
  var e = $('mMis'); if (e) { e.style.display = n ? '' : 'none'; e.innerHTML = n ? String(n) : ''; }
}
function misCheck() { if (!ME || LITE) return; api('missions', {}, function (r) { if (r && r.ok) misBadge(r); }); }
function openMissions() {
  if (!ME) return openSide('missions', T('ms_title'), '<div class="empty">' + esc(T('ms_login')) + '</div><a class="btn red" data-act="login" style="margin-top:12px">' + esc(T('a_login')) + '</a>');
  api('missions', {}, function (r) {
    if (!r.ok) return toast(r.msg || 'Xato');
    MIS = r; renderMissions(); misBadge(r);
  });
}
function renderMissions() {
  if (!MIS) return;
  var h = '<div class="mis">', ny = MIS.ny;
  if (ny) {                                        // Yangi yil iventi: XP x1.5, 5 vazifa - cheklangan ramka
    var left = Math.max(0, Math.ceil((ny.end - ny.now) / 86400)), nn = Math.min(ny.n || 0, ny.goal);
    h += '<div class="nyev"><div class="nyh">' + ico('gift') + ' ' + esc(T('ny_t').replace('{y}', ny.y)) + '<span>' + esc(T('ny_left').replace('{d}', left)) + '</span></div>' +
      '<div class="nyb"><i class="av fny">' + avInner(ME) + '</i><div><b>' + esc(T(ny.has ? 'ny_has' : 'ny_goal').replace('{g}', ny.goal)) + '</b>' +
      '<div class="xpw"><i style="width:' + Math.round(nn * 100 / ny.goal) + '%"></i></div><small>' + nn + ' / ' + ny.goal + ' \u00b7 ' + esc(T('ny_x15')) + '</small></div></div></div>';
  }
  each(MIS.list, function (m) {
    var p = misProgress(m), done = MIS.done.indexOf(m.id) >= 0, full = p >= m.goal;
    h += '<div class="msr' + (done ? ' got' : '') + '"><b>' + esc(T('ms_' + m.id).replace('{n}', m.goal)) + '</b><span class="gr">+' + m.xp + ' XP</span>' +
      '<div class="xpw"><i style="width:' + Math.round(p * 100 / m.goal) + '%"></i></div><small>' + p + ' / ' + m.goal + '</small>' +
      (done ? '<em>\u2713 ' + esc(T('ms_got')) + '</em>' : full ? '<a class="btn red" data-misclaim="' + esc(m.id) + '">' + esc(T('ms_claim')) + '</a>' : '') + '</div>';
  });
  h += '<div class="mut" style="font-size:12px;margin-top:10px">' + esc(T('ms_note')) + '</div></div>';
  openSide('missions', T('ms_title'), h);
}

/* ---- admin yuborgan shaxsiy xabarlar ---- */
function showAdminMsgs(list) {
  if (!list || !list.length) return;
  var h = '';
  each(list, function (m) { h += '<div class="amsg"><div>' + esc(m.text) + '</div><small class="mut">' + esc(fmtTime(m.t * 1000)) + '</small></div>'; });
  openSide('amsg', T('am_title'), h);
}

/* ---- qaysi tugmalar bosiladi (admin panel > Tugmalar): 2 daqiqada bir yuboriladi ---- */
var CLK = {}, CLK_N = 0;
document.addEventListener('mousedown', function (e) {
  for (var el = e.target; el && el !== document; el = el.parentNode) {
    if (!el.getAttribute) continue;
    var a = el.getAttribute('data-act') || (el.getAttribute('data-tab') ? 'tab:' + el.getAttribute('data-tab') : '') || (el.getAttribute('data-ip') ? 'connect' : '') || (el.getAttribute('data-ring') ? 'ring' : '') || (el.getAttribute('data-frprof') ? 'frprof' : '');
    if (a) { CLK[a] = (CLK[a] || 0) + 1; CLK_N++; return; }
  }
}, true);
setInterval(function () { if (!CLK_N || !feat('clicks') || playing()) return; var c = CLK; CLK = {}; CLK_N = 0; api('clicks', { c: JSON.stringify(c) }, function () {}); }, 120000);

/* ---- menyu ovozlari: o'yin sound/xclient/*.wav ni chaladi (XCLauncher.exe ularni o'yin papkasiga qo'yadi) ---- */
var SFX_ATTR = ['data-act', 'data-tab', 'data-hsub', 'data-seg', 'data-tg', 'data-otg', 'data-ohud', 'data-dd', 'data-ddv', 'data-xchk', 'data-pack',
  'data-sort', 'data-flt', 'data-theme', 'data-daymode', 'data-lang', 'data-prload', 'data-prsave', 'data-style', 'data-calc', 'data-avc', 'data-demo', 'data-dctl', 'data-ovq', 'data-ovf', 'data-vseg', 'data-dsel', 'data-vopen', 'data-vdel', 'data-vfold', 'data-vopt', 'data-vtrim', 'data-vshare', 'data-vlink', 'data-orsk', 'data-copyip', 'data-chat', 'data-fradd2', 'data-fracc', 'data-frdec', 'data-avpre'];
var SFX_QUIET = false, sfxLast = null, sfxT = 0;
/* CS 1.6 ning asl menyu ovozlari (o'yinning o'z fayllari: valve/sound/UI) - standart. Sozlamalarda X CLIENT ovozlariga almashtirsa bo'ladi */
var SFX_CS = { hover: 'ui/buttonrollover.wav', click: 'ui/buttonclick.wav', tab: 'ui/buttonclick.wav', on: 'ui/buttonclick.wav', off: 'ui/buttonclickrelease.wav',
  save: 'ui/buttonclick.wav', open: 'ui/buttonclickrelease.wav', close: 'ui/buttonclickrelease.wav' };
function sfx(n) {
  if (!S || S.uisnd === 0 || !hasApi()) return;
  var t = now();
  if (n === 'hover' && (DB.dnd || t - sfxT < 45)) return;
  sfxT = t; cmd('play xclient/' + n + '.wav');   // asl X CLIENT menyu ovozlari
}
function sfxTarget(el) {
  for (; el && el !== document; el = el.parentNode) {
    if (!el.getAttribute) continue;
    for (var i = 0; i < SFX_ATTR.length; i++) if (el.getAttribute(SFX_ATTR[i]) != null) return el;
    if (/(^| )(mi|btn|sr)( |$)/.test(el.className || '')) return el;
  }
  return null;
}
document.addEventListener('mouseover', function (e) { var el = sfxTarget(e.target); if (el && el !== sfxLast) sfx('hover'); sfxLast = el; }, true);
document.addEventListener('mousedown', function (e) {
  var el = sfxTarget(e.target);
  if (!el) return;
  var a = el.getAttribute('data-act');
  if (a === 'close' || /(^| )mi( |$)/.test(el.className || '')) return;            // oyna ochilish/yopilish ovozi o'zi chalinadi
  if (el.getAttribute('data-tg') != null || el.getAttribute('data-otg') != null || el.getAttribute('data-xchk') != null || el.getAttribute('data-pack') != null)
    return sfx(/(^| )on( |$)/.test(el.className || '') ? 'off' : 'on');
  if (el.getAttribute('data-tab') != null || el.getAttribute('data-hsub') != null) return sfx('tab');
  sfx(a === 'save' ? 'save' : 'click');
}, true);
document.onclick = function (e) {
  var t = e.target || e.srcElement, el;
  if (t && t.id === 'lgRemember' || (t && t.parentNode && t.parentNode.id === 'lgRemember')) { var cb = $('lgRemember'); cb.className = cb.className.indexOf('on') >= 0 ? 'cb' : 'cb on'; return; }
  if ((el = closest(t, 'data-ddv'))) { ddPick(el.getAttribute('data-ddv')); return; }
  if ((el = closest(t, 'data-dd'))) { ddOpen(el); return; }
  if (DD) ddClose();
  if ((el = closest(t, 'data-bind'))) { var ka = el.getAttribute('data-bind'); KEYWAIT = KEYWAIT === ka && KEYSLOT === 1 ? '' : ka; KEYSLOT = 1; showSetTab('keys'); return; }
  if ((el = closest(t, 'data-bind2'))) { var kb = el.getAttribute('data-bind2'); KEYWAIT = KEYWAIT === kb && KEYSLOT === 2 ? '' : kb; KEYSLOT = 2; showSetTab('keys'); return; }
  if ((el = closest(t, 'data-fav'))) { toggleFav(el.getAttribute('data-fav')); return; }
  if ((el = closest(t, 'data-inv'))) { api('invite', { to: el.getAttribute('data-inv'), ip: CONNECTED }, function (r) { toast(r.ok ? T('iv_sent') : (r.msg || 'Xato')); }); return; }
  if ((el = closest(t, 'data-avpre'))) { toast(T('lg_wait')); api('avatar', { preset: el.getAttribute('data-avpre') }, function (r) { if (!r.ok) return toast(r.msg || 'Xato'); setMe(r.me); toast(T('saved')); closeModal(); openSettings('account'); }); return; }
  if ((el = closest(t, 'data-fradd2'))) { frAdd(el.getAttribute('data-fradd2')); return; }
  if ((el = closest(t, 'data-fracc'))) { frAdd(el.getAttribute('data-fracc')); return; }
  if ((el = closest(t, 'data-frdec'))) { api('friend_decline', { login: el.getAttribute('data-frdec') }, function () { loadFriends(); }); return; }
  if ((el = closest(t, 'data-chat'))) { openChat(el.getAttribute('data-chat'), el.getAttribute('data-chatn')); return; }
  if ((el = closest(t, 'data-frprof'))) return openFrProfile(el.getAttribute('data-frprof'));
  if ((el = closest(t, 'data-duelp'))) { var dl = el.getAttribute('data-duelp'), dn = el.getAttribute('data-dueln');
    openSide('duel', T('du_title'), '<div class="dupick"><p>' + esc(T('du_how').replace('{n}', dn)) + '</p>' + [5, 10, 15].map(function (m) { return '<a class="btn red" data-duelgo="' + esc(dl) + '" data-duelm="' + m + '">' + m + ' ' + esc(T('du_min')) + '</a>'; }).join('') + '</div>'); return; }
  if ((el = closest(t, 'data-duelgo'))) { api('duel_req', { to: el.getAttribute('data-duelgo'), mins: el.getAttribute('data-duelm') }, function (r) { if (!r.ok) return toast(r.msg || 'Xato', 5000); closeModal(); toast(T('du_sent'), 6000); }); return; }
  if ((el = closest(t, 'data-duelok'))) { duelAnswer(el.getAttribute('data-duelok') === '1'); return; }
  if ((el = closest(t, 'data-equipnc'))) { api('equip', { nc: el.getAttribute('data-equipnc') }, function (r) { if (!r.ok) return toast(r.msg || 'Xato', 5000); ME = r.me; renderBar(); openChests(true); }); return; }
  if ((el = closest(t, 'data-equipfr'))) { api('equip', { frame: el.getAttribute('data-equipfr') }, function (r) { if (!r.ok) return toast(r.msg || 'Xato', 5000); ME = r.me; renderBar(); openChests(true); }); return; }
  if ((el = closest(t, 'data-bgs'))) { DB.bgs = el.getAttribute('data-bgs'); persist(); applyBg(); showSetTab('system'); return; }
  if ((el = closest(t, 'data-ptc'))) { DB.ptc = el.getAttribute('data-ptc'); persist(); applyBg(); showSetTab('system'); return; }
  if ((el = closest(t, 'data-fs'))) { DB.fs = Number(el.getAttribute('data-fs')); persist(); applyTheme(DB.theme || 'red'); showSetTab('system'); return; }
  if ((el = closest(t, 'data-lgsug'))) { $('lgLogin').value = el.getAttribute('data-lgsug'); lgCheck(); try { $('lgPass').focus(); } catch (e3) {} return; }
  if ((el = closest(t, 'data-wallsend'))) { var wto = el.getAttribute('data-wallsend'), wv = clean($('wlIn') ? $('wlIn').value : ''); if (!wv) return; api('wall_add', { to: wto, text: wv }, function (r) { if (!r.ok) return toast(r.msg || 'Xato'); openFrProfile(wto); }); return; }
  if ((el = closest(t, 'data-walldel'))) { var wt2 = el.getAttribute('data-wallto'); api('wall_del', { to: wt2, id: el.getAttribute('data-walldel') }, function () { openFrProfile(wt2); }); return; }
  if ((el = closest(t, 'data-xgal'))) { if (applyCode(el.getAttribute('data-xgal'))) { if (typeof xLive === 'function') xLive(); showSetTab('hud'); toast(T('xg_ok'), 3000); } return; }
  if ((el = closest(t, 'data-cfguse'))) { cfgUse(el.getAttribute('data-cfguse')); return; }
  if ((el = closest(t, 'data-cfglike'))) { var lk = el; api('cfg_like', { code: el.getAttribute('data-cfglike') }, function (r) { if (!r.ok) return toast(r.msg || 'Xato'); lk.innerHTML = '\u2665 ' + r.likes; lk.className = 'btn on'; }); return; }
  if ((el = closest(t, 'data-ring'))) { var rl = el.getAttribute('data-ring'); api('ring', { to: rl, srv: CONNECTED || '' }, function (r) { toast(r.ok ? T('rg_calling') : (r.msg || 'Xato'), 6000); }); return; }
  if ((el = closest(t, 'data-ringok'))) { ringAnswer(el.getAttribute('data-ringok') === '1'); return; }
  if ((el = closest(t, 'data-mcall'))) { var mc = el; api('miss_call', { to: el.getAttribute('data-mcall') }, function (r) { toast(r.ok ? T('mc_ok') : (r.msg || 'Xato'), 5000); if (r.ok && mc.parentNode) mc.parentNode.removeChild(mc); }); return; }
  if ((el = closest(t, 'data-fbk'))) { FBK = el.getAttribute('data-fbk'); var sib = el.parentNode.childNodes; for (var fi = 0; fi < sib.length; fi++) sib[fi].className = sib[fi] === el ? 'on' : ''; return; }
  if ((el = closest(t, 'data-frdel'))) { api('friend_del', { login: el.getAttribute('data-frdel') }, function () { loadFriends(); }); return; }
  if ((el = closest(t, 'data-bmap')) || (el = closest(t, 'data-bn')) || (el = closest(t, 'data-bd')) || (el = closest(t, 'data-bm')) || (el = closest(t, 'data-blan'))) {
    DB.bots = DB.bots || {};
    if (el.getAttribute('data-blan')) { DB.bots.lan = DB.bots.lan === 0 ? 1 : 0; persist(); botsPane(); return; }
    if (el.getAttribute('data-bm')) { DB.bots.m = el.getAttribute('data-bm'); persist(); botsPane(); return; }
    if (el.getAttribute('data-bmap')) DB.bots.map = el.getAttribute('data-bmap');
    else if (el.getAttribute('data-bn')) DB.bots.n = +el.getAttribute('data-bn');
    else DB.bots.d = +el.getAttribute('data-bd');
    persist(); botsPane(); return;
  }
  if ((el = closest(t, 'data-fq'))) { var fk = el.getAttribute('data-fq'); api('feedback', { text: 'Birinchi o\'yin: ' + fk + ' - ' + T('fq_' + fk), kind: 'first', nick: MYNAME || (S && S.name) || '', ver: VERSION }, function () {}); closeModal(); if (fk === 'lag') { api('gperf', { lag: 1 }, function () {}); lagFixPane(LASTPERF && (LASTPERF.pm >= 120 || LASTPERF.l >= 10) ? T('pf_was').replace('{p}', LASTPERF.pm).replace('{l}', LASTPERF.l) : ''); return; } toast(T(fk === 'good' ? 'fq_thx_g' : 'fq_thx'), 6000); return; }
  if ((el = closest(t, 'data-dbtg'))) { var dk = el.getAttribute('data-dbtg'); var cur = dk === 'fx' ? (DB.fx !== 0 && !FX.off) : (dk === 'autosave' || dk === 'dnd' ? !!DB[dk] : DB[dk] !== 0); DB[dk] = cur ? 0 : 1; persist(); if (dk === 'fx') { FX.off = 0; FX.slow = 0; sparks(); heroLoad(); } if (dk === 'hol') applyBg(); if (dk === 'autosave') $('setNote').innerHTML = esc(ME && DB.autosave ? T('note_cloud') : T('note_local')); el.className = 'tg' + (DB[dk] ? ' on' : ''); return; }
  if ((el = closest(t, 'data-misclaim'))) {
    var mid = el.getAttribute('data-misclaim');
    sendStat(null, function () { api('mission_claim', { id: mid }, function (r) {   // sayt bajarilganini o'zi tekshiradi - oxirgi o'yin natijasi avval yetib borsin
      if (!r.ok) return toast(r.err === 'notyet' ? T('ms_notyet') : (r.msg || 'Xato'), 5000);
      if (ME) { ME.xp = r.xp; ME.level = r.level; ME.lvlxp = r.lvlxp; renderBar(); }
      if (r.ny && MIS.ny) { MIS.ny.n = r.ny.n; if (r.ny.got) { MIS.ny.has = true; if (ME) { ME.inv = ME.inv || { nc: [], fr: [] }; (ME.inv.fr = ME.inv.fr || []).push('fny'); } } }
      MIS.done.push(mid); renderMissions(); toast(T('ms_ok').replace('{n}', r.got), 4000);
      if (r.ny && r.ny.got) setTimeout(function () { toast(T('ny_got'), 9000); chime(); }, 1500);
    }); });
    return;
  }
  if ((el = closest(t, 'data-orsk'))) {            // klassik radar foni: launcher sprites/radaropaque640.spr ni almashtiradi
    var rv = Number(el.getAttribute('data-orsk')); OPTS.rsk = rv; OPTS.rskx = 1;
    var rt2 = rv ? 1 : 0; S.radar = rt2; if (E) E.radar = rt2; DB.set = S; persist(); cmd('cl_radartype ' + rt2);
    showSetTab('hud');
    if (!PCID) return toast(T('sy_nolaunch'), 4000);
    api('opts_set', { d: PCID, o: JSON.stringify(OPTS) }, function (r) { if (r.ok) { vidCmd('opt', '', null, true); toast(T('rk_ok'), 6000); } else toast(r.msg || 'Xato', 3500); });
    return;
  }
  if ((el = closest(t, 'data-ohud'))) { OPTS.hud = Number(el.getAttribute('data-ohud')); saveOpts(T('h_size4')); showSetTab('hud'); return; }
  if ((el = closest(t, 'data-vseg'))) { var vk = el.getAttribute('data-vseg'), vv = el.getAttribute('data-v');
    if (vk === 'ar') { DB.ar = vv; persist(); if (OPTS.res && resAr(OPTS.res) !== vv) { OPTS.res = ''; saveOpts(T('v_rs2')); } }
    else { OPTS.win = +vv; OPTS.winx = 1; saveOpts(T('v_rs2')); }
    showSetTab('video'); return; }
  if ((el = closest(t, 'data-otg'))) { var ok2 = el.getAttribute('data-otg'); OPTS[ok2] = OPTS[ok2] ? 0 : 1; el.className = 'tg' + (OPTS[ok2] ? ' on' : ''); saveOpts(/^(tune|macc|bgp)$/.test(ok2) ? T('tn_next') : ''); if (ok2 === 'tune') showSetTab('pro'); return; }
  if ((el = closest(t, 'data-tg'))) { var k = el.getAttribute('data-tg'); E[k] = E[k] ? 0 : 1; if (k === 'hdm') E.hdmx = 1; el.className = 'tg' + (E[k] ? ' on' : ''); if (setTab === 'hud') { drawXhair(); var cd = $('xCode'); if (cd) cd.value = xcode(E); } return; }
  if ((el = closest(t, 'data-avc'))) { api('avatar', { color: el.getAttribute('data-avc') }, function (r) { if (!r.ok) return toast(r.msg); setMe(r.me); showSetTab('account'); }); return; }
  if ((el = closest(t, 'data-newsip')) && el.getAttribute('data-newsip')) { sfx('click'); return doConnect(el.getAttribute('data-newsip')); }
  if ((el = closest(t, 'data-daymode'))) return dayToggle();
  if ((el = closest(t, 'data-theme'))) { DB.theme = el.getAttribute('data-theme'); persist(); cloudSave(); applyTheme(DB.theme); if (curModal === 'mdSettings') showSetTab('cont'); return; }
  if ((el = closest(t, 'data-pack'))) {
    var pid = el.getAttribute('data-pack'), pl = (OPTS.packs ? OPTS.packs.split(',') : []), pix = pl.indexOf(pid);
    if (pix >= 0) pl.splice(pix, 1); else pl.push(pid);
    OPTS.packs = pl.join(','); el.className = 'tg' + (pix >= 0 ? '' : ' on'); saveOpts(); return;
  }
  if ((el = closest(t, 'data-shdel'))) { api('shot_del', { d: PCID, f: el.getAttribute('data-shdel') }, function () { act('gallery'); }); return; }
  if ((el = closest(t, 'data-prsave'))) { profSave(Number(el.getAttribute('data-prsave'))); showSetTab('tools'); return; }
  if ((el = closest(t, 'data-prload'))) { profLoad(Number(el.getAttribute('data-prload'))); showSetTab('tools'); return; }
  if ((el = closest(t, 'data-pren'))) {
    var pi = Number(el.getAttribute('data-pren'));
    ask(T('pf_rename'), function (v) {
      v = String(v || '').replace(/[<>"]/g, '').slice(0, 20); if (!v) return;
      var pp = DB.profiles || []; if (!pp[pi]) pp[pi] = { n: v, t: 0 }; else pp[pi].n = v;
      DB.profiles = pp; persist(); showSetTab('tools');
    });
    return;
  }
  if ((el = closest(t, 'data-calc'))) { var ci = $('calcIn'); if (ci) CALC_V = ci.value; CALC = el.getAttribute('data-calc'); showSetTab('tools'); return; }
  if ((el = closest(t, 'data-style'))) { applyStyle(el.getAttribute('data-style')); return; }
  if (t && t.className === 'ipin') { t.select(); return; }
  if ((el = closest(t, 'data-frcmp'))) { openCompare(el.getAttribute('data-frcmp')); return; }
  if ((el = closest(t, 'data-clkick'))) { clanCall('clan_kick', { who: el.getAttribute('data-clkick') }); return; }
  if ((el = closest(t, 'data-copyip'))) { copyIp(el.getAttribute('data-copyip'), el.parentNode.querySelector('input')); return; }
  if ((el = closest(t, 'data-ovf'))) { OPTS = OPTS || {}; OPTS.vf = el.getAttribute('data-ovf'); saveOpts(T('vf_ok')); showSetTab('demo'); return; }
  if ((el = closest(t, 'data-ovq'))) { OPTS = OPTS || {}; OPTS.vq = el.getAttribute('data-ovq'); OPTS.vqx = 1; saveOpts(T('vq_ok')); showSetTab('demo'); return; }
  if ((el = closest(t, 'data-cheat'))) { cheatPane(el.getAttribute('data-cheat')); return; }
  if ((el = closest(t, 'data-chwhy'))) { cheatSend(el.getAttribute('data-chwhy')); return; }
  if ((el = closest(t, 'data-utg'))) { openLink('utg', el.getAttribute('data-utg')); return; }
  if ((el = closest(t, 'data-vopen'))) { vidCmd('open', el.getAttribute('data-vopen')); return; }
  if ((el = closest(t, 'data-vdel'))) { var vn = el.getAttribute('data-vdel'); ask(T('vd_delq'), function () { vidCmd('del', vn); }, false, false, true); return; }
  if ((el = closest(t, 'data-vfold'))) { vidCmd('folder', ''); return; }
  if ((el = closest(t, 'data-sopen'))) { vidCmd('sopen', el.getAttribute('data-sopen')); return; }
  if ((el = closest(t, 'data-sdel'))) { var sn = el.getAttribute('data-sdel'); ask(T('ss_delq'), function () { vidCmd('sdel', sn); }, false, false, true); return; }
  if ((el = closest(t, 'data-sfold'))) { vidCmd('sfold', ''); return; }
  if ((el = closest(t, 'data-vshare'))) {          // klipni saytga va Telegram kanalga
    var vsn = el.getAttribute('data-vshare');
    if (!ME) return toast(T('vs_login'), 5000);
    var vmb = Number(el.getAttribute('data-vmb')) || 0;
    if (el.getAttribute('data-vsh') === 'l') return toast(T('vs_long'), 9000);   // oldingi urinish: juda uzun
    if (vmb >= 60 && !verGE(VERSION, '1.0.94')) return toast(T('vs_big').replace('{n}', vmb), 8000);   // eski launcher kichraytira olmaydi
    if (vmb > 45) toast(T('vs_bigok'), 7000);
    return ask(T('vs_ask'), function () {
      vidCmd('share', vsn, { srv: CONNECTED ? (srv(CONNECTED).name || CONNECTED) : '' });   // xato bo'lsa (kunlik chegara, qayta kirish) - sababi ko'rinadi
      each([6000, 20000, 45000, 90000, 150000], function (ms) { setTimeout(function () { VIDS_T = 0; vidsRefresh(); }, ms); });
    }, false, false, true);
  }
  if ((el = closest(t, 'data-vlink'))) {
    var url = 'https://mmb.boost-top.com/clips.php?v=' + el.getAttribute('data-vlink');
    copyIp(url, null); return;
  }
  if ((el = closest(t, 'data-vopt'))) {
    var vk = el.getAttribute('data-vopt');
    if (vk === 'gsum') { DB.gsum = DB.gsum === 0 ? 1 : 0; persist(); showSetTab('demo'); return; }
    if (vk === 'acl') { DB.acl = DB.acl === 0 ? 1 : 0; persist(); showSetTab('demo'); return; }
    if (vk === 'rb') { OPTS.rb = rbOn() ? 0 : 1; OPTS.rbx = 1; } else OPTS[vk] = OPTS[vk] ? 0 : 1;
    showSetTab('demo');
    if (!PCID) { toast(T('sy_nolaunch'), 4000); return; }
    api('opts_set', { d: PCID, o: JSON.stringify(OPTS) }, function (r) { if (r.ok) vidCmd('opt', '', null, false); else toast(r.msg || 'Xato', 3500); });   // launcher darhol qo'llaydi
    return;
  }
  if ((el = closest(t, 'data-vtrim'))) { vidCmd('edit', el.getAttribute('data-vtrim')); return; }   // launcher muharrir oynasini ochadi (o'yin yig'iladi)
  if ((el = closest(t, 'data-dctl'))) { demoCtl(el.getAttribute('data-dctl')); return; }
  if ((el = closest(t, 'data-demo'))) { closeModal(); demoPlay(el.getAttribute('data-demo')); return; }
  if ((el = closest(t, 'data-dsel'))) { DEMO_SEL = el.getAttribute('data-dsel'); showSetTab('demo'); return; }   // qatorni bosish - pleyerda tanlash (▶ tugmasi yuqorida ushlanadi)
  if ((el = closest(t, 'data-hsub'))) { HSUB = el.getAttribute('data-hsub'); showSetTab('hud'); return; }
  if ((el = closest(t, 'data-xchk'))) {
    var xk = el.getAttribute('data-xchk'), XT = { dot: 3, t: 1, circle: 2 };
    if (xk === 'dyn') E.xdyn = E.xdyn ? 0 : 1;
    else E.xt = Number(E.xt) === XT[xk] ? 0 : XT[xk];
    E.xp = presetOf(E); showSetTab('hud'); return;
  }
  if ((el = closest(t, 'data-xpre'))) {
    var id = el.getAttribute('data-xpre');
    each(XPRE, function (p) { if (p[0] === id) { E.xp = id; E.xt = p[2]; E.xs = p[3]; } });
    showSetTab('hud'); return;
  }
  if ((el = closest(t, 'data-seg'))) {
    var key = el.getAttribute('data-seg'), v = el.getAttribute('data-v');
    E[key] = (typeof DEF[key] === 'number') ? Number(v) : v;
    if (key === 'xs') E.xp = presetOf(E);
    showSetTab(setTab); return;
  }
  if ((el = closest(t, 'data-lang'))) { DB.lang = el.getAttribute('data-lang'); persist(); cloudSave(); setLang(DB.lang); var lp = $('lngpop'); if (lp) lp.parentNode.removeChild(lp); if (curModal === 'mdSettings') showSetTab('system'); return; }
  if ((el = closest(t, 'data-tab'))) { if (curModal === 'mdServers') setSrvTab(el.getAttribute('data-tab')); else showSetTab(el.getAttribute('data-tab')); return; }
  if ((el = closest(t, 'data-flt'))) { var f = el.getAttribute('data-flt'); FLT[f] = !FLT[f]; renderServers(); return; }
  if ((el = closest(t, 'data-sort'))) { var so = el.getAttribute('data-sort'); if (SORT_USER && srvSort === so) srvDesc = !srvDesc; else { srvSort = so; srvDesc = so === 'pl'; } SORT_USER = true; renderServers(); return; }
  if ((el = closest(t, 'data-act'))) { ACT_EL = el; act(el.getAttribute('data-act')); ACT_EL = null; return; }
  if ((el = closest(t, 'data-ip'))) {
    var ip = el.getAttribute('data-ip');
    if (el.className.indexOf('sr') === 0) { srvSel = ip; loadPlayers(ip); query(ip, true); renderServers(); }
    else { closeModal(); connect(ip); }
    return;
  }
  if (t && t.className === 'modal on' && t.id !== 'mdAsk') closeModal();
};
document.ondblclick = function (e) {
  var el = closest(e.target || e.srcElement, 'data-ip');
  if (el && el.className.indexOf('sr') === 0) { closeModal(); connect(el.getAttribute('data-ip')); }
};
function onSlide(e) {
  var t = e.target || e.srcElement;
  if (t && t.getAttribute && t.getAttribute('data-xsz')) {
    var i = Number(t.value); E.xs = SZ[i]; E.xp = presetOf(E); xLive();
    $('vv_xsz').innerHTML = 'x' + (i + 1); drawXhair(); var cd = $('xCode'); if (cd) cd.value = xcode(E);
    var dl = document.querySelector('.dd.xsz span'); if (dl) dl.innerHTML = esc(ddLabel('xsz'));
    return;
  }
  if (t && t.getAttribute && t.getAttribute('data-xop')) {
    E.xtr = Number(t.value) ? 0 : 1; xLive(); $('vv_xop').innerHTML = E.xtr ? '60%' : '100%'; drawXhair(); var cd2 = $('xCode'); if (cd2) cd2.value = xcode(E);
    return;
  }
  if (!t || !t.getAttribute || !t.getAttribute('data-sl')) return;
  var k = t.getAttribute('data-sl');
  E[k] = Math.round(Number(t.value) * 100) / 100; $('vv_' + k).innerHTML = E[k] + (t.getAttribute('data-u') || '');
  if (XEXT.hasOwnProperty(k)) { drawXhair(); xLive(); }
}
document.addEventListener('change', function (e) { onSlide(e); var t = e.target || e.srcElement; if (t && (t.id === 'fMap' || t.id === 'fMode')) renderServers();  }, false);
document.addEventListener('input', onSlide, false);
document.addEventListener('keyup', function (e) { var t = e.target || e.srcElement; if (t && t.id === 'frIn' && e.keyCode !== 13) frSearch(t.value); if (t && t.id === 'calcIn') { CALC_V = t.value; var o = $('calcOut'); if (o) o.innerHTML = calcOut(); } }, false);
document.addEventListener('mousedown', function (e) {
  if (!KEYWAIT || closest(e.target || e.srcElement, 'data-bind') || closest(e.target || e.srcElement, 'data-bind2')) return;
  var pk = closest(e.target || e.srcElement, 'data-pickkey');   // sichqoncha yon tugmalari brauzerga kelmaydi - ro'yxatdan tanlash
  if (pk) { e.preventDefault(); e.stopPropagation(); var kk = pk.getAttribute('data-pickkey'); if (kk) finishWait(kk); else { KEYWAIT = ''; showSetTab('keys'); } return; }
  var b = e.button === 0 ? 'MOUSE1' : e.button === 2 ? 'MOUSE2' : e.button === 1 ? 'MOUSE3' : e.button === 3 ? 'MOUSE4' : 'MOUSE5';
  e.preventDefault(); e.stopPropagation(); finishWait(b);
}, true);
document.addEventListener('mousewheel', function (e) { if (!KEYWAIT) return; e.preventDefault(); finishWait(e.wheelDelta > 0 ? 'MWHEELUP' : 'MWHEELDOWN'); }, false);
document.oncontextmenu = function () { return !KEYWAIT; };
document.onkeypress = function (e) { if (!KEYWAIT) return; var kn = charKey(String.fromCharCode(e.charCode || e.which || 0)); if (kn) { finishWait(kn); return false; } };
document.onkeydown = function (e) {
  var k = e.keyCode;
  if (k === 27 && !KEYWAIT) cmd('hideconsole');   // ochiq qolgan konsol ESC da menyu bilan birga chiqmasin (~ bilan ochish ishlayveradi)
  if (KEYWAIT) { if (k === 27) { finishWait(''); return false; } var kn = keyName(e); if (kn) { finishWait(kn); return false; } return; }   // nomi aniqlanmasa - keypress da harf bo'yicha
  if ($('mdAsk').className === 'modal on') { if (k === 13) askDone(true); if (k === 27) askDone(false); return; }
  if (curModal === 'mdLogin' && k === 13) { doLogin(); return false; }
  if (curModal === 'mdSide' && k === 13 && $('chatIn')) { chatSend(); return false; }
  if (curModal === 'mdSide' && k === 13 && $('frIn')) { act('fradd'); return false; }
  if (k === 27 && curModal) { closeModal(); return false; }
  if (k >= 112 && k <= 123 && k !== 116) { if (e.preventDefault) e.preventDefault(); return false; }   // F1-F12 menyuda hech narsa qilmasin (brauzer tugmalari)
  if (k === 116 || (k === 82 && e.ctrlKey)) { if (e.preventDefault) e.preventDefault(); toast(T('sh_menu'), 3500); return false; }   // F5 menyuni qayta yuklamasin (skrinshot - o'yin ichida)
};
$('askYes').onclick = function () { askDone(true); };
$('askNo').onclick = function () { askDone(false); };
$('srvSearch').onkeyup = function () { renderServers(); };
$('avFile').onchange = function () { avUpload(this.files && this.files[0]); };
$('sprayFile').onchange = function () {
  var f = this.files && this.files[0]; if (!f) return;
  if (!/^image\//.test(f.type || '') || !window.FileReader) return toast(T('a_photo_bad'));
  var rd = new FileReader(); rd.onload = function () { sprayFrom(rd.result); }; rd.readAsDataURL(f);
};

/* ============================================================ boshlash */
var VERSION = qparam('v') || window.XC_VERSION || '';
function detectLang() {
  if (DB.lang) { setLang(DB.lang); return; }
  var m = /[?&]lang=([a-z]+)/i.exec(location.search || '');
  setLang(m ? m[1] : 'uzbek');
}
/* o'yin paytida (serverda, menyu yashirin) sahifa o'zgarmaydi: o'yin brauzeri (CEF1) o'yin bilan bitta oqimda chizadi -
 * har o'zgarish o'yinda bir lahzalik qotish edi. O'zgarishlar menyu ochilganda ('show') bir yo'la chiziladi */
var UI_DIRTY = false;
function renderAll() { if (playing()) { UI_DIRTY = true; return; } renderHome(); renderServers(); }

/* har bir qadam alohida: bittasi buzilsa ham qolgani ishlaydi */
function step(name, fn) { try { fn(); } catch (e) { if (window.onerror) window.onerror(name + ': ' + (e && e.message ? e.message : e), 'xc.js', 0); } }
step('load();', function () { load(); });
step("if (DB.forget) { DB.token = ''; DB.forge", function () { if (DB.forget) { DB.token = ''; DB.forget = 0; persist(); } });      // "Eslab qolish" o'chirilgan bo'lsa - keyingi safar qayta kirish
step('loadSettings();', function () { loadSettings(); });
step('loadBinds();', function () { loadBinds(); binAliases(); });
step('seedFromGame();', function () { seedFromGame(); });
// saqlangan sozlamalar har ochilishda qayta qo'yiladi: sborkaning userconfig.cfg / eski xclient_launcher.cfg ularni o'zgartirib yuboradi
step('demo', function () { if (DB.dplay && now() - DB.dplay.t < 600000) { DEMO_PLAY = true; DEMO_CUR = DB.dplay.n; } });   // demo paytida menyu qayta yuklandi
step('f10', function () {                          // F10 (video) va F9 (oxirgi 30 soniya) - launcher ushlaydi; o'yinda zararsiz bo'lsin
  each(['F10', 'F11'], function (key) {
    var used = false; for (var a in BINDS) if (BINDS.hasOwnProperty(a) && (BINDS[a] === key || BINDS2[a] === key)) used = true;
    if (!used) { cmd('alias xc_' + key.toLowerCase() + ' "echo X CLIENT: ' + key + (key === 'F11' ? ' - skrinshot' : ' - video') + ' (launcher)"'); cmd('bind ' + key + ' xc_' + key.toLowerCase()); }
  });
});   // launcher F10 ni ushlay olmasa ham o'yinda "quit prompt" chiqmasin
/* oldingi versiyada ESC menyusidan chiqilganda "volume 0" config.cfg ga saqlanib qolgan bo'lishi mumkin: o'yin ovozsiz ochiladi.
 * Menyu ochilganda ovoz 0 bo'lsa (va hozir o'zimiz jim qilmagan bo'lsak) - qaytaramiz */
step('volfix', function () { setTimeout(function () { var v = parseFloat(readCvar('volume')); if (GMUTE || DEMO_PLAY) return; if (S && !(S.vol > 0)) { S.vol = DEF.vol; if (DB.set) { DB.set.vol = S.vol; persist(); } }   // o'yindan o'qilgan 0 - eski jim holat
    if (v === 0 || (isNaN(v) && !DB.vfix)) cmd('volume ' + gameVol()); if (!DB.vfix) { DB.vfix = 1; persist(); } }, 2000); });
step('reapply', function () { if (DB.set) { var ra = function () { applySettings(S); applyBinds(); }; setTimeout(ra, 2500); setTimeout(ra, 12000); } else setTimeout(xhairApply, 2500); });
step('fit();', function () { fit(); });
step('window.onresize = fit;', function () { window.onresize = fit; });
step('fxLoop();', function () { fxLoop(); });
step('beat', function () { if (DB.beat !== new Date().toDateString()) api('beat', { nick: MYNAME || (S && S.name) || '', res: (screen.width || 0) + 'x' + (screen.height || 0), mv: VERSION }, function (r) { if (r.ok) { DB.beat = new Date().toDateString(); persist(); } }); });   // statistika: menyu ochildi
step('loadAnn', function () { loadAnn(); });
step('loadFeat', function () { loadFeat(); });
step('perf', function () { perfStart(); });
step('loc', function () { if (DB.hist && DB.hist.length) { var h = DB.hist.filter(function (x) { return !(x && isLocalAddr(x.ip)); }); if (h.length !== DB.hist.length) { DB.hist = h; persist(); } } });   // 10204600 gacha botlar bilan o'yin 'local:27015' bo'lib tarixga tushgan
step('music', function () { setTimeout(musicSync, 3000); });
step('whatsnew', function () { setTimeout(loadWhatsNew, 4000); });
step('tour', function () { setTimeout(tourShow, 3000); });
step('ngFit', function () { ngFit(); });
step('applyTheme', function () { if ((DB.theme && DB.theme !== 'red') || DB.day || (DB.fs && DB.fs !== 1)) applyTheme(DB.theme || 'red'); else { renderTop2(); applyBg(); } });
step('detectLang();', function () { detectLang(); });
step('loadMaster();', function () { loadMaster(); });
step('loadTop();', function () { loadTop(); });
step('loadWeek();', function () { loadWeek(); });
step('loadOpts();', function () { loadOpts(); });
step('each(PINNED.concat(DB.fav).concat(DB.his', function () { each(PINNED.concat(DB.fav).concat(DB.hist.slice(0, 5).map(function (h) { return h.ip; })), function (ip) { query(ip); }); });
step('renderAll();', function () { renderAll(); });

// kirish oynasi o'zi ochilmaydi - o'ng ustundagi "Akkauntga kiring" kartasi orqali
if (DB.token) api('me', {}, function (r) { if (r.ok) { setMe(r.me); loadFriends(); pingPresence(); } else if (r.err === 'auth') { DB.token = ''; persist(); renderAll(); } });

if (NC) {
  // o'yin ekrani ochildi (NextClient'ning o'z ro'yxatidan yoki konsoldan kirilsa ham) - menyu musiqasi o'chsin
  try { if (NC.gameUi && NC.gameUi.addEventListener) NC.gameUi.addEventListener('hide', function () { UI_VIS = false; ESC_OPEN = false; clearTimeout(SHOW_TM); musicSync(); }); } catch (e) {}
  try { if (NC.gameUi && NC.gameUi.addEventListener) NC.gameUi.addEventListener('show', function () { UI_VIS = true; ESC_OPEN = !!CONNECTED; musicSync(); restCheck(); showWork(); botsScore(); }); } catch (e) {}
  try {
    if (NC.addEventListener) {
      NC.addEventListener('connect', function (e) { onConnectEvt(e && e.detail && e.detail.address, false); });
      NC.addEventListener('putinserver', function (e) { onConnectEvt(e && e.detail && e.detail.address, true); setTimeout(xhairApply, 4000); });   // server pritselni o'zgartirgan bo'lsa - qaytaramiz
      NC.addEventListener('disconnect', function () { onDisconnectEvt(); cmd('hideconsole'); setTimeout(function () { if (!CONNECTED) pwRestoreName(); }, 6000); });
    }
    /* CS 1.6: bir marta ochilgan konsol yopilmaguncha har ESC da (bosh menyuda) qayta chiqadi - NextClient faqat o'yinga qaytganda yopadi */
    setTimeout(function () { cmd('hideconsole'); if (!CONNECTED) pwRestoreName(); }, 1500);
    if (NC.connectedHost) onConnectEvt(NC.connectedHost, true);
  } catch (e) {}
  try {
    if (NC.console) {
      if (typeof NC.console.init === 'function') NC.console.init();
      if (NC.console.addEventListener) NC.console.addEventListener('message', function (e) { onConsole(e && e.detail && (e.detail.text != null ? e.detail.text : e.detail)); });
    }
  } catch (e) {}
} else dbg('nextclient API yo\'q');

/* O'yin paytida (serverda, menyu yopiq) fonda hech narsa qilmaymiz: serverlarni so'rash o'yin dvigateli orqali ketadi va
 * har 30 soniyada qisqa qotish berardi. Menyu ochilganda ('show') hammasi darhol yangilanadi */
function playing() {
  if (!CONNECTED && !localGame()) return false;    // botlar bilan mashq ham o'yin: menyu tinch turishi kerak (so'rovlar o'yinni qotiradi)
  return !uiShown();
}
setInterval(function () {
  if (playing()) return;
  each(TOP.slice(0, 6).concat(PINNED).concat(DB.fav), function (ip) { query(ip); });
  if (curModal === 'mdServers') each(tabIps(), function (ip) { query(ip); });
}, 30000);
setInterval(function () {                          // "Serverlar" oynasi ochiq va ko'rinib turibdi - 15 soniyada bir yangilanadi
  if (curModal !== 'mdServers' || !uiShown()) return;
  if (srvTab === 'lan') lanStart();               // LAN: yangi ochilgan serverlar ham chiqsin
  each(tabIps(), function (ip) { query(ip, true); });
  if (srvSel) loadPlayers(srvSel);
}, 15000);
var PP_N = 0; setInterval(function () { if (!playing() || ++PP_N % 3 === 0) pingPresence(); }, 60000);   // o'yin paytida 3 daqiqada bir
var SS_N = 0; setInterval(function () { if (CONNECTED && (!playing() || ++SS_N % 3 === 0)) sendStat(); }, 120000);
/* duel davom etyapti - kill'lar saytga tez-tez (30 s) yetib borsin: 6 daqiqada bir yuborilsa 5 daqiqalik duel 0:0 bo'lardi.
 * Kill o'zgarmagan bo'lsa sendStat so'rov yubormaydi (STAT_LAST) */
setInterval(function () { if (CONNECTED && DUEL && DUEL.st === 'on') sendStat(); }, 30000);   // menyu ochiq - 2 daqiqada, o'yin paytida 6 daqiqada bir (o'yin qulab tushsa ham yo'qolmasin)
setInterval(function () { if (!playing()) { loadFriends(); loadWeek(); } }, 60000);   // o'yinda xabarlar pollNotif orqali keladi
setInterval(function () { if (!playing()) loadTop(); }, 10 * 60 * 1000);
setInterval(function () { if (!playing()) loadAnn(); }, 5 * 60 * 1000);
setTimeout(sendStats, 90000); setInterval(function () { if (!playing()) sendStats(); }, 10 * 60 * 1000);
/* menyu to'liq ishga tushdi - index.html dagi qo'riqchi sahifani qayta yuklamaydi, hisoblagich tozalanadi */
window.XC_UP = 1; try { if (window.XC_NM) window.XC_NM(/^xcwd\d$/, ''); } catch (e) {}
if (window.XC_WDN > 0) setTimeout(function () { api('prob', { k: 'menu_wd', d: PCID || '' }, function () {}); }, 5000);
})();

/* ============================================================ QR kod (Telegram ulash)
 * qrcode-generator 1.4.4 - Copyright (c) 2009 Kazuhiko Arase, MIT litsenziyasi (https://github.com/kazuhikoarase/qrcode-generator). ES5 */
var QRGEN = (function () {
//---------------------------------------------------------------------
//
// QR Code Generator for JavaScript
//
// Copyright (c) 2009 Kazuhiko Arase
//
// URL: http://www.d-project.com/
//
// Licensed under the MIT license:
//  http://www.opensource.org/licenses/mit-license.php
//
// The word 'QR Code' is registered trademark of
// DENSO WAVE INCORPORATED
//  http://www.denso-wave.com/qrcode/faqpatent-e.html
//
//---------------------------------------------------------------------

var qrcode = function() {

  //---------------------------------------------------------------------
  // qrcode
  //---------------------------------------------------------------------

  /**
   * qrcode
   * @param typeNumber 1 to 40
   * @param errorCorrectionLevel 'L','M','Q','H'
   */
  var qrcode = function(typeNumber, errorCorrectionLevel) {

    var PAD0 = 0xEC;
    var PAD1 = 0x11;

    var _typeNumber = typeNumber;
    var _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
    var _modules = null;
    var _moduleCount = 0;
    var _dataCache = null;
    var _dataList = [];

    var _this = {};

    var makeImpl = function(test, maskPattern) {

      _moduleCount = _typeNumber * 4 + 17;
      _modules = function(moduleCount) {
        var modules = new Array(moduleCount);
        for (var row = 0; row < moduleCount; row += 1) {
          modules[row] = new Array(moduleCount);
          for (var col = 0; col < moduleCount; col += 1) {
            modules[row][col] = null;
          }
        }
        return modules;
      }(_moduleCount);

      setupPositionProbePattern(0, 0);
      setupPositionProbePattern(_moduleCount - 7, 0);
      setupPositionProbePattern(0, _moduleCount - 7);
      setupPositionAdjustPattern();
      setupTimingPattern();
      setupTypeInfo(test, maskPattern);

      if (_typeNumber >= 7) {
        setupTypeNumber(test);
      }

      if (_dataCache == null) {
        _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
      }

      mapData(_dataCache, maskPattern);
    };

    var setupPositionProbePattern = function(row, col) {

      for (var r = -1; r <= 7; r += 1) {

        if (row + r <= -1 || _moduleCount <= row + r) continue;

        for (var c = -1; c <= 7; c += 1) {

          if (col + c <= -1 || _moduleCount <= col + c) continue;

          if ( (0 <= r && r <= 6 && (c == 0 || c == 6) )
              || (0 <= c && c <= 6 && (r == 0 || r == 6) )
              || (2 <= r && r <= 4 && 2 <= c && c <= 4) ) {
            _modules[row + r][col + c] = true;
          } else {
            _modules[row + r][col + c] = false;
          }
        }
      }
    };

    var getBestMaskPattern = function() {

      var minLostPoint = 0;
      var pattern = 0;

      for (var i = 0; i < 8; i += 1) {

        makeImpl(true, i);

        var lostPoint = QRUtil.getLostPoint(_this);

        if (i == 0 || minLostPoint > lostPoint) {
          minLostPoint = lostPoint;
          pattern = i;
        }
      }

      return pattern;
    };

    var setupTimingPattern = function() {

      for (var r = 8; r < _moduleCount - 8; r += 1) {
        if (_modules[r][6] != null) {
          continue;
        }
        _modules[r][6] = (r % 2 == 0);
      }

      for (var c = 8; c < _moduleCount - 8; c += 1) {
        if (_modules[6][c] != null) {
          continue;
        }
        _modules[6][c] = (c % 2 == 0);
      }
    };

    var setupPositionAdjustPattern = function() {

      var pos = QRUtil.getPatternPosition(_typeNumber);

      for (var i = 0; i < pos.length; i += 1) {

        for (var j = 0; j < pos.length; j += 1) {

          var row = pos[i];
          var col = pos[j];

          if (_modules[row][col] != null) {
            continue;
          }

          for (var r = -2; r <= 2; r += 1) {

            for (var c = -2; c <= 2; c += 1) {

              if (r == -2 || r == 2 || c == -2 || c == 2
                  || (r == 0 && c == 0) ) {
                _modules[row + r][col + c] = true;
              } else {
                _modules[row + r][col + c] = false;
              }
            }
          }
        }
      }
    };

    var setupTypeNumber = function(test) {

      var bits = QRUtil.getBCHTypeNumber(_typeNumber);

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
      }

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
      }
    };

    var setupTypeInfo = function(test, maskPattern) {

      var data = (_errorCorrectionLevel << 3) | maskPattern;
      var bits = QRUtil.getBCHTypeInfo(data);

      // vertical
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 6) {
          _modules[i][8] = mod;
        } else if (i < 8) {
          _modules[i + 1][8] = mod;
        } else {
          _modules[_moduleCount - 15 + i][8] = mod;
        }
      }

      // horizontal
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 8) {
          _modules[8][_moduleCount - i - 1] = mod;
        } else if (i < 9) {
          _modules[8][15 - i - 1 + 1] = mod;
        } else {
          _modules[8][15 - i - 1] = mod;
        }
      }

      // fixed module
      _modules[_moduleCount - 8][8] = (!test);
    };

    var mapData = function(data, maskPattern) {

      var inc = -1;
      var row = _moduleCount - 1;
      var bitIndex = 7;
      var byteIndex = 0;
      var maskFunc = QRUtil.getMaskFunction(maskPattern);

      for (var col = _moduleCount - 1; col > 0; col -= 2) {

        if (col == 6) col -= 1;

        while (true) {

          for (var c = 0; c < 2; c += 1) {

            if (_modules[row][col - c] == null) {

              var dark = false;

              if (byteIndex < data.length) {
                dark = ( ( (data[byteIndex] >>> bitIndex) & 1) == 1);
              }

              var mask = maskFunc(row, col - c);

              if (mask) {
                dark = !dark;
              }

              _modules[row][col - c] = dark;
              bitIndex -= 1;

              if (bitIndex == -1) {
                byteIndex += 1;
                bitIndex = 7;
              }
            }
          }

          row += inc;

          if (row < 0 || _moduleCount <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    };

    var createBytes = function(buffer, rsBlocks) {

      var offset = 0;

      var maxDcCount = 0;
      var maxEcCount = 0;

      var dcdata = new Array(rsBlocks.length);
      var ecdata = new Array(rsBlocks.length);

      for (var r = 0; r < rsBlocks.length; r += 1) {

        var dcCount = rsBlocks[r].dataCount;
        var ecCount = rsBlocks[r].totalCount - dcCount;

        maxDcCount = Math.max(maxDcCount, dcCount);
        maxEcCount = Math.max(maxEcCount, ecCount);

        dcdata[r] = new Array(dcCount);

        for (var i = 0; i < dcdata[r].length; i += 1) {
          dcdata[r][i] = 0xff & buffer.getBuffer()[i + offset];
        }
        offset += dcCount;

        var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
        var rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);

        var modPoly = rawPoly.mod(rsPoly);
        ecdata[r] = new Array(rsPoly.getLength() - 1);
        for (var i = 0; i < ecdata[r].length; i += 1) {
          var modIndex = i + modPoly.getLength() - ecdata[r].length;
          ecdata[r][i] = (modIndex >= 0)? modPoly.getAt(modIndex) : 0;
        }
      }

      var totalCodeCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalCodeCount += rsBlocks[i].totalCount;
      }

      var data = new Array(totalCodeCount);
      var index = 0;

      for (var i = 0; i < maxDcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < dcdata[r].length) {
            data[index] = dcdata[r][i];
            index += 1;
          }
        }
      }

      for (var i = 0; i < maxEcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < ecdata[r].length) {
            data[index] = ecdata[r][i];
            index += 1;
          }
        }
      }

      return data;
    };

    var createData = function(typeNumber, errorCorrectionLevel, dataList) {

      var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectionLevel);

      var buffer = qrBitBuffer();

      for (var i = 0; i < dataList.length; i += 1) {
        var data = dataList[i];
        buffer.put(data.getMode(), 4);
        buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
        data.write(buffer);
      }

      // calc num max data.
      var totalDataCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalDataCount += rsBlocks[i].dataCount;
      }

      if (buffer.getLengthInBits() > totalDataCount * 8) {
        throw 'code length overflow. ('
          + buffer.getLengthInBits()
          + '>'
          + totalDataCount * 8
          + ')';
      }

      // end code
      if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
        buffer.put(0, 4);
      }

      // padding
      while (buffer.getLengthInBits() % 8 != 0) {
        buffer.putBit(false);
      }

      // padding
      while (true) {

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD0, 8);

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD1, 8);
      }

      return createBytes(buffer, rsBlocks);
    };

    _this.addData = function(data, mode) {

      mode = mode || 'Byte';

      var newData = null;

      switch(mode) {
      case 'Numeric' :
        newData = qrNumber(data);
        break;
      case 'Alphanumeric' :
        newData = qrAlphaNum(data);
        break;
      case 'Byte' :
        newData = qr8BitByte(data);
        break;
      case 'Kanji' :
        newData = qrKanji(data);
        break;
      default :
        throw 'mode:' + mode;
      }

      _dataList.push(newData);
      _dataCache = null;
    };

    _this.isDark = function(row, col) {
      if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
        throw row + ',' + col;
      }
      return _modules[row][col];
    };

    _this.getModuleCount = function() {
      return _moduleCount;
    };

    _this.make = function() {
      if (_typeNumber < 1) {
        var typeNumber = 1;

        for (; typeNumber < 40; typeNumber++) {
          var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, _errorCorrectionLevel);
          var buffer = qrBitBuffer();

          for (var i = 0; i < _dataList.length; i++) {
            var data = _dataList[i];
            buffer.put(data.getMode(), 4);
            buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
            data.write(buffer);
          }

          var totalDataCount = 0;
          for (var i = 0; i < rsBlocks.length; i++) {
            totalDataCount += rsBlocks[i].dataCount;
          }

          if (buffer.getLengthInBits() <= totalDataCount * 8) {
            break;
          }
        }

        _typeNumber = typeNumber;
      }

      makeImpl(false, getBestMaskPattern() );
    };

    _this.createTableTag = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var qrHtml = '';

      qrHtml += '<table style="';
      qrHtml += ' border-width: 0px; border-style: none;';
      qrHtml += ' border-collapse: collapse;';
      qrHtml += ' padding: 0px; margin: ' + margin + 'px;';
      qrHtml += '">';
      qrHtml += '<tbody>';

      for (var r = 0; r < _this.getModuleCount(); r += 1) {

        qrHtml += '<tr>';

        for (var c = 0; c < _this.getModuleCount(); c += 1) {
          qrHtml += '<td style="';
          qrHtml += ' border-width: 0px; border-style: none;';
          qrHtml += ' border-collapse: collapse;';
          qrHtml += ' padding: 0px; margin: 0px;';
          qrHtml += ' width: ' + cellSize + 'px;';
          qrHtml += ' height: ' + cellSize + 'px;';
          qrHtml += ' background-color: ';
          qrHtml += _this.isDark(r, c)? '#000000' : '#ffffff';
          qrHtml += ';';
          qrHtml += '"/>';
        }

        qrHtml += '</tr>';
      }

      qrHtml += '</tbody>';
      qrHtml += '</table>';

      return qrHtml;
    };

    _this.createSvgTag = function(cellSize, margin, alt, title) {

      var opts = {};
      if (typeof arguments[0] == 'object') {
        // Called by options.
        opts = arguments[0];
        // overwrite cellSize and margin.
        cellSize = opts.cellSize;
        margin = opts.margin;
        alt = opts.alt;
        title = opts.title;
      }

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      // Compose alt property surrogate
      alt = (typeof alt === 'string') ? {text: alt} : alt || {};
      alt.text = alt.text || null;
      alt.id = (alt.text) ? alt.id || 'qrcode-description' : null;

      // Compose title property surrogate
      title = (typeof title === 'string') ? {text: title} : title || {};
      title.text = title.text || null;
      title.id = (title.text) ? title.id || 'qrcode-title' : null;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var c, mc, r, mr, qrSvg='', rect;

      rect = 'l' + cellSize + ',0 0,' + cellSize +
        ' -' + cellSize + ',0 0,-' + cellSize + 'z ';

      qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
      qrSvg += !opts.scalable ? ' width="' + size + 'px" height="' + size + 'px"' : '';
      qrSvg += ' viewBox="0 0 ' + size + ' ' + size + '" ';
      qrSvg += ' preserveAspectRatio="xMinYMin meet"';
      qrSvg += (title.text || alt.text) ? ' role="img" aria-labelledby="' +
          escapeXml([title.id, alt.id].join(' ').trim() ) + '"' : '';
      qrSvg += '>';
      qrSvg += (title.text) ? '<title id="' + escapeXml(title.id) + '">' +
          escapeXml(title.text) + '</title>' : '';
      qrSvg += (alt.text) ? '<description id="' + escapeXml(alt.id) + '">' +
          escapeXml(alt.text) + '</description>' : '';
      qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
      qrSvg += '<path d="';

      for (r = 0; r < _this.getModuleCount(); r += 1) {
        mr = r * cellSize + margin;
        for (c = 0; c < _this.getModuleCount(); c += 1) {
          if (_this.isDark(r, c) ) {
            mc = c*cellSize+margin;
            qrSvg += 'M' + mc + ',' + mr + rect;
          }
        }
      }

      qrSvg += '" stroke="transparent" fill="black"/>';
      qrSvg += '</svg>';

      return qrSvg;
    };

    _this.createDataURL = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      return createDataURL(size, size, function(x, y) {
        if (min <= x && x < max && min <= y && y < max) {
          var c = Math.floor( (x - min) / cellSize);
          var r = Math.floor( (y - min) / cellSize);
          return _this.isDark(r, c)? 0 : 1;
        } else {
          return 1;
        }
      } );
    };

    _this.createImgTag = function(cellSize, margin, alt) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;

      var img = '';
      img += '<img';
      img += '\u0020src="';
      img += _this.createDataURL(cellSize, margin);
      img += '"';
      img += '\u0020width="';
      img += size;
      img += '"';
      img += '\u0020height="';
      img += size;
      img += '"';
      if (alt) {
        img += '\u0020alt="';
        img += escapeXml(alt);
        img += '"';
      }
      img += '/>';

      return img;
    };

    var escapeXml = function(s) {
      var escaped = '';
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charAt(i);
        switch(c) {
        case '<': escaped += '&lt;'; break;
        case '>': escaped += '&gt;'; break;
        case '&': escaped += '&amp;'; break;
        case '"': escaped += '&quot;'; break;
        default : escaped += c; break;
        }
      }
      return escaped;
    };

    var _createHalfASCII = function(margin) {
      var cellSize = 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r1, r2, p;

      var blocks = {
        '██': '█',
        '█ ': '▀',
        ' █': '▄',
        '  ': ' '
      };

      var blocksLastLineNoMargin = {
        '██': '▀',
        '█ ': '▀',
        ' █': ' ',
        '  ': ' '
      };

      var ascii = '';
      for (y = 0; y < size; y += 2) {
        r1 = Math.floor((y - min) / cellSize);
        r2 = Math.floor((y + 1 - min) / cellSize);
        for (x = 0; x < size; x += 1) {
          p = '█';

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
            p = ' ';
          }

          if (min <= x && x < max && min <= y+1 && y+1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
            p += ' ';
          }
          else {
            p += '█';
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          ascii += (margin < 1 && y+1 >= max) ? blocksLastLineNoMargin[p] : blocks[p];
        }

        ascii += '\n';
      }

      if (size % 2 && margin > 0) {
        return ascii.substring(0, ascii.length - size - 1) + Array(size+1).join('▀');
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.createASCII = function(cellSize, margin) {
      cellSize = cellSize || 1;

      if (cellSize < 2) {
        return _createHalfASCII(margin);
      }

      cellSize -= 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r, p;

      var white = Array(cellSize+1).join('██');
      var black = Array(cellSize+1).join('  ');

      var ascii = '';
      var line = '';
      for (y = 0; y < size; y += 1) {
        r = Math.floor( (y - min) / cellSize);
        line = '';
        for (x = 0; x < size; x += 1) {
          p = 1;

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) {
            p = 0;
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          line += p ? white : black;
        }

        for (r = 0; r < cellSize; r += 1) {
          ascii += line + '\n';
        }
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.renderTo2dContext = function(context, cellSize) {
      cellSize = cellSize || 2;
      var length = _this.getModuleCount();
      for (var row = 0; row < length; row++) {
        for (var col = 0; col < length; col++) {
          context.fillStyle = _this.isDark(row, col) ? 'black' : 'white';
          context.fillRect(row * cellSize, col * cellSize, cellSize, cellSize);
        }
      }
    }

    return _this;
  };

  //---------------------------------------------------------------------
  // qrcode.stringToBytes
  //---------------------------------------------------------------------

  qrcode.stringToBytesFuncs = {
    'default' : function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        bytes.push(c & 0xff);
      }
      return bytes;
    }
  };

  qrcode.stringToBytes = qrcode.stringToBytesFuncs['default'];

  //---------------------------------------------------------------------
  // qrcode.createStringToBytes
  //---------------------------------------------------------------------

  /**
   * @param unicodeData base64 string of byte array.
   * [16bit Unicode],[16bit Bytes], ...
   * @param numChars
   */
  qrcode.createStringToBytes = function(unicodeData, numChars) {

    // create conversion map.

    var unicodeMap = function() {

      var bin = base64DecodeInputStream(unicodeData);
      var read = function() {
        var b = bin.read();
        if (b == -1) throw 'eof';
        return b;
      };

      var count = 0;
      var unicodeMap = {};
      while (true) {
        var b0 = bin.read();
        if (b0 == -1) break;
        var b1 = read();
        var b2 = read();
        var b3 = read();
        var k = String.fromCharCode( (b0 << 8) | b1);
        var v = (b2 << 8) | b3;
        unicodeMap[k] = v;
        count += 1;
      }
      if (count != numChars) {
        throw count + ' != ' + numChars;
      }

      return unicodeMap;
    }();

    var unknownChar = '?'.charCodeAt(0);

    return function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        if (c < 128) {
          bytes.push(c);
        } else {
          var b = unicodeMap[s.charAt(i)];
          if (typeof b == 'number') {
            if ( (b & 0xff) == b) {
              // 1byte
              bytes.push(b);
            } else {
              // 2bytes
              bytes.push(b >>> 8);
              bytes.push(b & 0xff);
            }
          } else {
            bytes.push(unknownChar);
          }
        }
      }
      return bytes;
    };
  };

  //---------------------------------------------------------------------
  // QRMode
  //---------------------------------------------------------------------

  var QRMode = {
    MODE_NUMBER :    1 << 0,
    MODE_ALPHA_NUM : 1 << 1,
    MODE_8BIT_BYTE : 1 << 2,
    MODE_KANJI :     1 << 3
  };

  //---------------------------------------------------------------------
  // QRErrorCorrectionLevel
  //---------------------------------------------------------------------

  var QRErrorCorrectionLevel = {
    L : 1,
    M : 0,
    Q : 3,
    H : 2
  };

  //---------------------------------------------------------------------
  // QRMaskPattern
  //---------------------------------------------------------------------

  var QRMaskPattern = {
    PATTERN000 : 0,
    PATTERN001 : 1,
    PATTERN010 : 2,
    PATTERN011 : 3,
    PATTERN100 : 4,
    PATTERN101 : 5,
    PATTERN110 : 6,
    PATTERN111 : 7
  };

  //---------------------------------------------------------------------
  // QRUtil
  //---------------------------------------------------------------------

  var QRUtil = function() {

    var PATTERN_POSITION_TABLE = [
      [],
      [6, 18],
      [6, 22],
      [6, 26],
      [6, 30],
      [6, 34],
      [6, 22, 38],
      [6, 24, 42],
      [6, 26, 46],
      [6, 28, 50],
      [6, 30, 54],
      [6, 32, 58],
      [6, 34, 62],
      [6, 26, 46, 66],
      [6, 26, 48, 70],
      [6, 26, 50, 74],
      [6, 30, 54, 78],
      [6, 30, 56, 82],
      [6, 30, 58, 86],
      [6, 34, 62, 90],
      [6, 28, 50, 72, 94],
      [6, 26, 50, 74, 98],
      [6, 30, 54, 78, 102],
      [6, 28, 54, 80, 106],
      [6, 32, 58, 84, 110],
      [6, 30, 58, 86, 114],
      [6, 34, 62, 90, 118],
      [6, 26, 50, 74, 98, 122],
      [6, 30, 54, 78, 102, 126],
      [6, 26, 52, 78, 104, 130],
      [6, 30, 56, 82, 108, 134],
      [6, 34, 60, 86, 112, 138],
      [6, 30, 58, 86, 114, 142],
      [6, 34, 62, 90, 118, 146],
      [6, 30, 54, 78, 102, 126, 150],
      [6, 24, 50, 76, 102, 128, 154],
      [6, 28, 54, 80, 106, 132, 158],
      [6, 32, 58, 84, 110, 136, 162],
      [6, 26, 54, 82, 110, 138, 166],
      [6, 30, 58, 86, 114, 142, 170]
    ];
    var G15 = (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0);
    var G18 = (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0);
    var G15_MASK = (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1);

    var _this = {};

    var getBCHDigit = function(data) {
      var digit = 0;
      while (data != 0) {
        digit += 1;
        data >>>= 1;
      }
      return digit;
    };

    _this.getBCHTypeInfo = function(data) {
      var d = data << 10;
      while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
        d ^= (G15 << (getBCHDigit(d) - getBCHDigit(G15) ) );
      }
      return ( (data << 10) | d) ^ G15_MASK;
    };

    _this.getBCHTypeNumber = function(data) {
      var d = data << 12;
      while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
        d ^= (G18 << (getBCHDigit(d) - getBCHDigit(G18) ) );
      }
      return (data << 12) | d;
    };

    _this.getPatternPosition = function(typeNumber) {
      return PATTERN_POSITION_TABLE[typeNumber - 1];
    };

    _this.getMaskFunction = function(maskPattern) {

      switch (maskPattern) {

      case QRMaskPattern.PATTERN000 :
        return function(i, j) { return (i + j) % 2 == 0; };
      case QRMaskPattern.PATTERN001 :
        return function(i, j) { return i % 2 == 0; };
      case QRMaskPattern.PATTERN010 :
        return function(i, j) { return j % 3 == 0; };
      case QRMaskPattern.PATTERN011 :
        return function(i, j) { return (i + j) % 3 == 0; };
      case QRMaskPattern.PATTERN100 :
        return function(i, j) { return (Math.floor(i / 2) + Math.floor(j / 3) ) % 2 == 0; };
      case QRMaskPattern.PATTERN101 :
        return function(i, j) { return (i * j) % 2 + (i * j) % 3 == 0; };
      case QRMaskPattern.PATTERN110 :
        return function(i, j) { return ( (i * j) % 2 + (i * j) % 3) % 2 == 0; };
      case QRMaskPattern.PATTERN111 :
        return function(i, j) { return ( (i * j) % 3 + (i + j) % 2) % 2 == 0; };

      default :
        throw 'bad maskPattern:' + maskPattern;
      }
    };

    _this.getErrorCorrectPolynomial = function(errorCorrectLength) {
      var a = qrPolynomial([1], 0);
      for (var i = 0; i < errorCorrectLength; i += 1) {
        a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0) );
      }
      return a;
    };

    _this.getLengthInBits = function(mode, type) {

      if (1 <= type && type < 10) {

        // 1 - 9

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 10;
        case QRMode.MODE_ALPHA_NUM : return 9;
        case QRMode.MODE_8BIT_BYTE : return 8;
        case QRMode.MODE_KANJI     : return 8;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 27) {

        // 10 - 26

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 12;
        case QRMode.MODE_ALPHA_NUM : return 11;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 10;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 41) {

        // 27 - 40

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 14;
        case QRMode.MODE_ALPHA_NUM : return 13;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 12;
        default :
          throw 'mode:' + mode;
        }

      } else {
        throw 'type:' + type;
      }
    };

    _this.getLostPoint = function(qrcode) {

      var moduleCount = qrcode.getModuleCount();

      var lostPoint = 0;

      // LEVEL1

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount; col += 1) {

          var sameCount = 0;
          var dark = qrcode.isDark(row, col);

          for (var r = -1; r <= 1; r += 1) {

            if (row + r < 0 || moduleCount <= row + r) {
              continue;
            }

            for (var c = -1; c <= 1; c += 1) {

              if (col + c < 0 || moduleCount <= col + c) {
                continue;
              }

              if (r == 0 && c == 0) {
                continue;
              }

              if (dark == qrcode.isDark(row + r, col + c) ) {
                sameCount += 1;
              }
            }
          }

          if (sameCount > 5) {
            lostPoint += (3 + sameCount - 5);
          }
        }
      };

      // LEVEL2

      for (var row = 0; row < moduleCount - 1; row += 1) {
        for (var col = 0; col < moduleCount - 1; col += 1) {
          var count = 0;
          if (qrcode.isDark(row, col) ) count += 1;
          if (qrcode.isDark(row + 1, col) ) count += 1;
          if (qrcode.isDark(row, col + 1) ) count += 1;
          if (qrcode.isDark(row + 1, col + 1) ) count += 1;
          if (count == 0 || count == 4) {
            lostPoint += 3;
          }
        }
      }

      // LEVEL3

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount - 6; col += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row, col + 1)
              &&  qrcode.isDark(row, col + 2)
              &&  qrcode.isDark(row, col + 3)
              &&  qrcode.isDark(row, col + 4)
              && !qrcode.isDark(row, col + 5)
              &&  qrcode.isDark(row, col + 6) ) {
            lostPoint += 40;
          }
        }
      }

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount - 6; row += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row + 1, col)
              &&  qrcode.isDark(row + 2, col)
              &&  qrcode.isDark(row + 3, col)
              &&  qrcode.isDark(row + 4, col)
              && !qrcode.isDark(row + 5, col)
              &&  qrcode.isDark(row + 6, col) ) {
            lostPoint += 40;
          }
        }
      }

      // LEVEL4

      var darkCount = 0;

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount; row += 1) {
          if (qrcode.isDark(row, col) ) {
            darkCount += 1;
          }
        }
      }

      var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
      lostPoint += ratio * 10;

      return lostPoint;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // QRMath
  //---------------------------------------------------------------------

  var QRMath = function() {

    var EXP_TABLE = new Array(256);
    var LOG_TABLE = new Array(256);

    // initialize tables
    for (var i = 0; i < 8; i += 1) {
      EXP_TABLE[i] = 1 << i;
    }
    for (var i = 8; i < 256; i += 1) {
      EXP_TABLE[i] = EXP_TABLE[i - 4]
        ^ EXP_TABLE[i - 5]
        ^ EXP_TABLE[i - 6]
        ^ EXP_TABLE[i - 8];
    }
    for (var i = 0; i < 255; i += 1) {
      LOG_TABLE[EXP_TABLE[i] ] = i;
    }

    var _this = {};

    _this.glog = function(n) {

      if (n < 1) {
        throw 'glog(' + n + ')';
      }

      return LOG_TABLE[n];
    };

    _this.gexp = function(n) {

      while (n < 0) {
        n += 255;
      }

      while (n >= 256) {
        n -= 255;
      }

      return EXP_TABLE[n];
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrPolynomial
  //---------------------------------------------------------------------

  function qrPolynomial(num, shift) {

    if (typeof num.length == 'undefined') {
      throw num.length + '/' + shift;
    }

    var _num = function() {
      var offset = 0;
      while (offset < num.length && num[offset] == 0) {
        offset += 1;
      }
      var _num = new Array(num.length - offset + shift);
      for (var i = 0; i < num.length - offset; i += 1) {
        _num[i] = num[i + offset];
      }
      return _num;
    }();

    var _this = {};

    _this.getAt = function(index) {
      return _num[index];
    };

    _this.getLength = function() {
      return _num.length;
    };

    _this.multiply = function(e) {

      var num = new Array(_this.getLength() + e.getLength() - 1);

      for (var i = 0; i < _this.getLength(); i += 1) {
        for (var j = 0; j < e.getLength(); j += 1) {
          num[i + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i) ) + QRMath.glog(e.getAt(j) ) );
        }
      }

      return qrPolynomial(num, 0);
    };

    _this.mod = function(e) {

      if (_this.getLength() - e.getLength() < 0) {
        return _this;
      }

      var ratio = QRMath.glog(_this.getAt(0) ) - QRMath.glog(e.getAt(0) );

      var num = new Array(_this.getLength() );
      for (var i = 0; i < _this.getLength(); i += 1) {
        num[i] = _this.getAt(i);
      }

      for (var i = 0; i < e.getLength(); i += 1) {
        num[i] ^= QRMath.gexp(QRMath.glog(e.getAt(i) ) + ratio);
      }

      // recursive call
      return qrPolynomial(num, 0).mod(e);
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // QRRSBlock
  //---------------------------------------------------------------------

  var QRRSBlock = function() {

    var RS_BLOCK_TABLE = [

      // L
      // M
      // Q
      // H

      // 1
      [1, 26, 19],
      [1, 26, 16],
      [1, 26, 13],
      [1, 26, 9],

      // 2
      [1, 44, 34],
      [1, 44, 28],
      [1, 44, 22],
      [1, 44, 16],

      // 3
      [1, 70, 55],
      [1, 70, 44],
      [2, 35, 17],
      [2, 35, 13],

      // 4
      [1, 100, 80],
      [2, 50, 32],
      [2, 50, 24],
      [4, 25, 9],

      // 5
      [1, 134, 108],
      [2, 67, 43],
      [2, 33, 15, 2, 34, 16],
      [2, 33, 11, 2, 34, 12],

      // 6
      [2, 86, 68],
      [4, 43, 27],
      [4, 43, 19],
      [4, 43, 15],

      // 7
      [2, 98, 78],
      [4, 49, 31],
      [2, 32, 14, 4, 33, 15],
      [4, 39, 13, 1, 40, 14],

      // 8
      [2, 121, 97],
      [2, 60, 38, 2, 61, 39],
      [4, 40, 18, 2, 41, 19],
      [4, 40, 14, 2, 41, 15],

      // 9
      [2, 146, 116],
      [3, 58, 36, 2, 59, 37],
      [4, 36, 16, 4, 37, 17],
      [4, 36, 12, 4, 37, 13],

      // 10
      [2, 86, 68, 2, 87, 69],
      [4, 69, 43, 1, 70, 44],
      [6, 43, 19, 2, 44, 20],
      [6, 43, 15, 2, 44, 16],

      // 11
      [4, 101, 81],
      [1, 80, 50, 4, 81, 51],
      [4, 50, 22, 4, 51, 23],
      [3, 36, 12, 8, 37, 13],

      // 12
      [2, 116, 92, 2, 117, 93],
      [6, 58, 36, 2, 59, 37],
      [4, 46, 20, 6, 47, 21],
      [7, 42, 14, 4, 43, 15],

      // 13
      [4, 133, 107],
      [8, 59, 37, 1, 60, 38],
      [8, 44, 20, 4, 45, 21],
      [12, 33, 11, 4, 34, 12],

      // 14
      [3, 145, 115, 1, 146, 116],
      [4, 64, 40, 5, 65, 41],
      [11, 36, 16, 5, 37, 17],
      [11, 36, 12, 5, 37, 13],

      // 15
      [5, 109, 87, 1, 110, 88],
      [5, 65, 41, 5, 66, 42],
      [5, 54, 24, 7, 55, 25],
      [11, 36, 12, 7, 37, 13],

      // 16
      [5, 122, 98, 1, 123, 99],
      [7, 73, 45, 3, 74, 46],
      [15, 43, 19, 2, 44, 20],
      [3, 45, 15, 13, 46, 16],

      // 17
      [1, 135, 107, 5, 136, 108],
      [10, 74, 46, 1, 75, 47],
      [1, 50, 22, 15, 51, 23],
      [2, 42, 14, 17, 43, 15],

      // 18
      [5, 150, 120, 1, 151, 121],
      [9, 69, 43, 4, 70, 44],
      [17, 50, 22, 1, 51, 23],
      [2, 42, 14, 19, 43, 15],

      // 19
      [3, 141, 113, 4, 142, 114],
      [3, 70, 44, 11, 71, 45],
      [17, 47, 21, 4, 48, 22],
      [9, 39, 13, 16, 40, 14],

      // 20
      [3, 135, 107, 5, 136, 108],
      [3, 67, 41, 13, 68, 42],
      [15, 54, 24, 5, 55, 25],
      [15, 43, 15, 10, 44, 16],

      // 21
      [4, 144, 116, 4, 145, 117],
      [17, 68, 42],
      [17, 50, 22, 6, 51, 23],
      [19, 46, 16, 6, 47, 17],

      // 22
      [2, 139, 111, 7, 140, 112],
      [17, 74, 46],
      [7, 54, 24, 16, 55, 25],
      [34, 37, 13],

      // 23
      [4, 151, 121, 5, 152, 122],
      [4, 75, 47, 14, 76, 48],
      [11, 54, 24, 14, 55, 25],
      [16, 45, 15, 14, 46, 16],

      // 24
      [6, 147, 117, 4, 148, 118],
      [6, 73, 45, 14, 74, 46],
      [11, 54, 24, 16, 55, 25],
      [30, 46, 16, 2, 47, 17],

      // 25
      [8, 132, 106, 4, 133, 107],
      [8, 75, 47, 13, 76, 48],
      [7, 54, 24, 22, 55, 25],
      [22, 45, 15, 13, 46, 16],

      // 26
      [10, 142, 114, 2, 143, 115],
      [19, 74, 46, 4, 75, 47],
      [28, 50, 22, 6, 51, 23],
      [33, 46, 16, 4, 47, 17],

      // 27
      [8, 152, 122, 4, 153, 123],
      [22, 73, 45, 3, 74, 46],
      [8, 53, 23, 26, 54, 24],
      [12, 45, 15, 28, 46, 16],

      // 28
      [3, 147, 117, 10, 148, 118],
      [3, 73, 45, 23, 74, 46],
      [4, 54, 24, 31, 55, 25],
      [11, 45, 15, 31, 46, 16],

      // 29
      [7, 146, 116, 7, 147, 117],
      [21, 73, 45, 7, 74, 46],
      [1, 53, 23, 37, 54, 24],
      [19, 45, 15, 26, 46, 16],

      // 30
      [5, 145, 115, 10, 146, 116],
      [19, 75, 47, 10, 76, 48],
      [15, 54, 24, 25, 55, 25],
      [23, 45, 15, 25, 46, 16],

      // 31
      [13, 145, 115, 3, 146, 116],
      [2, 74, 46, 29, 75, 47],
      [42, 54, 24, 1, 55, 25],
      [23, 45, 15, 28, 46, 16],

      // 32
      [17, 145, 115],
      [10, 74, 46, 23, 75, 47],
      [10, 54, 24, 35, 55, 25],
      [19, 45, 15, 35, 46, 16],

      // 33
      [17, 145, 115, 1, 146, 116],
      [14, 74, 46, 21, 75, 47],
      [29, 54, 24, 19, 55, 25],
      [11, 45, 15, 46, 46, 16],

      // 34
      [13, 145, 115, 6, 146, 116],
      [14, 74, 46, 23, 75, 47],
      [44, 54, 24, 7, 55, 25],
      [59, 46, 16, 1, 47, 17],

      // 35
      [12, 151, 121, 7, 152, 122],
      [12, 75, 47, 26, 76, 48],
      [39, 54, 24, 14, 55, 25],
      [22, 45, 15, 41, 46, 16],

      // 36
      [6, 151, 121, 14, 152, 122],
      [6, 75, 47, 34, 76, 48],
      [46, 54, 24, 10, 55, 25],
      [2, 45, 15, 64, 46, 16],

      // 37
      [17, 152, 122, 4, 153, 123],
      [29, 74, 46, 14, 75, 47],
      [49, 54, 24, 10, 55, 25],
      [24, 45, 15, 46, 46, 16],

      // 38
      [4, 152, 122, 18, 153, 123],
      [13, 74, 46, 32, 75, 47],
      [48, 54, 24, 14, 55, 25],
      [42, 45, 15, 32, 46, 16],

      // 39
      [20, 147, 117, 4, 148, 118],
      [40, 75, 47, 7, 76, 48],
      [43, 54, 24, 22, 55, 25],
      [10, 45, 15, 67, 46, 16],

      // 40
      [19, 148, 118, 6, 149, 119],
      [18, 75, 47, 31, 76, 48],
      [34, 54, 24, 34, 55, 25],
      [20, 45, 15, 61, 46, 16]
    ];

    var qrRSBlock = function(totalCount, dataCount) {
      var _this = {};
      _this.totalCount = totalCount;
      _this.dataCount = dataCount;
      return _this;
    };

    var _this = {};

    var getRsBlockTable = function(typeNumber, errorCorrectionLevel) {

      switch(errorCorrectionLevel) {
      case QRErrorCorrectionLevel.L :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
      case QRErrorCorrectionLevel.M :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
      case QRErrorCorrectionLevel.Q :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
      case QRErrorCorrectionLevel.H :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
      default :
        return undefined;
      }
    };

    _this.getRSBlocks = function(typeNumber, errorCorrectionLevel) {

      var rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);

      if (typeof rsBlock == 'undefined') {
        throw 'bad rs block @ typeNumber:' + typeNumber +
            '/errorCorrectionLevel:' + errorCorrectionLevel;
      }

      var length = rsBlock.length / 3;

      var list = [];

      for (var i = 0; i < length; i += 1) {

        var count = rsBlock[i * 3 + 0];
        var totalCount = rsBlock[i * 3 + 1];
        var dataCount = rsBlock[i * 3 + 2];

        for (var j = 0; j < count; j += 1) {
          list.push(qrRSBlock(totalCount, dataCount) );
        }
      }

      return list;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrBitBuffer
  //---------------------------------------------------------------------

  var qrBitBuffer = function() {

    var _buffer = [];
    var _length = 0;

    var _this = {};

    _this.getBuffer = function() {
      return _buffer;
    };

    _this.getAt = function(index) {
      var bufIndex = Math.floor(index / 8);
      return ( (_buffer[bufIndex] >>> (7 - index % 8) ) & 1) == 1;
    };

    _this.put = function(num, length) {
      for (var i = 0; i < length; i += 1) {
        _this.putBit( ( (num >>> (length - i - 1) ) & 1) == 1);
      }
    };

    _this.getLengthInBits = function() {
      return _length;
    };

    _this.putBit = function(bit) {

      var bufIndex = Math.floor(_length / 8);
      if (_buffer.length <= bufIndex) {
        _buffer.push(0);
      }

      if (bit) {
        _buffer[bufIndex] |= (0x80 >>> (_length % 8) );
      }

      _length += 1;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrNumber
  //---------------------------------------------------------------------

  var qrNumber = function(data) {

    var _mode = QRMode.MODE_NUMBER;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var data = _data;

      var i = 0;

      while (i + 2 < data.length) {
        buffer.put(strToNum(data.substring(i, i + 3) ), 10);
        i += 3;
      }

      if (i < data.length) {
        if (data.length - i == 1) {
          buffer.put(strToNum(data.substring(i, i + 1) ), 4);
        } else if (data.length - i == 2) {
          buffer.put(strToNum(data.substring(i, i + 2) ), 7);
        }
      }
    };

    var strToNum = function(s) {
      var num = 0;
      for (var i = 0; i < s.length; i += 1) {
        num = num * 10 + chatToNum(s.charAt(i) );
      }
      return num;
    };

    var chatToNum = function(c) {
      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      }
      throw 'illegal char :' + c;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrAlphaNum
  //---------------------------------------------------------------------

  var qrAlphaNum = function(data) {

    var _mode = QRMode.MODE_ALPHA_NUM;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var s = _data;

      var i = 0;

      while (i + 1 < s.length) {
        buffer.put(
          getCode(s.charAt(i) ) * 45 +
          getCode(s.charAt(i + 1) ), 11);
        i += 2;
      }

      if (i < s.length) {
        buffer.put(getCode(s.charAt(i) ), 6);
      }
    };

    var getCode = function(c) {

      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      } else if ('A' <= c && c <= 'Z') {
        return c.charCodeAt(0) - 'A'.charCodeAt(0) + 10;
      } else {
        switch (c) {
        case ' ' : return 36;
        case '$' : return 37;
        case '%' : return 38;
        case '*' : return 39;
        case '+' : return 40;
        case '-' : return 41;
        case '.' : return 42;
        case '/' : return 43;
        case ':' : return 44;
        default :
          throw 'illegal char :' + c;
        }
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qr8BitByte
  //---------------------------------------------------------------------

  var qr8BitByte = function(data) {

    var _mode = QRMode.MODE_8BIT_BYTE;
    var _data = data;
    var _bytes = qrcode.stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _bytes.length;
    };

    _this.write = function(buffer) {
      for (var i = 0; i < _bytes.length; i += 1) {
        buffer.put(_bytes[i], 8);
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrKanji
  //---------------------------------------------------------------------

  var qrKanji = function(data) {

    var _mode = QRMode.MODE_KANJI;
    var _data = data;

    var stringToBytes = qrcode.stringToBytesFuncs['SJIS'];
    if (!stringToBytes) {
      throw 'sjis not supported.';
    }
    !function(c, code) {
      // self test for sjis support.
      var test = stringToBytes(c);
      if (test.length != 2 || ( (test[0] << 8) | test[1]) != code) {
        throw 'sjis not supported.';
      }
    }('\u53cb', 0x9746);

    var _bytes = stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return ~~(_bytes.length / 2);
    };

    _this.write = function(buffer) {

      var data = _bytes;

      var i = 0;

      while (i + 1 < data.length) {

        var c = ( (0xff & data[i]) << 8) | (0xff & data[i + 1]);

        if (0x8140 <= c && c <= 0x9FFC) {
          c -= 0x8140;
        } else if (0xE040 <= c && c <= 0xEBBF) {
          c -= 0xC140;
        } else {
          throw 'illegal char at ' + (i + 1) + '/' + c;
        }

        c = ( (c >>> 8) & 0xff) * 0xC0 + (c & 0xff);

        buffer.put(c, 13);

        i += 2;
      }

      if (i < data.length) {
        throw 'illegal char at ' + (i + 1);
      }
    };

    return _this;
  };

  //=====================================================================
  // GIF Support etc.
  //

  //---------------------------------------------------------------------
  // byteArrayOutputStream
  //---------------------------------------------------------------------

  var byteArrayOutputStream = function() {

    var _bytes = [];

    var _this = {};

    _this.writeByte = function(b) {
      _bytes.push(b & 0xff);
    };

    _this.writeShort = function(i) {
      _this.writeByte(i);
      _this.writeByte(i >>> 8);
    };

    _this.writeBytes = function(b, off, len) {
      off = off || 0;
      len = len || b.length;
      for (var i = 0; i < len; i += 1) {
        _this.writeByte(b[i + off]);
      }
    };

    _this.writeString = function(s) {
      for (var i = 0; i < s.length; i += 1) {
        _this.writeByte(s.charCodeAt(i) );
      }
    };

    _this.toByteArray = function() {
      return _bytes;
    };

    _this.toString = function() {
      var s = '';
      s += '[';
      for (var i = 0; i < _bytes.length; i += 1) {
        if (i > 0) {
          s += ',';
        }
        s += _bytes[i];
      }
      s += ']';
      return s;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64EncodeOutputStream
  //---------------------------------------------------------------------

  var base64EncodeOutputStream = function() {

    var _buffer = 0;
    var _buflen = 0;
    var _length = 0;
    var _base64 = '';

    var _this = {};

    var writeEncoded = function(b) {
      _base64 += String.fromCharCode(encode(b & 0x3f) );
    };

    var encode = function(n) {
      if (n < 0) {
        // error.
      } else if (n < 26) {
        return 0x41 + n;
      } else if (n < 52) {
        return 0x61 + (n - 26);
      } else if (n < 62) {
        return 0x30 + (n - 52);
      } else if (n == 62) {
        return 0x2b;
      } else if (n == 63) {
        return 0x2f;
      }
      throw 'n:' + n;
    };

    _this.writeByte = function(n) {

      _buffer = (_buffer << 8) | (n & 0xff);
      _buflen += 8;
      _length += 1;

      while (_buflen >= 6) {
        writeEncoded(_buffer >>> (_buflen - 6) );
        _buflen -= 6;
      }
    };

    _this.flush = function() {

      if (_buflen > 0) {
        writeEncoded(_buffer << (6 - _buflen) );
        _buffer = 0;
        _buflen = 0;
      }

      if (_length % 3 != 0) {
        // padding
        var padlen = 3 - _length % 3;
        for (var i = 0; i < padlen; i += 1) {
          _base64 += '=';
        }
      }
    };

    _this.toString = function() {
      return _base64;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64DecodeInputStream
  //---------------------------------------------------------------------

  var base64DecodeInputStream = function(str) {

    var _str = str;
    var _pos = 0;
    var _buffer = 0;
    var _buflen = 0;

    var _this = {};

    _this.read = function() {

      while (_buflen < 8) {

        if (_pos >= _str.length) {
          if (_buflen == 0) {
            return -1;
          }
          throw 'unexpected end of file./' + _buflen;
        }

        var c = _str.charAt(_pos);
        _pos += 1;

        if (c == '=') {
          _buflen = 0;
          return -1;
        } else if (c.match(/^\s$/) ) {
          // ignore if whitespace.
          continue;
        }

        _buffer = (_buffer << 6) | decode(c.charCodeAt(0) );
        _buflen += 6;
      }

      var n = (_buffer >>> (_buflen - 8) ) & 0xff;
      _buflen -= 8;
      return n;
    };

    var decode = function(c) {
      if (0x41 <= c && c <= 0x5a) {
        return c - 0x41;
      } else if (0x61 <= c && c <= 0x7a) {
        return c - 0x61 + 26;
      } else if (0x30 <= c && c <= 0x39) {
        return c - 0x30 + 52;
      } else if (c == 0x2b) {
        return 62;
      } else if (c == 0x2f) {
        return 63;
      } else {
        throw 'c:' + c;
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // gifImage (B/W)
  //---------------------------------------------------------------------

  var gifImage = function(width, height) {

    var _width = width;
    var _height = height;
    var _data = new Array(width * height);

    var _this = {};

    _this.setPixel = function(x, y, pixel) {
      _data[y * _width + x] = pixel;
    };

    _this.write = function(out) {

      //---------------------------------
      // GIF Signature

      out.writeString('GIF87a');

      //---------------------------------
      // Screen Descriptor

      out.writeShort(_width);
      out.writeShort(_height);

      out.writeByte(0x80); // 2bit
      out.writeByte(0);
      out.writeByte(0);

      //---------------------------------
      // Global Color Map

      // black
      out.writeByte(0x00);
      out.writeByte(0x00);
      out.writeByte(0x00);

      // white
      out.writeByte(0xff);
      out.writeByte(0xff);
      out.writeByte(0xff);

      //---------------------------------
      // Image Descriptor

      out.writeString(',');
      out.writeShort(0);
      out.writeShort(0);
      out.writeShort(_width);
      out.writeShort(_height);
      out.writeByte(0);

      //---------------------------------
      // Local Color Map

      //---------------------------------
      // Raster Data

      var lzwMinCodeSize = 2;
      var raster = getLZWRaster(lzwMinCodeSize);

      out.writeByte(lzwMinCodeSize);

      var offset = 0;

      while (raster.length - offset > 255) {
        out.writeByte(255);
        out.writeBytes(raster, offset, 255);
        offset += 255;
      }

      out.writeByte(raster.length - offset);
      out.writeBytes(raster, offset, raster.length - offset);
      out.writeByte(0x00);

      //---------------------------------
      // GIF Terminator
      out.writeString(';');
    };

    var bitOutputStream = function(out) {

      var _out = out;
      var _bitLength = 0;
      var _bitBuffer = 0;

      var _this = {};

      _this.write = function(data, length) {

        if ( (data >>> length) != 0) {
          throw 'length over';
        }

        while (_bitLength + length >= 8) {
          _out.writeByte(0xff & ( (data << _bitLength) | _bitBuffer) );
          length -= (8 - _bitLength);
          data >>>= (8 - _bitLength);
          _bitBuffer = 0;
          _bitLength = 0;
        }

        _bitBuffer = (data << _bitLength) | _bitBuffer;
        _bitLength = _bitLength + length;
      };

      _this.flush = function() {
        if (_bitLength > 0) {
          _out.writeByte(_bitBuffer);
        }
      };

      return _this;
    };

    var getLZWRaster = function(lzwMinCodeSize) {

      var clearCode = 1 << lzwMinCodeSize;
      var endCode = (1 << lzwMinCodeSize) + 1;
      var bitLength = lzwMinCodeSize + 1;

      // Setup LZWTable
      var table = lzwTable();

      for (var i = 0; i < clearCode; i += 1) {
        table.add(String.fromCharCode(i) );
      }
      table.add(String.fromCharCode(clearCode) );
      table.add(String.fromCharCode(endCode) );

      var byteOut = byteArrayOutputStream();
      var bitOut = bitOutputStream(byteOut);

      // clear code
      bitOut.write(clearCode, bitLength);

      var dataIndex = 0;

      var s = String.fromCharCode(_data[dataIndex]);
      dataIndex += 1;

      while (dataIndex < _data.length) {

        var c = String.fromCharCode(_data[dataIndex]);
        dataIndex += 1;

        if (table.contains(s + c) ) {

          s = s + c;

        } else {

          bitOut.write(table.indexOf(s), bitLength);

          if (table.size() < 0xfff) {

            if (table.size() == (1 << bitLength) ) {
              bitLength += 1;
            }

            table.add(s + c);
          }

          s = c;
        }
      }

      bitOut.write(table.indexOf(s), bitLength);

      // end code
      bitOut.write(endCode, bitLength);

      bitOut.flush();

      return byteOut.toByteArray();
    };

    var lzwTable = function() {

      var _map = {};
      var _size = 0;

      var _this = {};

      _this.add = function(key) {
        if (_this.contains(key) ) {
          throw 'dup key:' + key;
        }
        _map[key] = _size;
        _size += 1;
      };

      _this.size = function() {
        return _size;
      };

      _this.indexOf = function(key) {
        return _map[key];
      };

      _this.contains = function(key) {
        return typeof _map[key] != 'undefined';
      };

      return _this;
    };

    return _this;
  };

  var createDataURL = function(width, height, getPixel) {
    var gif = gifImage(width, height);
    for (var y = 0; y < height; y += 1) {
      for (var x = 0; x < width; x += 1) {
        gif.setPixel(x, y, getPixel(x, y) );
      }
    }

    var b = byteArrayOutputStream();
    gif.write(b);

    var base64 = base64EncodeOutputStream();
    var bytes = b.toByteArray();
    for (var i = 0; i < bytes.length; i += 1) {
      base64.writeByte(bytes[i]);
    }
    base64.flush();

    return 'data:image/gif;base64,' + base64;
  };

  //---------------------------------------------------------------------
  // returns qrcode function.

  return qrcode;
}();

// multibyte support
!function() {

  qrcode.stringToBytesFuncs['UTF-8'] = function(s) {
    // http://stackoverflow.com/questions/18729405/how-to-convert-utf8-string-to-byte-array
    function toUTF8Array(str) {
      var utf8 = [];
      for (var i=0; i < str.length; i++) {
        var charcode = str.charCodeAt(i);
        if (charcode < 0x80) utf8.push(charcode);
        else if (charcode < 0x800) {
          utf8.push(0xc0 | (charcode >> 6),
              0x80 | (charcode & 0x3f));
        }
        else if (charcode < 0xd800 || charcode >= 0xe000) {
          utf8.push(0xe0 | (charcode >> 12),
              0x80 | ((charcode>>6) & 0x3f),
              0x80 | (charcode & 0x3f));
        }
        // surrogate pair
        else {
          i++;
          // UTF-16 encodes 0x10000-0x10FFFF by
          // subtracting 0x10000 and splitting the
          // 20 bits of 0x0-0xFFFFF into two halves
          charcode = 0x10000 + (((charcode & 0x3ff)<<10)
            | (str.charCodeAt(i) & 0x3ff));
          utf8.push(0xf0 | (charcode >>18),
              0x80 | ((charcode>>12) & 0x3f),
              0x80 | ((charcode>>6) & 0x3f),
              0x80 | (charcode & 0x3f));
        }
      }
      return utf8;
    }
    return toUTF8Array(s);
  };

}();
  return qrcode;
})();
